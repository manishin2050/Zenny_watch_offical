(function(g) {
    var window = this;
    'use strict';
    var ID = function(l) {
            l.publish("cardstatechange", l.iZ() && l.jj() ? 1 : 0)
        },
        fG = function(l, E) {
            var e = g.Co(E),
                d = e ? E : arguments;
            for (e = e ? 0 : 1; e < d.length; e++) {
                if (l == null) return;
                l = l[d[e]]
            }
            return l
        },
        hki = function(l) {
            var E = g.nQ(l);
            l = g.es(l);
            return new g.$$(E.x, E.y, l.width, l.height)
        },
        Fut = function(l, E, e) {
            var d = d === void 0 ? {} : d;
            var C;
            return C = g.KE(l, E, function() {
                g.Ur(C);
                e.apply(l, arguments)
            }, d)
        },
        kB = function(l) {
            l = g.u_(l);
            delete P8[l];
            g.Jw(P8) && RD && RD.stop()
        },
        cb6 = function() {
            RD || (RD = new g.Gv(function() {
                Lux()
            }, 20));
            var l = RD;
            l.isActive() || l.start()
        },
        Lux = function() {
            var l = g.v6();
            g.lR(P8, function(E) {
                i36(E, l)
            });
            g.Jw(P8) || cb6()
        },
        ht = function(l, E, e, d) {
            g.BN.call(this);
            if (!Array.isArray(l) || !Array.isArray(E)) throw Error("Start and end parameters must be arrays");
            if (l.length != E.length) throw Error("Start and end points must be the same length");
            this.V = l;
            this.Y = E;
            this.duration = e;
            this.Z = d;
            this.coords = [];
            this.progress = this.X = 0;
            this.W = null
        },
        i36 = function(l, E) {
            E < l.startTime && (l.endTime = E + l.endTime - l.startTime, l.startTime = E);
            l.progress = (E - l.startTime) / (l.endTime - l.startTime);
            l.progress > 1 && (l.progress = 1);
            l.X = 1E3 / (E - l.W);
            l.W = E;
            Z3H(l, l.progress);
            l.progress == 1 ? (l.C = 0, kB(l), l.onFinish(), l.Qr()) : l.isPlaying() && l.v8()
        },
        Z3H = function(l, E) {
            typeof l.Z === "function" && (E = l.Z(E));
            l.coords = Array(l.V.length);
            for (var e = 0; e < l.V.length; e++) l.coords[e] = (l.Y[e] - l.V[e]) * E + l.V[e]
        },
        $MK = function(l, E) {
            g.G4.call(this, l);
            this.coords = E.coords;
            this.x = E.coords[0];
            this.y = E.coords[1];
            this.z = E.coords[2];
            this.duration = E.duration;
            this.progress = E.progress;
            this.fps = E.X;
            this.state = E.C
        },
        FL = function(l, E, e, d, C) {
            ht.call(this, E, e, d, C);
            this.element = l
        },
        TEi = function(l, E, e, d, C) {
            if (E.length != 2 || e.length != 2) throw Error("Start and end points must be 2D");
            FL.call(this, l, E, e, d, C)
        },
        gxo = function(l) {
            return Math.pow(l, 3)
        },
        Wu6 = function(l) {
            return 3 * l * l - 2 * l * l * l
        },
        jVx = function(l) {
            g.F.call(this);
            this.V = l || window;
            this.C = []
        },
        LG = function(l) {
            return l.baseUrl || null
        },
        c8 = function(l, E) {
            return g.aM(g.KF(l, E), function(e) {
                return !!e
            })
        },
        GXB = function(l, E, e) {
            function d(BB) {
                var OZ = BB.hovercardButton;
                if (!OZ) return null;
                OZ = OZ.subscribeButtonRenderer;
                if (!OZ) return null;
                var No = x(OZ.unsubscribedButtonText),
                    eR = x(OZ.subscribedButtonText);
                if (OZ.subscribed) {
                    var fs = x(OZ.subscriberCountWithUnsubscribeText);
                    var SR = x(OZ.subscriberCountText)
                } else fs = x(OZ.subscriberCountText), SR = x(OZ.subscriberCountWithSubscribeText);
                var l_ = null;
                if (BB.signinEndpoint) {
                    l_ = fG(BB, "signinEndpoint", "webNavigationEndpointData", "url");
                    if (!l_) {
                        var po, B6;
                        l_ = (B6 = g.T((po = OZ.signInEndpoint) == null ? void 0 : po.commandMetadata, g.tD)) == null ?
                            void 0 : B6.url
                    }
                    if (!l_) return null
                }
                return No && (eR || l_) ? {
                    subscribed: OZ.subscribed,
                    subscribeText: No,
                    subscribeCount: fs,
                    unsubscribeText: eR,
                    unsubscribeCount: SR,
                    enabled: OZ.enabled,
                    signinUrl: l_,
                    classic: BB.useClassicSubscribeButton
                } : null
            }

            function C(BB) {
                if (BB) {
                    var OZ = [],
                        No = BB.videoId;
                    No && OZ.push("v=" + No);
                    (No = BB.playlistId) && OZ.push("list=" + No);
                    (BB = BB.startTimeSeconds) && OZ.push("t=" + BB);
                    return "/watch?" + OZ.join("&")
                }
            }

            function x(BB) {
                if (!BB) return null;
                var OZ = BB.simpleText;
                return OZ ? OZ : BB.runs ? g.KF(BB.runs, function(No) {
                    return No.text
                }).join("") : null
            }
            E = E.endscreenElementRenderer;
            if (!E) return null;
            var Y = E.style,
                B = E.endpoint || {},
                q = null,
                O = null,
                M = !1,
                v = null,
                N = null,
                J = null,
                b = null,
                m = !1,
                H = null,
                Q = null,
                A = null,
                f = null,
                h = null,
                Z = null;
            if (Y === "VIDEO") g.T(B, g.PF) ? q = g.T(B, g.PF).url : (Z = g.T(B, g.oR), q = C(Z)), O = !1, v = l, E.thumbnailOverlays ? (M = E.thumbnailOverlays[0].thumbnailOverlayTimeStatusRenderer, N = x(M.text), M = M.style === "LIVE") : N = x(E.videoDuration);
            else if (Y === "PLAYLIST") g.T(B, g.PF) ? q = g.T(B, g.PF).url : (Z = g.T(B, g.oR), q = C(Z)), O = !1, v = l, J = x(E.playlistLength);
            else if (Y ===
                "CHANNEL") {
                if (m = fG(B, "browseEndpoint", "browseId")) b = m, q = "/channel/" + b;
                O = !1;
                v = "new";
                (m = !!E.isSubscribe) ? H = d(E): Q = x(E.subscribersText)
            } else Y === "WEBSITE" ? ((A = fG(B, "urlEndpoint", "url")) && (q = A), O = !0, v = "new", A = E.icon.thumbnails[0].url) : Y === "CREATOR_MERCHANDISE" && (E.productPrice && (f = x(E.productPrice)), E.additionalFeesText && (h = x(E.additionalFeesText)), (O = fG(B, "urlEndpoint", "url")) && (q = O), O = !0, v = "new");
            l = fG(E, "title", "accessibility", "accessibilityData", "label");
            var r = E.endpoint ? E.endpoint.clickTrackingParams :
                null,
                X = "";
            if (E.metadata) {
                var qo = x(E.metadata);
                qo && (X = qo)
            }
            return {
                id: "element-" + e,
                type: Y,
                title: x(E.title),
                metadata: X,
                callToAction: x(E.callToAction),
                iQ: E.image,
                iconUrl: A,
                left: Number(E.left),
                width: Number(E.width),
                top: Number(E.top),
                aspectRatio: Number(E.aspectRatio),
                startMs: Math.floor(Number(E.startMs)),
                endMs: Math.floor(Number(E.endMs)),
                videoDuration: N,
                SO: M,
                playlistLength: J,
                channelId: b,
                subscribeButton: H,
                subscribersText: Q,
                isSubscribe: m,
                targetUrl: q || null,
                YZ: O,
                sessionData: r ? {
                    itct: r
                } : null,
                JcK: v,
                Pm: l ? l : null,
                isPlaceholder: E.isPlaceholder,
                impressionUrls: c8(E.impressionUrls || [], LG),
                Ok: c8(E.hovercardShowUrls || [], LG),
                clickUrls: c8(B.loggingUrls || [], LG),
                visualElement: g.bG(E.trackingParams),
                productPrice: f,
                additionalFeesText: h,
                watchEndpoint: Z || null
            }
        },
        XrN = function(l, E) {
            var e = {
                startMs: Math.floor(Number(l.startMs)),
                impressionUrls: c8(l.impressionUrls || [], LG),
                elements: c8(l.elements || [], function(d, C) {
                    return GXB(E, d, C)
                })
            };
            l.trackingParams && (e.visualElement = g.bG(l.trackingParams));
            return e
        },
        SoR = function(l) {
            g.Vc.call(this, l);
            this.W = this.endscreen = null;
            this.V = {};
            this.X = {};
            this.Z = this.G = null;
            this.K = [];
            this.C = null;
            this.o4 = !0;
            this.Y = 0;
            l = l.N();
            this.U = g.qk(l) || g.Mk(l);
            this.events = new g.oE(this);
            g.L(this, this.events);
            this.events.L(this.player, g.zw("creatorendscreen"), this.onCueRangeEnter);
            this.events.L(this.player, g.r9("creatorendscreen"), this.onCueRangeExit);
            this.events.L(this.player, "resize", this.l2);
            this.events.L(window, "focus", this.yE8);
            this.load();
            var E = g.bV("STYLE");
            (g.Y$("HEAD")[0] || document.body).appendChild(E);
            this.addOnDisposeCallback(function() {
                g.mT(E)
            });
            E.sheet && (E.sheet.insertRule(".ytp-ce-playlist-icon {background:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABIAAAASBAMAAACk4JNkAAAABGdBTUEAALGPC/xhBQAAACBjSFJNAAB6JgAAgIQAAPoAAACA6AAAdTAAAOpgAAA6mAAAF3CculE8AAAAIVBMVEVMaXGzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7P///91E4wTAAAACXRSTlMArBbpVOtYrReN+x2FAAAAAWJLR0QKaND0VgAAACFJREFUCNdjYCAWzIQAFBaZ6hgVYLKcJnBWGEyWvYGASwCXtBf7m4i3CQAAAABJRU5ErkJggg==) no-repeat center;background-size:18px;width:18px;height:18px}", 0), E.sheet.insertRule(".ytp-ce-size-853 .ytp-ce-playlist-icon, .ytp-ce-size-1280 .ytp-ce-playlist-icon, .ytp-ce-size-1920 .ytp-ce-playlist-icon {background:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYBAMAAAASWSDLAAAABGdBTUEAALGPC/xhBQAAACBjSFJNAAB6JgAAgIQAAPoAAACA6AAAdTAAAOpgAAA6mAAAF3CculE8AAAAJ1BMVEVMaXGzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7P///9RfzIKAAAAC3RSTlMAvDeyLvxYtDK9Ogx4T1QAAAABYktHRAyBs1FjAAAAK0lEQVQY02NgoBjshgO8HJoYwKiAMGAD92YHJM7uMCTO9gaEHs4FlPuZAQC8Fj8x/xHjxwAAAABJRU5ErkJggg==) no-repeat center;background-size:24px;width:24px;height:24px}",
                0))
        },
        zkB = function(l) {
            return l.player.getVideoData().HB ? "current" : l.U ? "new" : "current"
        },
        i2 = function(l) {
            return l.player.N().playerStyle === "creator-endscreen-editor"
        },
        rbW = function(l) {
            var E = l.player.getVideoData(),
                e = E.videoId;
            l.W && l.W.abort();
            e = {
                method: "POST",
                onFinish: function(C) {
                    var x = l.W = null;
                    C.status === 200 && (C = C.responseText, C.substring(0, 3) === ")]}" && (C = C.substring(3), x = JSON.parse(C), x = XrN(x, zkB(l))));
                    Z6(l, x)
                },
                urlParams: {
                    v: e
                },
                withCredentials: !0
            };
            l.U && (e.urlParams.ptype = "embedded");
            var d = E.m$;
            d && (e.postParams = {
                ad_tracking: d
            });
            if (E = g.cuZ(E))
                if (E = g.Bb(E), E = g.x1(E)) l.W = g.yD(E, e)
        },
        Z6 = function(l, E, e) {
            e = e === void 0 ? !0 : e;
            l.player.tE("creatorendscreen");
            l.G && (l.G.dispose(), l.G = null, l.Z.dispose(), l.Z = null);
            for (var d = g.U(Object.values(l.V)), C = d.next(); !C.done; C = d.next()) C.value.dispose();
            l.V = {};
            l.X = {};
            l.K.length > 0 && (l.K.forEach(function(B) {
                B.dispose()
            }), l.K.length = 0);
            l.C && (g.xP(l.C, "ytp-ce-element-show"), l.C.setAttribute("aria-hidden", "true"));
            l.Y = 0;
            if ((l.endscreen = E) && E.elements) {
                e && wrR(l);
                e = [];
                d = new g.X1(E.startMs, 0x7ffffffffffff, {
                    id: "ytp-ce-in-endscreen",
                    namespace: "creatorendscreen"
                });
                e.push(d);
                l.player.N().V || (l.G = new g.W({
                    j: "div",
                    T: "ytp-ce-shadow"
                }), g.lb(l.player, l.G.element, 4), l.Z = new g.wY(l.G, 200));
                for (d = 0; d < E.elements.length; ++d) {
                    C = E.elements[d];
                    var x = nxW(l, C);
                    if (x) {
                        l.V[C.id] = x;
                        l.X[C.id] = C;
                        g.lb(l.player, x.element, 4);
                        var Y = new g.X1(C.startMs, C.endMs, {
                            id: "ytp-ce-element-" +
                                C.id,
                            namespace: "creatorendscreen"
                        });
                        e.push(Y);
                        ljD(l, x, C)
                    } else g.Qj(new g.$C("buildEndscreenElement null", C))
                }
                l.player.Lh(e);
                l.l2()
            }
        },
        wrR = function(l) {
            var E = g.pi(),
                e = g.Ki();
            e && E && l.endscreen.visualElement && g.Xs(g.iG)(void 0, e, E, l.endscreen.visualElement)
        },
        nxW = function(l, E) {
            var e = null;
            switch (E.type) {
                case "VIDEO":
                    l = {
                        j: "div",
                        R4: ["ytp-ce-element", "ytp-ce-video"],
                        J: {
                            tabindex: "0",
                            "aria-label": E.Pm || "",
                            "aria-hidden": "true"
                        },
                        S: [{
                            j: "div",
                            T: "ytp-ce-element-shadow"
                        }, {
                            j: "div",
                            T: "ytp-ce-covering-image",
                            J: $B(E)
                        }, {
                            j: "div",
                            T: "ytp-ce-covering-shadow-top"
                        }, {
                            j: "a",
                            T: "ytp-ce-covering-overlay",
                            J: {
                                href: TE(l, E.targetUrl),
                                tabindex: "-1"
                            },
                            S: [{
                                j: "div",
                                R4: ["ytp-ce-video-title", "ytp-webkit-ellipsis"],
                                J: {
                                    dir: g.NE(E.title || "")
                                },
                                zK: E.title
                            }, {
                                j: "div",
                                T: E.SO ? "ytp-ce-live-video-duration" : "ytp-ce-video-duration",
                                zK: E.videoDuration || void 0
                            }]
                        }]
                    };
                    e = new g.W(l);
                    break;
                case "PLAYLIST":
                    l = {
                        j: "div",
                        R4: ["ytp-ce-element", "ytp-ce-playlist"],
                        J: {
                            tabindex: "0",
                            "aria-label": E.Pm || "",
                            "aria-hidden": "true"
                        },
                        S: [{
                            j: "div",
                            T: "ytp-ce-element-shadow"
                        }, {
                            j: "div",
                            T: "ytp-ce-covering-image",
                            J: $B(E)
                        }, {
                            j: "div",
                            T: "ytp-ce-covering-shadow-top"
                        }, {
                            j: "a",
                            T: "ytp-ce-covering-overlay",
                            J: {
                                href: TE(l, E.targetUrl),
                                tabindex: "-1"
                            },
                            S: [{
                                j: "div",
                                R4: ["ytp-ce-playlist-title", "ytp-webkit-ellipsis"],
                                J: {
                                    dir: g.NE(E.title || "")
                                },
                                zK: E.title
                            }, {
                                j: "div",
                                T: "ytp-ce-playlist-count",
                                S: [{
                                    j: "div",
                                    T: "ytp-ce-playlist-icon"
                                }, {
                                    j: "div",
                                    T: "ytp-ce-playlist-count-text",
                                    zK: E.playlistLength || void 0
                                }]
                            }]
                        }]
                    };
                    e = new g.W(l);
                    break;
                case "CHANNEL":
                    e = {
                        j: "div",
                        R4: ["ytp-ce-element", "ytp-ce-channel", E.isSubscribe ? "ytp-ce-channel-this" : "ytp-ce-channel-that"],
                        J: {
                            tabindex: "0",
                            "aria-label": E.Pm || "",
                            "aria-hidden": "true"
                        },
                        S: [{
                            j: "div",
                            T: "ytp-ce-element-shadow"
                        }, {
                            j: "div",
                            T: "ytp-ce-expanding-overlay",
                            S: [{
                                j: "div",
                                T: "ytp-ce-expanding-overlay-hider"
                            }, {
                                j: "div",
                                T: "ytp-ce-expanding-overlay-background"
                            }, {
                                j: "div",
                                T: "ytp-ce-expanding-overlay-content",
                                S: [{
                                    j: "div",
                                    T: "ytp-ce-expanding-overlay-body",
                                    S: [{
                                        j: "div",
                                        T: "ytp-ce-expanding-overlay-body-padding",
                                        S: [{
                                            j: "a",
                                            R4: ["ytp-ce-channel-title", "ytp-ce-link"],
                                            J: {
                                                href: TE(l, E.targetUrl),
                                                target: "_blank",
                                                tabindex: "-1",
                                                dir: g.NE(E.title || "")
                                            },
                                            zK: E.title
                                        }, E.subscribeButton ? {
                                            j: "div",
                                            T: "ytp-ce-subscribe-container",
                                            S: [{
                                                j: "div",
                                                T: "ytp-ce-channel-subscribe"
                                            }]
                                        } : "", E.subscribersText ? {
                                            j: "div",
                                            T: "ytp-ce-channel-subscribers-text",
                                            zK: E.subscribersText
                                        } : "", E.metadata ? {
                                            j: "div",
                                            R4: ["ytp-ce-channel-metadata", "yt-ui-ellipsis",
                                                "yt-ui-ellipsis-3"
                                            ],
                                            zK: E.metadata
                                        } : ""]
                                    }]
                                }]
                            }]
                        }, {
                            j: "div",
                            T: "ytp-ce-expanding-image",
                            J: $B(E)
                        }]
                    };
                    e = new g.W(e);
                    var d = g.B_(document, "div", "ytp-ce-channel-subscribe", e.element)[0];
                    if (E.subscribeButton && E.channelId) {
                        g.d4(d, "ytp-ce-subscribe-button");
                        if (l.player.N().V) {
                            var C = null;
                            var x = E.sessionData.itct
                        } else C = "endscreen", x = null;
                        C = new g.Cl(E.subscribeButton.subscribeText, E.subscribeButton.subscribeCount, E.subscribeButton.unsubscribeText, E.subscribeButton.unsubscribeCount, !!E.subscribeButton.enabled, !!E.subscribeButton.classic,
                            E.channelId, !!E.subscribeButton.subscribed, C, x, l.player, !1);
                        d.appendChild(C.element);
                        l.K.push(C)
                    }
                    break;
                case "WEBSITE":
                    l = {
                        j: "div",
                        R4: ["ytp-ce-element", "ytp-ce-website"],
                        J: {
                            tabindex: "0",
                            "aria-label": E.Pm || "",
                            "aria-hidden": "true"
                        },
                        S: [{
                            j: "div",
                            T: "ytp-ce-element-shadow"
                        }, {
                            j: "div",
                            T: "ytp-ce-expanding-overlay",
                            S: [{
                                j: "div",
                                T: "ytp-ce-expanding-overlay-hider"
                            }, {
                                j: "div",
                                T: "ytp-ce-expanding-overlay-background"
                            }, {
                                j: "div",
                                T: "ytp-ce-expanding-overlay-content",
                                S: [{
                                    j: "div",
                                    T: "ytp-ce-expanding-overlay-body",
                                    S: [{
                                        j: "div",
                                        T: "ytp-ce-expanding-overlay-body-padding",
                                        S: [{
                                            j: "div",
                                            T: "ytp-ce-website-title",
                                            J: {
                                                dir: g.NE(E.title || "")
                                            },
                                            zK: E.title
                                        }, {
                                            j: "div",
                                            T: "ytp-ce-website-metadata",
                                            zK: E.metadata
                                        }, {
                                            j: "a",
                                            R4: ["ytp-ce-website-goto", "ytp-ce-link"],
                                            J: {
                                                href: TE(l, E.targetUrl),
                                                target: "_blank",
                                                tabindex: "-1"
                                            },
                                            zK: E.callToAction
                                        }]
                                    }]
                                }]
                            }]
                        }, {
                            j: "div",
                            T: "ytp-ce-expanding-image",
                            J: $B(E)
                        }, {
                            j: "div",
                            T: "ytp-ce-expanding-icon",
                            J: EGN(E.iconUrl)
                        }]
                    };
                    e = new g.W(l);
                    break;
                case "CREATOR_MERCHANDISE":
                    e = "", E.productPrice && (e = {
                        j: "div",
                        T: "ytp-ce-merchandise-price-container",
                        S: [{
                            j: "div",
                            T: "ytp-ce-merchandise-price",
                            zK: E.productPrice
                        }]
                    }, E.additionalFeesText && e.S.push({
                        j: "div",
                        T: "ytp-ce-merchandise-additional-fees",
                        zK: E.additionalFeesText
                    })), l = {
                        j: "div",
                        R4: ["ytp-ce-element", "ytp-ce-merchandise"],
                        J: {
                            tabindex: "0",
                            "aria-label": E.Pm || "",
                            "aria-hidden": "true"
                        },
                        S: [{
                            j: "div",
                            T: "ytp-ce-element-shadow"
                        }, {
                            j: "div",
                            T: "ytp-ce-expanding-overlay",
                            S: [{
                                j: "div",
                                T: "ytp-ce-expanding-overlay-hider"
                            }, {
                                j: "div",
                                T: "ytp-ce-expanding-overlay-background"
                            }, {
                                j: "div",
                                T: "ytp-ce-expanding-overlay-content",
                                S: [{
                                    j: "div",
                                    T: "ytp-ce-expanding-overlay-body",
                                    S: [{
                                        j: "div",
                                        T: "ytp-ce-expanding-overlay-body-padding",
                                        S: [{
                                            j: "div",
                                            T: "ytp-ce-merchandise-title",
                                            J: {
                                                dir: g.NE(E.title || "")
                                            },
                                            zK: E.title
                                        }, e, {
                                            j: "div",
                                            T: "ytp-ce-merchandise-metadata",
                                            zK: E.metadata
                                        }, {
                                            j: "a",
                                            R4: ["ytp-ce-merchandise-goto", "ytp-ce-link"],
                                            J: {
                                                href: TE(l, E.targetUrl),
                                                target: "_blank",
                                                tabindex: "-1"
                                            },
                                            zK: E.callToAction
                                        }]
                                    }]
                                }]
                            }]
                        }, {
                            j: "div",
                            T: "ytp-ce-expanding-image",
                            J: $B(E)
                        }, {
                            j: "div",
                            T: "ytp-ce-merchandise-invideo-cta-container",
                            S: [{
                                j: "div",
                                T: "ytp-ce-merchandise-invideo-cta",
                                zK: E.callToAction || void 0
                            }]
                        }]
                    }, e = new g.W(l)
            }
            E.isPlaceholder && g.d4(e.element, "ytp-ce-placeholder");
            return e
        },
        $B = function(l) {
            if (l.iQ) var E = l.iQ.thumbnails;
            return EGN(E ? E[E.length - 1].url : null)
        },
        EGN = function(l) {
            return l ? {
                style: "background-image: url(" + l + ")"
            } : {}
        },
        ljD = function(l, E, e) {
            function d(q) {
                q && (E.listen("blur", function() {
                    q.style.display != "none" && l.o4 && q.focus()
                }), E.L(q, "focus", x), E.L(q, "blur", Y))
            }

            function C(q) {
                l.Y += q;
                l.Y > 0 ? (g.d4(E.element, "ytp-ce-force-expand"), gs(l, e.id, !0)) : (g.xP(E.element, "ytp-ce-force-expand"), g.xP(E.element, "ytp-ce-element-hover"), gs(l, e.id, !1))
            }

            function x() {
                C(1)
            }

            function Y() {
                C(-1)
            }
            E.listen("mouseenter", function() {
                eO5(l, E, e)
            });
            E.listen("mouseleave", function() {
                dI_(l, E, e)
            });
            l.player.N().V || E.listen("click", function() {
                g.d4(E.element, "ytp-ce-element-hover")
            });
            E.listen("click", function(q) {
                Chx(l, e, q)
            });
            E.listen("keypress", function(q) {
                Chx(l, e, q)
            });
            E.listen("focus", function() {
                eO5(l, E, e)
            });
            E.listen("blur", function() {
                dI_(l, E, e)
            });
            E.listen("touchstart", function() {
                eO5(l, E, e)
            });
            var B = g.qr("ytp-ce-expanding-overlay-hider", E.element);
            B && E.L(B, "touchstart", function(q) {
                q.stopPropagation();
                g.xP(E.element, "ytp-ce-element-hover");
                g.xP(E.element, "ytp-ce-force-expand")
            });
            E.listen("keydown", function(q) {
                l.o4 = q.keyCode === 9 && !q.shiftKey
            });
            d(g.qr("ytp-sb-subscribe", E.element));
            d(g.qr("ytp-sb-unsubscribe", E.element));
            E.listen("focus", x);
            E.listen("blur", Y)
        },
        Chx = function(l, E, e) {
            if (E.targetUrl && (!e || e.type !== "keypress" || e.keyCode === 13)) {
                for (var d = e.target; d && !g.ec(d, "ytp-ce-element");) {
                    g.ec(d, "subscribe-label") && xI6(l, E);
                    if (g.ec(d, "ytp-ce-channel-subscribe")) return;
                    d = d.parentElement || null
                }
                if (!d || g.ec(d, "ytp-ce-element-hover")) {
                    e.preventDefault();
                    e.stopPropagation();
                    if (d = l.V[E.id]) dI_(l, d, E), d.element.blur();
                    if (e.ctrlKey || e.metaKey || E.JcK === "new") xI6(l, E), l.player.sendVideoStatsEngageEvent(17, void 0), l.player.pauseVideo(), e = g.Bb(TE(l, E.targetUrl)), e = g.x1(e), g.Ze(e, void 0, E.sessionData);
                    else {
                        var C = g.Vr(l.player.N()) || l.player.getVideoData().HB,
                            x = function() {
                                var Y = TE(l, E.targetUrl),
                                    B = E.sessionData,
                                    q = E.watchEndpoint,
                                    O =
                                    g.l0(Y);
                                C && O && (O.v || O.list) ? l.player.Q4(O.v, B, O.list, !1, void 0, q || void 0) : g.ix(Y, B)
                            };
                        xI6(l, E, function() {
                            l.player.sendVideoStatsEngageEvent(17, x)
                        })
                    }
                }
            }
        },
        TE = function(l, E) {
            l = l.player.N();
            if (E) {
                if (E.startsWith("//")) return l.protocol + ":" + E;
                if (E.startsWith("/")) return g.PI(l) + E
            } else return "";
            return E
        },
        eO5 = function(l, E, e) {
            g.ec(E.element, "ytp-ce-element-hover") || (e.type === "VIDEO" || e.type === "PLAYLIST" ? g.d4(E.element, "ytp-ce-element-hover") : l.player.N().V ? (new g.Gv(function() {
                g.d4(E.element, "ytp-ce-element-hover")
            }, 200)).start() : g.d4(E.element, "ytp-ce-element-hover"), W8(l, e.Ok), gs(l, e.id, !0))
        },
        dI_ = function(l, E, e) {
            g.xP(E.element, "ytp-ce-element-hover");
            g.xP(E.element, "ytp-ce-force-expand");
            gs(l, e.id, !1)
        },
        gs = function(l, E, e) {
            l.G && (e ? l.Z.show() : l.Z.hide());
            for (var d = g.U(Object.keys(l.V)), C = d.next(); !C.done; C = d.next()) C = C.value, C !== E && g.u9(l.V[C].element, "ytp-ce-element-shadow-show", e)
        },
        W8 = function(l, E, e) {
            function d() {
                x || (C++, C === E.length && (Y.stop(), e && e()))
            }
            if (!E || E.length === 0 || i2(l)) e && e();
            else {
                E = Yqx(l, E);
                var C = 0,
                    x = !1,
                    Y = new g.Gv(function() {
                        x = !0;
                        e && e()
                    }, 1E3, l);
                Y.start();
                for (l = 0; l < E.length; l++) g.P3(E[l], d)
            }
        },
        xI6 = function(l, E, e) {
            W8(l, E.clickUrls, e);
            (l = g.Ki()) && E.YZ && g.r$(l, E.visualElement)
        },
        Yqx = function(l, E) {
            var e = l.player.getVideoData().clientPlaybackNonce;
            l = l.player.getCurrentTime().toFixed(2);
            e = {
                CPN: e,
                AD_CPN: e,
                MT: l
            };
            l = [];
            for (var d = 0; d < E.length; d++) l.push(uj_(E[d], e));
            return l
        },
        uj_ = function(l, E) {
            return l.replace(/%5B[a-zA-Z_:]+%5D|\[[a-zA-Z_:]+\]/g, function(e) {
                var d = unescape(e);
                d = d.substring(1, d.length - 1);
                return E[d] ? escape(E[d]) : e
            })
        },
        B1i = function(l) {
            return typeof l === "string" ? l : ""
        },
        j9 = function(l, E, e) {
            for (var d in E)
                if (E[d] === l) return l;
            return e
        },
        qq6 = function(l, E, e, d) {
            this.value = l;
            this.target = E;
            this.showLinkIcon = e;
            this.C = d
        },
        GE = function(l) {
            return l.value ? l.value : null
        },
        XL = function(l) {
            if (!l) return null;
            var E = g.Bb(B1i(l.value));
            E = g.x1(E);
            if (!E) return null;
            var e = j9(l.target, Oq_, "current");
            if (e == null) l = null;
            else {
                var d = l.show_link_icon;
                l = new qq6(E, e, d === "true" || d === "false" ? d === "true" : !0, l.pause_on_navigation != null ? l.pause_on_navigation : !0)
            }
            return l
        },
        MH6 = function(l, E, e) {
            this.type = l;
            this.trigger = E;
            this.url = e
        },
        JfK = function(l) {
            if (!l) return null;
            var E = j9(l.type, vGB),
                e = j9(l.trigger, N1K);
            l = l.url;
            l = Array.isArray(l) && l.length ? l[0] : l;
            l = XL(l ? l : null);
            return E ? new MH6(E, e, l) : null
        },
        bqB = function(l, E, e, d, C) {
            this.id = l;
            this.type = E;
            this.style = e;
            this.data = C;
            this.action = d || []
        },
        DIx = function(l, E) {
            return g.Uu(l.action, E)
        },
        pfN = function(l, E) {
            this.context = l;
            this.C = E
        },
        Kdi = function(l) {
            return l.customMessage ? S9("div", "iv-card-message", l.customMessage) : ""
        },
        zE = function(l, E) {
            l = "background-image: url(" + l + ");";
            var e = [];
            E && e.push(E);
            return {
                j: "div",
                T: "iv-card-image",
                J: {
                    style: l
                },
                S: e
            }
        },
        UI6 = function(l) {
            if (!l.metaInfo || l.metaInfo.length === 0) return "";
            var E = [];
            l = g.U(l.metaInfo);
            for (var e = l.next(); !e.done; e = l.next()) E.push(S9("li", "", e.value));
            return {
                j: "ul",
                T: "iv-card-meta-info",
                S: E
            }
        },
        S9 = function(l, E, e) {
            E ? typeof E === "string" ? E = {
                "class": E
            } : Array.isArray(E) && (E = {
                "class": E.join(" ")
            }) : E = {};
            E.dir = g.NE(e);
            return {
                j: l,
                J: E,
                zK: e
            }
        },
        mIK = function(l) {
            if (!l.customMessage) return "";
            var E = ["iv-card-action", "iv-card-primary-link"],
                e = {};
            l.RA && (E.push("iv-card-action-icon"), e.style = "background-image: url(" + l.RA + ");");
            e.dir = g.NE(l.customMessage);
            var d = [{
                j: "span",
                zK: l.customMessage
            }];
            l.showLinkIcon && (d.push("\u00a0"), d.push({
                j: "span",
                T: "iv-card-link-icon"
            }));
            return {
                j: "div",
                R4: E,
                J: e,
                S: d
            }
        },
        rs = function(l, E, e, d) {
            if (d) {
                E = g.U(E);
                for (var C = E.next(); !C.done; C = E.next()) l.C(C.value, d, e.id, e.sessionData, e.Mi.click, 5)
            }
        },
        yfo = function(l, E) {
            this.merchant = l;
            this.price = E
        },
        tHD = function(l) {
            var E;
            (E = l) && !(E = l.length > 1 ? l.charAt(0) === "/" && l.charAt(1) !== "/" : l === "/") && (E = l.replace(/^(https?:)?\/\//, "").split("/", 1), E = !E || E.length < 1 || !E[0] ? [] : E[0].toLowerCase().split(".").reverse(), E = E[0] === "com" && E[1] === "youtube" || E[0] === "be" && E[1] === "youtu");
            return E ? l.indexOf("/redirect?") === -1 : !1
        },
        HqD = function(l, E) {
            return E ? E : tHD(l) ? "current" : "new"
        },
        ws = function(l, E) {
            g.F.call(this);
            var e = this;
            this.element = l;
            this.context = E;
            this.eZ = !1;
            this.E6 = new Map;
            this.bO = new Map;
            this.context.D.addEventListener(g.zw("annotations_module"), function(d) {
                (d = e.E6.get(d)) && d.apply(e)
            });
            this.context.D.addEventListener(g.r9("annotations_module"), function(d) {
                (d = e.bO.get(d)) && d.apply(e)
            })
        },
        nG = function(l, E, e, d, C, x, Y) {
            l.context.C.listen(E, "click", function(B) {
                l.Ga(e, d, C, x || [], Y || 0, B)
            });
            l.context.C.listen(E, "touchstart", function() {
                l.eZ = !1
            });
            l.context.C.listen(E, "touchmove", function() {
                l.eZ = !0
            })
        },
        VH_ = function(l) {
            var E;
            return ((E = g.T(l, g.PF)) == null ? 0 : E.url) ? g.T(l, g.PF).url : (l = g.T(l, g.oR)) && l.videoId ? (E = "/watch?v=" + l.videoId, l.playlistId && (E += "&list=" + l.playlistId), l.index && (E += "&index=" + l.index), l.startTimeSeconds && (E += "&t=" + l.startTimeSeconds), E) : null
        },
        lL = function(l, E, e) {
            return {
                wM: (l.impressionLoggingUrlsV2s || []).map(function(d) {
                    return d.baseUrl || ""
                }),
                click: (e.loggingUrls || []).map(function(d) {
                    return d.baseUrl || ""
                }),
                close: (E.dismissLoggingUrlsV2s || []).map(function(d) {
                    return d.baseUrl || ""
                }),
                L6: (E.impressionLoggingUrlsV2s || []).map(function(d) {
                    return d.baseUrl || ""
                }),
                wO: (E.clickLoggingUrlsV2s || []).map(function(d) {
                    return d.baseUrl || ""
                })
            }
        },
        oGu = function(l, E, e) {
            ws.call(this, E, e);
            var d = this;
            this.D = l;
            this.eventId = null;
            this.oE = this.DQ = this.zN = this.G = this.isInitialized = !1;
            this.cards = [];
            this.F9 = this.Z = this.s6 = this.X = this.tO = this.C = null;
            this.o4 = [];
            this.VV = this.K = this.eB = this.WS = null;
            this.Y = 0;
            this.pJ = new g.Gv(function() {}, e.Mw.n8 ? 4E3 : 3E3);
            g.L(this, this.pJ);
            this.lO = new g.Gv(function() {});
            g.L(this, this.lO);
            this.vS = new pfN(e, function(C, x, Y, B, q, O) {
                nG(d, C, x, Y, B, q, O)
            });
            this.U = new g.W({
                j: "div",
                T: "iv-drawer",
                J: {
                    id: "iv-drawer"
                },
                S: [{
                    j: "div",
                    T: "iv-drawer-header",
                    J: {
                        "aria-role": "heading"
                    },
                    S: [{
                        j: "span",
                        T: "iv-drawer-header-text"
                    }, {
                        j: "button",
                        R4: ["iv-drawer-close-button", "ytp-button"],
                        J: {
                            "aria-label": "Hide cards",
                            tabindex: "0"
                        }
                    }]
                }, {
                    j: "div",
                    T: "iv-drawer-content"
                }]
            });
            g.L(this, this.U);
            this.W = this.U.element;
            this.JO = new g.wY(this.U, 330);
            g.L(this, this.JO);
            this.PP = g.qr("iv-drawer-header-text", this.W);
            this.V = g.qr("iv-drawer-content", this.W);
            this.addCueRange(0, e.videoData.lengthSeconds *
                1E3, "",
                function() {
                    d.zN && Eh(d, "YOUTUBE_DRAWER_AUTO_OPEN")
                },
                function() {
                    (d.zN = d.G) && eY(d)
                });
            this.hO = new g.oE(this);
            g.L(this, this.hO);
            this.D.addEventListener("videodatachange", this.GV.bind(this))
        },
        AfR = function(l, E) {
            E = E.data;
            E.autoOpenMs && l.addCueRange(E.autoOpenMs, 0x8000000000000, "", function() {
                Eh(l, "YOUTUBE_DRAWER_AUTO_OPEN")
            });
            E.autoCloseMs && l.addCueRange(E.autoCloseMs, 0x8000000000000, "", function() {
                eY(l)
            });
            var e = E.headerText;
            g.tC(l.PP, e);
            l.Z && (l.D.B("player_tooltip_data_title_killswitch") ? l.Z.setAttribute("title", e) : l.Z.setAttribute("data-tooltip-title", e));
            E.eventId && (l.eventId = E.eventId);
            l.WS = g.bG(E.trackingParams);
            l.K = g.bG(E.closeTrackingParams);
            l.eB = g.bG(E.iconTrackingParams)
        },
        QkK = function(l, E) {
            var e = E.cardId ? E.cardId : "cr:" + l.Y,
                d = l.D.N().experiments.uO("enable_error_corrections_infocard_web_client");
            if (!E.content && E.teaser.simpleCardTeaserRenderer && d) {
                var C = E.teaser.simpleCardTeaserRenderer,
                    x = E.icon ? E.icon.infoCardIconRenderer : null;
                if (C.channelAvatar && C.channelAvatar.thumbnails && C.channelAvatar.thumbnails.length > 0) var Y = d0(C.channelAvatar.thumbnails, 22, 22).url;
                E = {
                    id: e,
                    timestamp: l.Y,
                    type: "simple",
                    teaserText: g.q8(C.message),
                    teaserDurationMs: Number(E.cueRanges[0].teaserDurationMs),
                    startMs: Number(E.cueRanges[0].startCardActiveMs),
                    autoOpen: !!E.autoOpen,
                    sessionData: {},
                    sponsored: !1,
                    Mi: {},
                    gs: null,
                    El: C.trackingParams ?
                        g.bG(C.trackingParams) : null,
                    eB: x && x.trackingParams ? g.bG(x.trackingParams) : null,
                    imageUrl: "",
                    displayDomain: null,
                    showLinkIcon: !1,
                    RA: null,
                    title: "",
                    customMessage: "",
                    url: null,
                    onClickCommand: C.onTapCommand || null,
                    OG: Y
                };
                Cv(l, E)
            } else {
                var B;
                if ((B = E.content) == null ? 0 : B.simpleCardContentRenderer) {
                    if (!E.cueRanges.length) return;
                    Y = (C = E.content) == null ? void 0 : C.simpleCardContentRenderer;
                    C = E.teaser.simpleCardTeaserRenderer;
                    x = E.icon ? E.icon.infoCardIconRenderer : null;
                    E = {
                        id: e,
                        timestamp: l.Y,
                        type: "simple",
                        teaserText: g.q8(C.message),
                        teaserDurationMs: Number(E.cueRanges[0].teaserDurationMs),
                        startMs: Number(E.cueRanges[0].startCardActiveMs),
                        autoOpen: !!E.autoOpen,
                        sessionData: xn(l, e, E, Y),
                        sponsored: !1,
                        Mi: lL(Y, C, Y.command),
                        gs: Y.trackingParams ? g.bG(Y.trackingParams) : null,
                        El: C.trackingParams ? g.bG(C.trackingParams) : null,
                        eB: x && x.trackingParams ? g.bG(x.trackingParams) : null,
                        imageUrl: d0(Y.image.thumbnails, 290, 290).url,
                        displayDomain: Y.displayDomain ? g.q8(Y.displayDomain) : null,
                        showLinkIcon: !!Y.showLinkIcon,
                        RA: null,
                        title: Y.title ? g.q8(Y.title) : "",
                        customMessage: Y.callToAction ? g.q8(Y.callToAction) : "",
                        url: g.T(Y.command, g.PF).url ? XL({
                            pause_on_navigation: !l.context.videoData.isLivePlayback,
                            target: "new",
                            value: g.T(Y.command, g.PF).url
                        }) : null,
                        onClickCommand: null
                    };
                    Cv(l, E)
                } else {
                    var q;
                    if ((q = E.content) == null ? 0 : q.collaboratorInfoCardContentRenderer) {
                        if (!E.cueRanges.length) return;
                        Y = (x = E.content) == null ? void 0 : x.collaboratorInfoCardContentRenderer;
                        C = E.teaser.simpleCardTeaserRenderer;
                        x = E.icon ? E.icon.infoCardIconRenderer : null;
                        E = {
                            id: e,
                            timestamp: l.Y,
                            type: "collaborator",
                            teaserText: g.q8(C.message),
                            teaserDurationMs: Number(E.cueRanges[0].teaserDurationMs),
                            startMs: Number(E.cueRanges[0].startCardActiveMs),
                            autoOpen: !!E.autoOpen,
                            sessionData: xn(l, e, E, Y),
                            sponsored: !1,
                            Mi: lL(Y, C, Y.endpoint),
                            gs: Y.trackingParams ? g.bG(Y.trackingParams) : null,
                            El: C.trackingParams ? g.bG(C.trackingParams) : null,
                            eB: x && x.trackingParams ? g.bG(x.trackingParams) : null,
                            channelId: g.T(Y.endpoint, g.wq).browseId,
                            customMessage: Y.customText ? g.q8(Y.customText) : null,
                            profileImageUrl: d0(Y.channelAvatar.thumbnails, 290,
                                290).url,
                            title: Y.channelName ? g.q8(Y.channelName) : "",
                            metaInfo: [Y.subscriberCountText ? g.q8(Y.subscriberCountText) : ""],
                            url: XL({
                                pause_on_navigation: !l.context.videoData.isLivePlayback,
                                target: "new",
                                value: g.T(Y.endpoint, g.wq).canonicalBaseUrl ? g.T(Y.endpoint, g.wq).canonicalBaseUrl : "/channel/" + g.T(Y.endpoint, g.wq).browseId
                            }),
                            onClickCommand: null
                        };
                        Cv(l, E)
                    } else {
                        var O;
                        if ((O = E.content) == null ? 0 : O.playlistInfoCardContentRenderer) {
                            if (!E.cueRanges.length) return;
                            var M;
                            Y = (M = E.content) == null ? void 0 : M.playlistInfoCardContentRenderer;
                            C = E.teaser.simpleCardTeaserRenderer;
                            x = E.icon ? E.icon.infoCardIconRenderer : null;
                            E = {
                                id: e,
                                timestamp: l.Y,
                                type: "playlist",
                                teaserText: g.q8(C.message),
                                teaserDurationMs: Number(E.cueRanges[0].teaserDurationMs),
                                startMs: Number(E.cueRanges[0].startCardActiveMs),
                                autoOpen: !!E.autoOpen,
                                sessionData: xn(l, e, E, Y),
                                sponsored: !1,
                                Mi: lL(Y, C, Y.action),
                                gs: Y.trackingParams ? g.bG(Y.trackingParams) : null,
                                El: C.trackingParams ? g.bG(C.trackingParams) : null,
                                eB: x && x.trackingParams ? g.bG(x.trackingParams) : null,
                                jY: d0(Y.playlistThumbnail.thumbnails,
                                    258, 290).url,
                                customMessage: Y.customMessage ? g.q8(Y.customMessage) : null,
                                playlistVideoCount: g.q8(Y.playlistVideoCount),
                                title: Y.playlistTitle ? g.q8(Y.playlistTitle) : "",
                                metaInfo: [Y.channelName ? g.q8(Y.channelName) : "", Y.videoCountText ? g.q8(Y.videoCountText) : ""],
                                url: XL({
                                    pause_on_navigation: !l.context.videoData.isLivePlayback,
                                    target: "new",
                                    value: VH_(Y.action)
                                }),
                                onClickCommand: null
                            };
                            Cv(l, E)
                        } else {
                            var v;
                            if ((v = E.content) == null ? 0 : v.videoInfoCardContentRenderer) {
                                if (!E.cueRanges.length) return;
                                var N;
                                Y = (N = E.content) ==
                                    null ? void 0 : N.videoInfoCardContentRenderer;
                                C = E.teaser.simpleCardTeaserRenderer;
                                x = E.icon ? E.icon.infoCardIconRenderer : null;
                                E = {
                                    id: e,
                                    timestamp: l.Y,
                                    type: "video",
                                    teaserText: g.q8(C.message),
                                    teaserDurationMs: Number(E.cueRanges[0].teaserDurationMs),
                                    startMs: Number(E.cueRanges[0].startCardActiveMs),
                                    autoOpen: !!E.autoOpen,
                                    sessionData: xn(l, e, E, Y),
                                    sponsored: !1,
                                    Mi: lL(Y, C, Y.action),
                                    gs: Y.trackingParams ? g.bG(Y.trackingParams) : null,
                                    El: C.trackingParams ? g.bG(C.trackingParams) : null,
                                    eB: x && x.trackingParams ? g.bG(x.trackingParams) : null,
                                    jY: d0(Y.videoThumbnail.thumbnails, 258, 290).url,
                                    videoDuration: Y.lengthString ? g.q8(Y.lengthString) : null,
                                    customMessage: Y.customMessage ? g.q8(Y.customMessage) : null,
                                    title: Y.videoTitle ? g.q8(Y.videoTitle) : "",
                                    metaInfo: [Y.channelName ? g.q8(Y.channelName) : "", Y.viewCountText ? g.q8(Y.viewCountText) : ""],
                                    isLiveNow: !!Y.badge,
                                    url: XL({
                                        pause_on_navigation: !l.context.videoData.isLivePlayback,
                                        target: "new",
                                        value: VH_(Y.action)
                                    }),
                                    onClickCommand: null
                                };
                                Cv(l, E)
                            }
                        }
                    }
                }
            }
            l.Y++
        },
        d0 = function(l, E, e) {
            for (var d = -1, C = -1, x = 0; x < l.length; x++) {
                if (l[x].height ===
                    E || l[x].width === e) return l[x];
                ((l[x].height || 0) < E || (l[x].width || 0) < e) && (d < 0 || (l[d].height || 0) < (l[x].height || 0) || (l[d].width || 0) < (l[x].width || 0)) ? d = x: ((l[x].height || 0) >= E || (l[x].width || 0) >= e) && (C < 0 || (l[C].height || 0) > (l[x].height || 0) || (l[C].width || 0) > (l[x].width || 0)) && (C = x)
            }
            return l[C >= 0 ? C : d]
        },
        xn = function(l, E, e, d) {
            return {
                feature: e.feature ? e.feature : "cards",
                src_vid: l.context.videoData.videoId,
                annotation_id: E,
                ei: l.context.videoData.eventId || "",
                itct: d.trackingParams || ""
            }
        },
        ajt = function(l, E) {
            if (E = sku(l, E)) E === l.C && (l.C = null), l.D.removeCueRange(E.LW.id), g.mT(E.Ti), g.Vx(l.cards, E), l.uS(), Yn(l)
        },
        Eh = function(l, E, e) {
            if (!l.G) {
                l.JO.show();
                l.tO = new g.Gv(function() {
                    g.d4(l.context.D.getRootNode(), g.oG.IV_DRAWER_OPEN)
                }, 0);
                l.tO.start();
                l.hO.L(l.V, "mousewheel", function(Y) {
                    l.pJ.start();
                    Y.preventDefault();
                    Y = Y || window.event;
                    var B = 0;
                    Y.type == "MozMousePixelScroll" ? B = 0 == (Y.axis == Y.HORIZONTAL_AXIS) ? Y.detail : 0 : window.opera ? B = Y.detail : B = Y.wheelDelta % 120 == 0 ? "WebkitTransform" in document.documentElement.style ? window.chrome && navigator.platform.indexOf("Mac") == 0 ? Y.wheelDeltaY / -30 : Y.wheelDeltaY / -1.2 : Y.wheelDelta / -1.6 : Y.wheelDeltaY / -3;
                    if (Y = B) l.V.scrollTop += Y
                });
                l.G = !0;
                var d = g.Ki();
                d && l.WS && l.K && g.SK(d, [l.WS, l.K]);
                E = {
                    TRIGGER_TYPE: E
                };
                for (var C = g.U(l.cards), x = C.next(); !x.done; x = C.next()) x = x.value, x.d9 || (x.d9 = !0, IjH(l.context.logger, x.LW.Mi.wM, E)), d && g.SK(d, [x.LW.gs]);
                ID(l.D);
                e && (l.X = new g.Gv(function() {
                    l.s6 = l.Z;
                    l.F9.focus()
                }, 330), l.X.start())
            }
        },
        eY = function(l) {
            l.G && (l.JO.hide(), g.oU(l.hO), g.xP(l.context.D.getRootNode(), g.oG.IV_DRAWER_OPEN), l.G = !1, ID(l.D), l.X && l.X.stop(), l.X = new g.Gv(function() {
                l.s6 && (l.s6.focus(), l.s6 = null)
            }, 330), l.X.start())
        },
        fjD = function(l) {
            g.CZ(l.IE(), [g.oG.STOP_EVENT_PROPAGATION,
                "iv-drawer-manager"
            ]);
            g.lb(l.D, l.W, 5);
            l.a5();
            l.Z = g.qr("ytp-cards-button", l.D.getRootNode());
            l.F9 = g.qr("iv-drawer-close-button", l.W);
            l.isInitialized = !0
        },
        Phx = function(l) {
            l.o4.push(g.r7("iv-teaser-shown", l.YM, l));
            l.o4.push(g.r7("iv-teaser-hidden", l.IQQ, l));
            l.o4.push(g.r7("iv-teaser-clicked", l.tT, l));
            l.oE = !0
        },
        ROx = function(l, E) {
            var e;
            return E.onClickCommand && ((e = g.T(E.onClickCommand, g.Bvo)) == null ? void 0 : e.targetId) === "engagement-panel-error-corrections" ? (l.VV = E, !0) : !1
        },
        kVD = function(l, E) {
            l.VV = E;
            var e = l.D.getVideoData();
            if (!e) return !1;
            e = g.eA(e);
            if (e == null ? 0 : e.markersMap)
                for (var d, C = 0;
                    ((d = e) == null ? void 0 : d.markersMap.length) > C; C++) {
                    var x = void 0,
                        Y = (x = e) == null ? void 0 : x.markersMap[C];
                    if (Y.key === "ERROR_CORRECTION_MARKERS" && (x = void 0, (Y = (x = Y.value) == null ? void 0 : x.markers) && Y.length > 0)) return d = void 0, E.startMs = ((d = g.T(Y[0], g.IVZ)) == null ? void 0 : d.timeRangeStartMillis) || 0, l.VV = null, !0
                }
            return !1
        },
        Cv = function(l, E) {
            if (!ROx(l, E) || kVD(l, E)) {
                var e = hOo(l, E);
                if (e) {
                    var d = {
                        LW: E,
                        Ti: e.element,
                        d9: !1
                    };
                    if (E.onClickCommand) l.D.B("web_infocards_teaser_show_logging_fix") && (l.oE || Phx(l), ajt(l, E.id), e = l.findLastIndex(d), g.Zx(l.cards, e, 0, d));
                    else {
                        l.isInitialized || fjD(l);
                        ajt(l, E.id);
                        var C = l.findLastIndex(d);
                        g.Zx(l.cards, C, 0, d);
                        e.AO(l.V, C);
                        l.uS()
                    }
                    E.autoOpen ? l.addCueRange(E.startMs, 0x8000000000000, E.id, function() {
                        l.G || (l.C = d, Yn(l), Fd6(l, d), Eh(l, "YOUTUBE_DRAWER_AUTO_OPEN", !1))
                    }) : (e = l.context.D.getCurrentTime() * 1E3, e < 5E3 && e > E.startMs && Ld_(l, d), l.addCueRange(E.startMs,
                        E.startMs + 1, E.id,
                        function() {
                            Ld_(l, d)
                        }), Yn(l))
                }
            }
        },
        hOo = function(l, E) {
            switch (E.type) {
                case "simple":
                    l = l.vS;
                    var e = E.displayDomain ? {
                        j: "div",
                        T: "iv-card-image-text",
                        zK: E.displayDomain
                    } : void 0;
                    var d = mIK(E);
                    e = {
                        j: "div",
                        R4: ["iv-card"],
                        S: [{
                            j: "a",
                            T: "iv-click-target",
                            J: {
                                href: E.url ? GE(E.url) || "" : ""
                            },
                            S: [zE(E.imageUrl, e), {
                                j: "div",
                                T: "iv-card-content",
                                S: [S9("h2", void 0, E.title), d]
                            }]
                        }]
                    };
                    e = new g.W(e);
                    rs(l, g.uV("iv-click-target", e.element), E, E.url);
                    E = e;
                    break;
                case "collaborator":
                    l = l.vS;
                    e = {
                        j: "div",
                        R4: ["iv-card", "iv-card-channel"],
                        S: [{
                            j: "a",
                            R4: ["iv-click-target"],
                            J: {
                                href: GE(E.url) || "",
                                "data-ytid": E.channelId
                            },
                            S: [zE(E.profileImageUrl),
                                {
                                    j: "div",
                                    T: "iv-card-content",
                                    S: [Kdi(E), {
                                        j: "h2",
                                        T: "iv-card-primary-link",
                                        zK: E.title
                                    }, UI6(E)]
                                }
                            ]
                        }]
                    };
                    e = new g.W(e);
                    rs(l, g.uV("iv-click-target", e.element), E, E.url);
                    E = e;
                    break;
                case "playlist":
                    l = l.vS;
                    e = {
                        j: "div",
                        R4: ["iv-card", "iv-card-playlist"],
                        S: [{
                            j: "a",
                            T: "iv-click-target",
                            J: {
                                href: GE(E.url) || ""
                            },
                            S: [zE(E.jY, {
                                j: "div",
                                T: "iv-card-image-overlay",
                                S: [{
                                    j: "span",
                                    T: "iv-card-playlist-video-count",
                                    zK: E.playlistVideoCount
                                }]
                            }), {
                                j: "div",
                                T: "iv-card-content",
                                S: [Kdi(E), S9("h2", "iv-card-primary-link", E.title), UI6(E)]
                            }]
                        }]
                    };
                    e = new g.W(e);
                    rs(l, g.uV("iv-click-target", e.element), E, E.url);
                    E = e;
                    break;
                case "productListing":
                    l = l.vS;
                    var C = E.offers.length != 0;
                    e = ["iv-card"];
                    d = "";
                    var x = mIK(E);
                    C && (e.push("iv-card-product-listing"), d = "iv-card-primary-link", x = E.offers[0], C = [], x.price && C.push({
                        j: "div",
                        T: "iv-card-offer-price",
                        zK: x.price
                    }), x.merchant && C.push({
                        j: "div",
                        T: "iv-card-offer-merchant",
                        zK: x.merchant
                    }), x = {
                        j: "div",
                        S: C
                    });
                    C = E.url ? GE(E.url) || "" : "";
                    e = {
                        j: "div",
                        R4: e,
                        J: {
                            tabindex: "0"
                        },
                        S: [{
                            j: "a",
                            R4: ["iv-card-image", "iv-click-target"],
                            J: {
                                style: "background-image: url(" +
                                    E.imageUrl + ");",
                                href: C,
                                "aria-hidden": "true",
                                tabindex: "-1"
                            }
                        }, {
                            j: "div",
                            T: "iv-card-content",
                            S: [E.sponsored ? {
                                j: "div",
                                T: "iv-card-sponsored",
                                S: ["Sponsored", {
                                    j: "div",
                                    T: "iv-ad-info-container",
                                    S: [{
                                        j: "div",
                                        T: "iv-ad-info",
                                        zK: "{{adInfo}}"
                                    }, {
                                        j: "div",
                                        T: "iv-ad-info-icon-container",
                                        S: [{
                                            j: "div",
                                            T: "iv-ad-info-icon"
                                        }, {
                                            j: "div",
                                            T: "iv-ad-info-callout"
                                        }]
                                    }]
                                }]
                            } : "", {
                                j: "a",
                                T: "iv-click-target",
                                J: {
                                    href: C
                                },
                                S: [S9("h2", d, E.title), x]
                            }]
                        }]
                    };
                    e = new g.W(e);
                    d = g.bV("span");
                    g.tC(d, "You are seeing this product because we think it is relevant to the video. Google may be compensated by the merchant.");
                    e.n3(d, "adInfo");
                    rs(l, g.uV("iv-click-target", e.element), E, E.url);
                    E = e;
                    break;
                case "video":
                    l = l.vS;
                    d = E.videoDuration ? {
                        j: "span",
                        T: "iv-card-video-duration",
                        zK: E.videoDuration
                    } : void 0;
                    x = E.isLiveNow ? {
                        j: "span",
                        R4: ["yt-badge", "yt-badge-live"],
                        zK: "LIVE NOW"
                    } : null;
                    C = {
                        j: "div",
                        R4: ["iv-card", "iv-card-video"],
                        S: [{
                            j: "a",
                            T: "iv-click-target",
                            J: {
                                href: ((e = E.url) == null ? void 0 : GE(e)) || ""
                            },
                            S: [zE(E.jY, d), {
                                j: "div",
                                T: "iv-card-content",
                                S: [Kdi(E), S9("h2", "iv-card-primary-link", E.title), UI6(E), x]
                            }]
                        }]
                    };
                    e = new g.W(C);
                    rs(l, g.uV("iv-click-target",
                        e.element), E, E.url);
                    E = e;
                    break;
                default:
                    return null
            }
            return E
        },
        cfN = function(l) {
            if (l.C) return l.C.LW.type === "productListing";
            if (l.D.B("enable_wn_infocards")) {
                var E;
                return !((E = l.cards) == null || !E.length) && g.Uj(l.cards, function(e) {
                    return e.LW.type === "productListing"
                })
            }
            return g.Uj(l.cards, function(e) {
                return e.LW.type === "productListing"
            })
        },
        Yn = function(l) {
            g.u9(l.D.getRootNode(), "ytp-cards-shopping-active", cfN(l))
        },
        Ld_ = function(l, E) {
            if (!g.ec(l.D.getRootNode(), "ytp-cards-teaser-shown")) {
                if (l.C !== E) {
                    var e = g.Ki(),
                        d = l.C ? l.C.LW.eB : l.eB;
                    e && d && g.zF(e, [d]);
                    l.C = E;
                    Yn(l)
                }(e = l.isInitialized && l.IE().style.display == "none") || (e = l.context.D.getPlayerState(), d = e === 0 && l.context.D.getCurrentTime() === 0, e = !(e === 1 || e === 3 || d));
                if (!e && E.LW.teaserDurationMs) {
                    var C;
                    e = {
                        teaserText: E.LW.teaserText,
                        durationMs: E.LW.teaserDurationMs,
                        onClickCommand: E.LW.onClickCommand,
                        OG: (C = E.LW.OG) != null ? C : null
                    };
                    l.D.OW(!0, e)
                }
                l.lO.isActive() || ((!l.G || !l.pJ.isActive() && l.DQ) && Fd6(l, E), l.lO.start(910 + E.LW.teaserDurationMs))
            }
        },
        Fd6 = function(l, E) {
            l.U.qw ? (E = new ht([0,
                l.V.scrollTop
            ], [0, E.Ti.offsetTop], 600, Wu6), l.context.G.listen(E, "animate", function(e) {
                l.V.scrollTop = e.y
            }), l.context.G.listen(E, "finish", function(e) {
                l.V.scrollTop = e.y
            }), E.play()) : (l.U.SD(!0), l.V.scrollTop = E.Ti.offsetTop, l.U.SD(!1))
        },
        uL = function(l) {
            return l.C && l.C.LW ? l.C.LW : l.cards[0] && l.cards[0].LW ? l.cards[0].LW : null
        },
        sku = function(l, E) {
            return g.Uu(l.cards, function(e) {
                return e.LW.id === E
            })
        },
        BT = function(l, E, e) {
            ws.call(this, l, E);
            this.annotation = e;
            this.isActive = !1
        },
        iqo = function(l) {
            var E = l.annotation.data;
            "start_ms" in E && "end_ms" in E && l.addCueRange(Number(E.start_ms), Number(E.end_ms), l.annotation.id, function() {
                l.show()
            }, function() {
                l.hide()
            })
        },
        qm = function(l, E, e) {
            BT.call(this, l, E, e);
            this.V = null;
            this.Y = !1;
            this.G = null;
            this.W = !1;
            this.C = this.X = this.Z = null
        },
        ZqR = function(l, E) {
            var e = e === void 0 ? 0 : e;
            var d = hki(E).width;
            g.rv(E, d);
            e = new TEi(E, [d, E.offsetTop], [d - d - e, E.offsetTop], 200, gxo);
            g.L(l, e);
            l.context.G.listen(e, "begin", function() {
                g.dk(E, !0)
            });
            e.play()
        },
        gG5 = function(l, E) {
            if (E.channel_name) {
                var e = l.createElement({
                        j: "div",
                        R4: ["iv-branding-context-name"],
                        zK: E.channel_name
                    }),
                    d = l.createElement({
                        j: "div",
                        R4: ["iv-branding-context-subscribe"]
                    }),
                    C = E.standalone_subscribe_button_data;
                C && (l.C = new g.Cl(C.subscribeText, C.subscribeCount, C.unsubscribeText, C.unsubscribeCount, !!C.enabled, !!C.classic, E.channel_id, !!C.subscribed, C.feature, E.session_data.itct, l.context.D, !1), l.C.AO(d));
                var x = l.createElement({
                        j: "div",
                        R4: ["iv-branding-context-subscribe-caret"]
                    }),
                    Y = l.createElement({
                        j: "div",
                        R4: ["branding-context-container-inner"]
                    });
                Y.appendChild(x);
                Y.appendChild(e);
                Y.appendChild(d);
                g.dk(Y, !1);
                var B = l.createElement({
                    j: "div",
                    R4: ["branding-context-container-outer"]
                });
                B.appendChild(Y);
                g.W_(B, "right", E.image_width + "px");
                g.pQ(l.IE(), B);
                l.G = new g.Gv(function() {
                    $It(l, Y, B)
                }, 500);
                g.L(l, l.G);
                l.context.C.listen(l.IE(), "mouseover", function() {
                    T16(l, Y, B, x, E.image_height)
                });
                l.context.C.listen(l.IE(), "mouseout", function() {
                    l.G.start()
                })
            }
        },
        T16 = function(l, E, e, d, C) {
            l.G.stop();
            if (!l.W) {
                var x = g.es(E);
                l.C || (E.style.width = g.z_(x.width, !0), e.style.width = g.z_(x.width, !0));
                g.W_(d, "top", x.height - Math.max(Math.min(x.height, C) / 2 + 10, 20) + "px");
                g.W_(d, "right", "1px");
                l.W = !0;
                g.dk(E, !0);
                l.Z = new g.Gv(function() {
                    g.d4(this.IE(), "iv-branding-active")
                }, 0, l);
                l.Z.start()
            }
        },
        $It = function(l, E, e) {
            g.xP(l.IE(), "iv-branding-active");
            l.X = new g.Gv(function() {
                g.dk(E, !1);
                l.C || (e.style.width = g.z_(0, !0))
            }, 250);
            l.X.start();
            l.W = !1
        },
        WdH = function(l, E, e, d, C, x, Y) {
            this.C = l;
            this.G = E;
            this.Mw = e;
            this.videoData = d;
            this.logger = C;
            this.D = x;
            this.V = Y
        },
        jkD = function(l, E, e) {
            BT.call(this, l, E, e);
            var d = this;
            this.K = this.isCollapsed = this.U = !1;
            this.X = 5E3;
            this.V = this.G = this.C = this.W = null;
            this.Y = this.createElement({
                j: "div",
                R4: ["iv-promo-contents"]
            });
            this.Z = new g.Gv(function() {
                d.C.setAttribute("aria-hidden", "true");
                g.dk(d.G, !1);
                g.dk(d.V, !0)
            }, 700, this);
            g.L(this, this.Z)
        },
        XfR = function(l) {
            var E = l.annotation.data;
            if (l.annotation.style === "cta") var e = 6;
            else if (l.annotation.style === "video" || l.annotation.style === "playlist") e = 7;
            l.X = E.collapsedelay_ms || l.X;
            var d = ["iv-promo", "iv-promo-inactive"];
            l.IE().setAttribute("aria-hidden", "true");
            l.IE().setAttribute("aria-label", "Promotion");
            l.IE().tabIndex = 0;
            var C = l.annotation.s0(),
                x = E.image_url;
            if (x) {
                var Y = l.createElement({
                    j: "div",
                    R4: ["iv-promo-img", "iv-click-target"]
                });
                x = l.createElement({
                    j: "img",
                    J: {
                        src: x,
                        "aria-hidden": "true"
                    }
                });
                Y.appendChild(x);
                E.video_duration && !E.is_live ?
                    (x = l.createElement({
                        j: "span",
                        T: "iv-promo-video-duration",
                        zK: E.video_duration
                    }), Y.appendChild(x)) : E.playlist_length && (x = l.createElement({
                        j: "span",
                        T: "iv-promo-playlist-length",
                        zK: E.playlist_length.toString()
                    }), Y.appendChild(x));
                C && nG(l, Y, C, l.annotation.id, E.session_data, void 0, e)
            }
            C ? (x = l.createElement({
                j: "a",
                T: "iv-promo-txt"
            }), g.Mp(x, GE(C)), l.C = x) : l.C = l.createElement({
                j: "div",
                T: "iv-promo-txt"
            });
            switch (l.annotation.style) {
                case "cta":
                case "website":
                    var B = l.createElement({
                        j: "p",
                        S: [{
                            j: "strong",
                            zK: E.text_line_1
                        }]
                    });
                    var q = l.createElement({
                        j: "p",
                        S: [{
                            j: "span",
                            T: "iv-promo-link",
                            zK: E.text_line_2
                        }]
                    });
                    if (x = E.text_line_3) {
                        d.push("iv-promo-website-card-cta-redesign");
                        var O = l.createElement({
                            j: "button",
                            R4: ["iv-promo-round-expand-icon", "ytp-button"]
                        });
                        x = l.createElement({
                            j: "button",
                            R4: ["iv-button", "iv-promo-button"],
                            S: [{
                                j: "span",
                                T: "iv-button-content",
                                zK: x
                            }]
                        });
                        var M = l.createElement({
                            j: "div",
                            T: "iv-promo-button-container"
                        });
                        M.appendChild(x);
                        C && nG(l, l.IE(), C, l.annotation.id, E.session_data, void 0, e)
                    }
                    g.d4(l.C, "iv-click-target");
                    C && nG(l, l.C, C, l.annotation.id, E.session_data, void 0, e);
                    break;
                case "playlist":
                case "video":
                    B = l.createElement({
                        j: "p",
                        S: [{
                            j: "span",
                            zK: E.text_line_1
                        }]
                    }), q = l.createElement({
                        j: "p",
                        S: [{
                            j: "strong",
                            zK: E.text_line_2
                        }]
                    }), E.is_live && (B = q, q = l.createElement({
                        j: "span",
                        R4: ["yt-badge", "iv-promo-badge-live"],
                        zK: "LIVE NOW"
                    })), g.d4(l.C, "iv-click-target"), C && nG(l, l.C, C, l.annotation.id, E.session_data, void 0, e), d.push("iv-promo-video")
            }
            B && l.C.appendChild(B);
            q && l.C.appendChild(q);
            l.Y.appendChild(l.C);
            M && l.Y.appendChild(M);
            e = l.createElement({
                j: "div",
                T: "iv-promo-actions"
            });
            l.V = l.createElement({
                j: "button",
                R4: ["iv-promo-expand", "ytp-button"]
            });
            l.V.title = "Expand";
            l.context.C.listen(l.V, "click", function(v) {
                GVW(l, 5E3, v)
            });
            e.appendChild(l.V);
            g.dk(l.V, !1);
            l.context.C.listen(l.IE(), "mouseover", l.lF, l);
            l.context.C.listen(l.IE(), "mouseout", l.xU, l);
            l.context.C.listen(l.IE(), "touchend", function(v) {
                GVW(l, 5E3, v)
            });
            l.G = l.createElement({
                j: "button",
                R4: ["iv-promo-close", "ytp-button"]
            });
            l.G.title = "Close";
            l.context.C.listen(l.G, "click", l.annotation.style === "cta" && E.text_line_3 ? l.Nv : l.yv, l);
            e.appendChild(l.G);
            g.CZ(l.IE(), d);
            Y && (g.pQ(l.IE(), Y), O && Y.appendChild(O));
            g.pQ(l.IE(), l.Y);
            g.pQ(l.IE(), e)
        },
        GVW = function(l, E, e) {
            e.stopPropagation();
            Sqt(l);
            zOu(l, E);
            l.C.focus()
        },
        rf_ = function(l) {
            l.isCollapsed || l.K || l.W || (g.d4(l.IE(), "iv-promo-collapsed"), l.isCollapsed = !0, l.Z.start())
        },
        Sqt = function(l) {
            l.Z.stop();
            l.isCollapsed && (g.YP(l.IE(), ["iv-promo-collapsed", "iv-promo-collapsed-no-delay"]), l.isCollapsed = !1, l.C && l.C.removeAttribute("aria-hidden"), g.dk(l.V, !1), g.dk(l.G, !0))
        },
        zOu = function(l, E) {
            l.W || (l.W = g.Lk(function() {
                wfi(this);
                rf_(this)
            }, E, l))
        },
        wfi = function(l) {
            l.W && (g.wr.clearTimeout(l.W), l.W = null)
        },
        nGR = function(l) {
            this.D = l
        },
        IjH = function(l, E, e) {
            E && (e ? Oh(l, E.map(function(d) {
                return g.sn(d, e)
            })) : Oh(l, E))
        },
        Oh = function(l, E, e, d) {
            var C = 1,
                x = void 0,
                Y = -1;
            if (e) {
                var B = !1;
                x = function() {
                    C--;
                    C || B || (clearTimeout(Y), B = !0, e())
                };
                Y = setTimeout(function() {
                    B = !0;
                    e()
                }, 1E3)
            }
            E = g.U(E || []);
            for (var q = E.next(); !q.done; q = E.next()) q = q.value, C++, g.P3(q, x);
            d && (C++, d !== 0 && l.D.sendVideoStatsEngageEvent(d, x))
        },
        l5B = function(l) {
            g.Vc.call(this, l);
            var E = this;
            this.o4 = this.K = !1;
            this.loadNumber = 0;
            this.X = {};
            this.logger = new nGR(this.player);
            this.W = new g.oE(this);
            this.Z = this.Y = null;
            this.events = new g.oE(this);
            this.EQ = this.U = this.C = null;
            this.VV = [];
            g.L(this, this.W);
            this.W.L(this.player, "onVideoAreaChange", function() {
                E.publish("onVideoAreaChange")
            });
            this.W.L(this.player, "onHideControls", function() {
                E.publish("onHideControls")
            });
            this.W.L(this.player, "onShowControls", function() {
                E.publish("onShowControls")
            });
            this.W.L(this.player, "resize", function(d) {
                E.publish("resize", d)
            });
            this.W.L(this.player, "presentingplayerstatechange", function(d) {
                E.publish("presentingplayerstatechange", d)
            });
            this.subscribe("presentingplayerstatechange", this.Th, this);
            this.subscribe("resize", this.Fh, this);
            this.player.N().DQ.subscribe("vast_info_card_add", this.Uj, this);
            g.L(this, this.events);
            this.vS = this.createElement({
                j: "div",
                T: "video-custom-annotations"
            });
            this.V = new g.W({
                j: "div",
                R4: ["ytp-player-content", "ytp-iv-player-content"]
            });
            g.L(this, this.V);
            g.lb(this.player, this.V.element, 4);
            this.V.hide();
            this.G = new g.W({
                j: "div",
                R4: ["ytp-iv-video-content"]
            });
            g.L(this, this.G);
            l = this.createElement({
                j: "div",
                T: "video-annotations"
            });
            l.appendChild(this.vS);
            this.G.element.appendChild(l);
            this.f_() && this.load();
            var e = this.createElement({
                j: "style"
            });
            (g.Y$("HEAD")[0] || document.body).appendChild(e);
            this.addOnDisposeCallback(function() {
                g.mT(e)
            });
            if (l = e.sheet) l.insertRule(".iv-promo .iv-promo-contents .iv-promo-txt .iv-promo-link:after {background:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABQAAAAUBAMAAAB/pwA+AAAABGdBTUEAALGPC/xhBQAAACBjSFJNAAB6JgAAgIQAAPoAAACA6AAAdTAAAOpgAAA6mAAAF3CculE8AAAAHlBMVEVMaXH////////////////////////////////////Z6AnKAAAACXRSTlMA+/A2IuI1mJIldm0CAAAAAWJLR0QB/wIt3gAAAEVJREFUCNdjYGCYCQUMBJlACOIzIDElIcyZkwxgojOVWWDMSQauMKYySySUOSnBdSaUOZ0lEsac2YqwYiZ+JhwgM7E5HACgzVCI/YJ59AAAAABJRU5ErkJggg==) no-repeat center;background-size:10px;width:10px;height:10px}",
                0), l.insertRule(".iv-promo .iv-promo-actions .iv-promo-close:after {background:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAkAAAAJBAMAAAASvxsjAAAABGdBTUEAALGPC/xhBQAAACBjSFJNAAB6JgAAgIQAAPoAAACA6AAAdTAAAOpgAAA6mAAAF3CculE8AAAAJFBMVEVMaXH///////////////////////////////////////////9tKdXLAAAAC3RSTlMAVaQDpaimqQbl5rjXUFUAAAABYktHRAH/Ai3eAAAAPUlEQVQI12MQMmAwEmDwDmaOTmAw39663YCBuXp2MQMDQ+fOBgYG5ujVwQwMptvbgeLaxczVCQwiBgxmAgBkXg1FN5iwiAAAAABJRU5ErkJggg==) no-repeat center;background-size:9px;width:9px;height:9px}",
                0), l.insertRule(".iv-promo .iv-promo-actions .iv-promo-expand:after {background:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAQAAAAJBAMAAADnQZCTAAAABGdBTUEAALGPC/xhBQAAACBjSFJNAAB6JgAAgIQAAPoAAACA6AAAdTAAAOpgAAA6mAAAF3CculE8AAAAJFBMVEVMaXHMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMz////eMKB4AAAAC3RSTlMAOpE7k5Uvj5kpfRaQSaQAAAABYktHRAsf18TAAAAAHklEQVQI12MQYGBQZmBwTWCo0GSo6AKRQDZQRIABADXXA/UkIpvtAAAAAElFTkSuQmCC) no-repeat center;background-size:4px 9px;width:4px;height:9px}", 0), l.insertRule(".iv-promo-website-card-cta-redesign .iv-promo-round-expand-icon:after {background:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAQAAAD9CzEMAAAAAmJLR0QA/4ePzL8AAAAJcEhZcwAACxMAAAsTAQCanBgAAAAHdElNRQfgCgUUEztsNfqrAAAAXklEQVRYw+3Uuw2AQAwEUUNXfBpDIvBRMhQwJJAScNrA0r4CdiQHjjAzK4NGKucPAFmCnZcmwcTphBNO9CTGH4VB+/Zm6YlYis9fhedXz38FNvFriCCl808iw8ysrBu65gCeuV/CfgAAAABJRU5ErkJggg==) no-repeat center;background-size:18px 18px;width:18px;height:18px}",
                0), l.insertRule(".iv-card-link-icon {background:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABIAAAASBAMAAACk4JNkAAAABGdBTUEAALGPC/xhBQAAACBjSFJNAAB6JgAAgIQAAPoAAACA6AAAdTAAAOpgAAA6mAAAF3CculE8AAAAGFBMVEVMaXG7u7u7u7u7u7u7u7u7u7u7u7v///+WKTAlAAAABnRSTlMAFdQWbGj9GiOuAAAAAWJLR0QHFmGI6wAAAEhJREFUCNdjYACBNCBgQGMxMKrBWEJJaRAJRjVlKEsoSQDIAqtSZICwgEIQFkgIZBRECMxiBqsCsVjAqsCygQwwFgMeFgQgswBg2xjLrfC4mgAAAABJRU5ErkJggg==) no-repeat center;background-size:9px;width:9px;height:9px}", 0), l.insertRule(".iv-card-playlist-video-count:after {background:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYBAMAAAASWSDLAAAABGdBTUEAALGPC/xhBQAAACBjSFJNAAB6JgAAgIQAAPoAAACA6AAAdTAAAOpgAAA6mAAAF3CculE8AAAAJFBMVEVMaXH///////////////////////////////////////////9tKdXLAAAAC3RSTlMAvDeyLvxYtDK9Ogx4T1QAAAABYktHRAH/Ai3eAAAAK0lEQVQY02NgoBjshgO8HJoYwKiAMGAD92YHJM7uMCTO9gaEHs4FlPuZAQC8Fj8x/xHjxwAAAABJRU5ErkJggg==) no-repeat center;background-size:24px;width:24px;height:24px}",
                0), l.insertRule(".iv-drawer-close-button:after {background:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAwAAAAMAgMAAAArG7R0AAAABGdBTUEAALGPC/xhBQAAACBjSFJNAAB6JgAAgIQAAPoAAACA6AAAdTAAAOpgAAA6mAAAF3CculE8AAAACVBMVEVMaXH////////OZTV/AAAAAnRSTlMAoKBFbtAAAAABYktHRAH/Ai3eAAAAKUlEQVQI12MIYGBlSGGQBMIUBjbHCQyM0xwYGDIZwBjEBomB5EBqgGoBolQGzYuy51cAAAAASUVORK5CYII=) no-repeat center;background-size:12px;width:12px;height:12px}", 0), l.insertRule(".iv-ad-info-icon {background:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAsAAAALCAMAAACecocUAAAABGdBTUEAALGPC/xhBQAAACBjSFJNAAB6JgAAgIQAAPoAAACA6AAAdTAAAOpgAAA6mAAAF3CculE8AAAAVFBMVEVMaXGUlJSYmJiZmZmYmJiXl5eZmZmZmZmWlpaVlZWOjo6ZmZmSkpKXl5eYmJiYmJiZmZmZmZmZmZmZmZmYmJiJiYmXl5eZmZmYmJiWlpaZmZn///+81lbeAAAAGnRSTlMAE5DM80DliTMMEjccWIM5p1UjaTQNgB5cLlr5mgUAAAABYktHRBsCYNSkAAAAVElEQVQI102NRw7AIBADhw7ppIf/PzQLJ/ZgWSNrFlDaWKMVcs6HmGLwTqjEME6CFDrAXBYIGhNh3TJEg02wHydctvFc7sbrvnXZV8/zfs3T+7u/P7CrAso35YfPAAAAAElFTkSuQmCC) no-repeat center;background-size:11px;width:11px;height:11px}",
                0), l.insertRule(".annotation-close-button {background:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQBAMAAADt3eJSAAAABGdBTUEAALGPC/xhBQAAACBjSFJNAAB6JgAAgIQAAPoAAACA6AAAdTAAAOpgAAA6mAAAF3CculE8AAAALVBMVEVMaXEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA/Pz9aWloBAQGZmZlbW1v///+X9wUzAAAACHRSTlMANprf+g6lyRmB9hUAAAABYktHRA5vvTBPAAAAWUlEQVQI12NgYBAycVZkAIKwDiBIZWBgrQAx2gMY2DrAIIFBomPWju6VHY0MGh1rbu891dHEYNGx9+yd2x3NDB4d3XfO7uhoQTDgUnDFcO1wA+FWwC2FOQMAdKg6tUSAFEAAAAAASUVORK5CYII=) no-repeat center}", 0), l.insertRule(".annotation-link-icon {background:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACIAAAAiCAMAAAANmfvwAAAABGdBTUEAALGPC/xhBQAAACBjSFJNAAB6JgAAgIQAAPoAAACA6AAAdTAAAOpgAAA6mAAAF3CculE8AAAAUVBMVEVMaXH////////////////////////////////////////////////////////////////////////////////////////////////////////JzkR1AAAAGnRSTlMAfXf+c3xsdGdv/GJoXPtXXflSVk5L7DBH9VeFfsQAAAABYktHRAH/Ai3eAAAAgElEQVQ4y93SSQ6AIAwFULSOOOJs739Qf9SF0VA2uNCu+psHaQJK7cVCqY+Rg92PXA++Q84KnCR03UIRJrFEKMEgZYFQhpyzQHSBWJJAdIVUENtJ3SC0mu3EdOh7zXZiBrRdzQLJ0Y1GfOlpVstD3HaZktX9X/gvRCxvxL6FR7IBS1RTM5xIpLoAAAAASUVORK5CYII=) no-repeat center}",
                0)
        },
        Ect = function(l) {
            l = l.createElement({
                j: "div",
                R4: ["annotation", "annotation-type-custom"]
            });
            g.dk(l, !1);
            return l
        },
        ewo = function(l, E) {
            E = !E.isCued() && !g.G(E, 1024);
            l.V.SD(E);
            l.G.SD(E)
        },
        dFx = function(l, E, e) {
            l.K = !0;
            l.Z = g.yD(E, e)
        },
        Ck_ = function(l, E) {
            for (var e = {}, d = g.U(E.attributes), C = d.next(); !C.done; C = d.next()) C = C.value, e[C.name] = C.nodeValue;
            for (d = 0; d < E.childNodes.length; d++)
                if (C = E.childNodes[d], g.xi(C) && C.nodeType == 1) {
                    if (e[C.tagName]) var x = e[C.tagName];
                    else if (C.tagName === "data") {
                        C.childNodes.length > 0 && (x = C.childNodes[0].nodeValue, e[C.tagName] = typeof x === "string" ? x.trim() : x);
                        continue
                    } else x = [], e[C.tagName] = x;
                    C && C.tagName === "TEXT" ? C.childNodes.length === 1 && C.childNodes[0].nodeType === 3 ? x.push(C.childNodes[0].nodeValue) : x.push("") : C && x.push(Ck_(l, C))
                }
            return e
        },
        BNK = function(l) {
            var E = l.player.getVideoData();
            if (E.hO) {
                var e = l.player.N().DQ.get(E.videoId);
                if (e) {
                    var d = {
                        format: "XML",
                        urlParams: {},
                        method: "POST",
                        withCredentials: !0,
                        onFinish: function(C, x, Y) {
                            C = l.loadNumber;
                            x = E.videoId;
                            l.loaded && l.loadNumber === C && l.player.getVideoData().videoId === x && (Y = g.Ox(Y) && Y.responseXML ? Y.responseXML : null) && xF_(l, Y)
                        }
                    };
                    g.zZ() && (d.onFinish = Ylu(l, d.onFinish));
                    d.postParams = {
                        ic_only: "1"
                    };
                    uGK(d, e);
                    l.K = !0;
                    g.yD(E.hO, d)
                }
            }
        },
        uGK = function(l, E) {
            l.method = "POST";
            l.postParams = l.postParams || {};
            E.UH && (l.postParams.ic_coll = E.UH);
            E.w6 && (l.postParams.ic_xml = E.w6);
            E.ea && (l.postParams.ic_track = E.ea)
        },
        qlD = function(l) {
            var E = new g.W({
                j: "div"
            });
            g.dk(E.element, !1);
            var e = new oGu(l.player, E.element, Mm(l));
            g.L(e, E);
            E.AO(l.V.element);
            e.UM();
            return e
        },
        Mau = function(l, E) {
            var e, d;
            if (E = (e = E.getWatchNextResponse()) == null ? void 0 : (d = e.cards) == null ? void 0 : d.cardCollectionRenderer) l.o4 = !0, OtW(l, E), E.headerText && l.EQ && (e = g.q8(E.headerText), l.player.B("player_tooltip_data_title_killswitch") ? l.EQ.setAttribute("title", e) : l.EQ.setAttribute("data-tooltip-title", e))
        },
        Mm = function(l) {
            if (!l.U) {
                var E = new jVx(l);
                g.L(l, E);
                var e = new g.DI(l);
                g.L(l, e);
                l.U = new WdH(E, e, l.player.N(), l.player.getVideoData(), l.logger, l.player, l.Vm)
            }
            return l.U
        },
        xF_ = function(l, E) {
            var e = !1,
                d = E.getElementsByTagName("annotations");
            if (d && !(d.length < 1) && (d = d[0].getAttribute("itct"))) {
                var C = g.Ki();
                if (C) {
                    var x = g.pi();
                    x && g.Xs(g.c2)(void 0, C, x, [g.bG(d)])
                }
            }
            E = E.getElementsByTagName("annotation");
            for (d = 0; d < E.length; d++) {
                x = Ck_(l, E[d]);
                C = null;
                try {
                    if (x) {
                        var Y = x.id,
                            B = /.+/;
                        var q = typeof Y === "string" && B != null && Y != null && Y.match(B) ? Y : "";
                        var O = j9(x.type, vcR),
                            M = j9(x.style, NNu),
                            v = B1i(x.data),
                            N = v.length !== 0 ? JSON.parse(v) : {};
                        var J = x.action;
                        x = JfK;
                        if (J == null) var b = null;
                        else if (g.Co(J)) {
                            B = [];
                            for (var m = g.U(J), H = m.next(); !H.done; H = m.next()) {
                                var Q = x(H.value);
                                Q && B.push(Q)
                            }
                            b = B
                        } else {
                            var A = x(J);
                            b = A ? [A] : []
                        }
                        C = q && O ? new bqB(q, O, M, b, N) : null
                    } else C = null
                } catch (qo) {}
                if (C)
                    if (C.type === "branding" || C.type === "promotion") {
                        x = l;
                        B = C;
                        var f = Ect(x),
                            h = null;
                        switch (B.type) {
                            case "branding":
                                if (x.player.N().us) break;
                                x.player.B("web_player_overlay_positioned_layout") ? (f.setAttribute("data-overlay-order", "11"), x.player.Yy(f, 4, !0)) : x.V.element.appendChild(f);
                                h = new qm(f, Mm(x), B);
                                break;
                            case "promotion":
                                g.lb(x.player, f, 4), h = new jkD(f, Mm(x), B)
                        }
                        h && h.UM();
                        if (x = h) g.L(l, x), l.X[C.id] = x
                    } else if (C.type ===
                    "card" || C.type === "drawer") {
                    l.C || (l.C = qlD(l), g.L(l, l.C));
                    if (C.type === "card") {
                        f = l.C;
                        var Z = (e = C) && e.data && e.data.card_type;
                        C = e.data;
                        if (Z) switch (x = C.tracking || {}, x = {
                            wM: x.impression,
                            click: x.click,
                            close: x.close,
                            L6: x.teaser_impression,
                            wO: x.teaser_click
                        }, B = C.tracking_params || {}, h = null, Z) {
                            case "collaborator":
                                e = {
                                    id: e.id,
                                    timestamp: C.timestamp || 0,
                                    type: C.card_type,
                                    teaserText: C.teaser_text,
                                    teaserDurationMs: C.teaser_duration_ms,
                                    startMs: C.start_ms,
                                    autoOpen: C.auto_open || !1,
                                    sessionData: C.session_data || {},
                                    sponsored: C.sponsored ||
                                        !1,
                                    Mi: x,
                                    gs: B.card ? g.bG(B.card) : null,
                                    El: B.teaser ? g.bG(B.teaser) : null,
                                    eB: B.icon ? g.bG(B.icon) : null,
                                    channelId: C.channel_id,
                                    customMessage: C.custom_message ? C.custom_message : null,
                                    profileImageUrl: C.image_url,
                                    title: C.title,
                                    metaInfo: C.meta_info,
                                    url: XL({
                                        pause_on_navigation: C.pause_on_navigation,
                                        target: C.target || "new",
                                        value: C.url
                                    }),
                                    onClickCommand: null
                                };
                                Cv(f, e);
                                break;
                            case "playlist":
                                e = {
                                    id: e.id,
                                    timestamp: C.timestamp || 0,
                                    type: C.card_type,
                                    teaserText: C.teaser_text,
                                    teaserDurationMs: C.teaser_duration_ms,
                                    startMs: C.start_ms,
                                    autoOpen: C.auto_open || !1,
                                    sessionData: C.session_data || {},
                                    sponsored: C.sponsored || !1,
                                    Mi: x,
                                    gs: B.card ? g.bG(B.card) : null,
                                    El: B.teaser ? g.bG(B.teaser) : null,
                                    eB: B.icon ? g.bG(B.icon) : null,
                                    jY: C.image_url,
                                    playlistVideoCount: C.playlist_video_count,
                                    customMessage: C.custom_message ? C.custom_message : null,
                                    title: C.title,
                                    metaInfo: C.meta_info,
                                    url: XL({
                                        pause_on_navigation: C.pause_on_navigation,
                                        target: C.target || "new",
                                        value: C.url
                                    }),
                                    onClickCommand: null
                                };
                                Cv(f, e);
                                break;
                            case "productListing":
                                C.signin_url && (h = XL({
                                    target: "current",
                                    value: C.signin_url
                                }));
                                Z = [];
                                for (var r = C.offers || [], X = 0; X < r.length; X++) Z.push(new yfo(g.Pb(r[X].merchant), g.Pb(r[X].price)));
                                e = {
                                    id: e.id,
                                    timestamp: C.timestamp || 0,
                                    type: C.card_type,
                                    teaserText: C.teaser_text,
                                    teaserDurationMs: C.teaser_duration_ms,
                                    startMs: C.start_ms,
                                    autoOpen: C.auto_open || !1,
                                    sessionData: C.session_data || {},
                                    sponsored: C.sponsored || !1,
                                    Mi: x,
                                    gs: B.card ? g.bG(B.card) : null,
                                    El: B.teaser ? g.bG(B.teaser) : null,
                                    eB: B.icon ? g.bG(B.icon) : null,
                                    imageUrl: C.image_url,
                                    displayDomain: C.display_domain ? C.display_domain : null,
                                    showLinkIcon: !!C.show_link_icon,
                                    RA: C.button_icon_url ? C.button_icon_url : null,
                                    title: C.title,
                                    customMessage: C.custom_message ? C.custom_message : null,
                                    url: XL({
                                        pause_on_navigation: C.pause_on_navigation,
                                        target: C.target || "new",
                                        value: C.url
                                    }),
                                    hK2: h,
                                    Bh9: C.signin_title ? C.signin_title : void 0,
                                    sVS: C.signin_message ? C.signin_message : void 0,
                                    offers: Z,
                                    onClickCommand: null
                                };
                                Cv(f, e);
                                break;
                            case "simple":
                                e = {
                                    id: e.id,
                                    timestamp: C.timestamp || 0,
                                    type: C.card_type,
                                    teaserText: C.teaser_text,
                                    teaserDurationMs: C.teaser_duration_ms,
                                    startMs: C.start_ms,
                                    autoOpen: C.auto_open || !1,
                                    sessionData: C.session_data || {},
                                    sponsored: C.sponsored || !1,
                                    Mi: x,
                                    gs: B.card ? g.bG(B.card) : null,
                                    El: B.teaser ? g.bG(B.teaser) : null,
                                    eB: B.icon ? g.bG(B.icon) : null,
                                    imageUrl: C.image_url,
                                    displayDomain: C.display_domain ? C.display_domain : null,
                                    showLinkIcon: !!C.show_link_icon,
                                    RA: C.button_icon_url ? C.button_icon_url : null,
                                    title: C.title,
                                    customMessage: C.custom_message ? C.custom_message : null,
                                    url: XL({
                                        pause_on_navigation: C.pause_on_navigation,
                                        target: C.target || "new",
                                        value: C.url
                                    }),
                                    onClickCommand: null
                                };
                                Cv(f, e);
                                break;
                            case "video":
                                e = {
                                    id: e.id,
                                    timestamp: C.timestamp || 0,
                                    type: C.card_type,
                                    teaserText: C.teaser_text,
                                    teaserDurationMs: C.teaser_duration_ms,
                                    startMs: C.start_ms,
                                    autoOpen: C.auto_open || !1,
                                    sessionData: C.session_data || {},
                                    sponsored: C.sponsored || !1,
                                    Mi: x,
                                    gs: B.card ? g.bG(B.card) : null,
                                    El: B.teaser ? g.bG(B.teaser) : null,
                                    eB: B.icon ? g.bG(B.icon) : null,
                                    jY: C.image_url,
                                    videoDuration: C.video_duration || null,
                                    customMessage: C.custom_message ? C.custom_message : null,
                                    title: C.title,
                                    metaInfo: C.meta_info,
                                    isLiveNow: !!C.is_live_now,
                                    url: XL({
                                        pause_on_navigation: C.pause_on_navigation,
                                        target: C.target || "new",
                                        value: C.url
                                    }),
                                    onClickCommand: null
                                }, Cv(f, e)
                        }
                    } else AfR(l.C, C);
                    e = !0
                }
            }
            e && (ID(l.player), l.Fh())
        },
        OtW = function(l, E) {
            var e = !1;
            l.C || (l.C = qlD(l), g.L(l, l.C));
            for (var d = g.U(E.cards || []), C = d.next(); !C.done; C = d.next()) C = C.value, C.cardRenderer && (QkK(l.C, C.cardRenderer), e = !0);
            if (e) {
                var x;
                (x = l.player.getVideoData()) != null && g.xL(x) || (e = l.C, d = E.headerText ? g.q8(E.headerText) : "", g.tC(e.PP, d), e.Z && (e.D.B("player_tooltip_data_title_killswitch") ? e.Z.setAttribute("title", d) : e.Z.setAttribute("data-tooltip-title", d)), e.context.videoData.eventId && (e.eventId = e.context.videoData.eventId), e.WS = E.trackingParams ? g.bG(E.trackingParams) : null, e.K =
                    E.closeButton.infoCardIconRenderer.trackingParams ? g.bG(E.closeButton.infoCardIconRenderer.trackingParams) : null, e.eB = E.icon.infoCardIconRenderer.trackingParams ? g.bG(E.icon.infoCardIconRenderer.trackingParams) : null, l.Fh());
                ID(l.player)
            }
        },
        Jh5 = function(l, E, e, d, C) {
            if (!l.player.N().us) {
                var x = [];
                E.navigationEndpoint && g.T(E.navigationEndpoint, g.wq) && g.T(E.navigationEndpoint, g.wq).browseId && x.push(new MH6("openUrl", "click", new qq6("/channel/" + g.T(E.navigationEndpoint, g.wq).browseId, "new", !0, !0)));
                var Y = E.watermark.thumbnails[0];
                d = {
                    channel_name: E.channelName,
                    end_ms: E.endTimeMs,
                    image_height: Y.height,
                    image_type: 1,
                    image_url: Y.url,
                    image_width: Y.width,
                    is_mobile: !1,
                    session_data: {
                        annotation_id: e,
                        ei: C,
                        feature: "iv",
                        itct: E.trackingParams,
                        src_vid: d
                    },
                    start_ms: E.startTimeMs
                };
                if (E.subscribeButton && g.T(E.subscribeButton,
                        g.n0)) {
                    d.channel_id = g.T(E.subscribeButton, g.n0).channelId;
                    var B;
                    E = g.T(E.subscribeButton, g.n0);
                    Y = C = null;
                    E.subscribed ? (E.subscriberCountWithUnsubscribeText && (C = g.q8(E.subscriberCountWithUnsubscribeText)), E.subscriberCountText && (Y = g.q8(E.subscriberCountText))) : (E.subscriberCountText && (C = g.q8(E.subscriberCountText)), E.subscriberCountWithSubscribeText && (Y = g.q8(E.subscriberCountWithSubscribeText)));
                    var q, O = ((q = g.T((B = E.signInEndpoint) == null ? void 0 : B.commandMetadata, g.tD)) == null ? void 0 : q.url) || "";
                    B = {
                        subscribeText: g.q8(E.unsubscribedButtonText),
                        subscribeCount: C || "",
                        unsubscribeText: g.q8(E.subscribedButtonText),
                        unsubscribeCount: Y || "",
                        enabled: E.enabled || !1,
                        classic: !1,
                        subscribed: E.subscribed || !1,
                        feature: "iv",
                        signInUrl: O
                    };
                    d.standalone_subscribe_button_data = B
                }
                x = new bqB(e, "branding", "branding", x, d);
                B = Ect(l);
                l.player.B("web_player_overlay_positioned_layout") ? (B.setAttribute("data-overlay-order", "11"), l.player.Yy(B, 4, !0)) : l.V.element.appendChild(B);
                x = new qm(B, Mm(l), x);
                x.UM();
                g.L(x, x);
                l.X[e] = x
            }
        },
        Ylu = function(l, E) {
            return function() {
                var e = g.iZ.apply(0,
                    arguments);
                l.BS() || l.VV.push(g.LA.tD(function() {
                    E.apply(null, g.bZ(e))
                }))
            }
        },
        btR = function(l) {
            return l === "annotation-editor" || l === "live-dashboard"
        };
    g.jw.prototype.OW = g.Cs(39, function(l, E) {
        var e = g.Fg(this.WP());
        e && e.OW(l, E)
    });
    var P8 = {},
        RD = null;
    g.JH(ht, g.BN);
    g.D = ht.prototype;
    g.D.getDuration = function() {
        return this.duration
    };
    g.D.play = function(l) {
        if (l || this.C == 0) this.progress = 0, this.coords = this.V;
        else if (this.isPlaying()) return !1;
        kB(this);
        this.startTime = l = g.v6();
        this.isPaused() && (this.startTime -= this.duration * this.progress);
        this.endTime = this.startTime + this.duration;
        this.W = this.startTime;
        this.progress || this.Nt();
        this.v9("play");
        this.isPaused() && this.v9("resume");
        this.C = 1;
        var E = g.u_(this);
        E in P8 || (P8[E] = this);
        cb6();
        i36(this, l);
        return !0
    };
    g.D.stop = function(l) {
        kB(this);
        this.C = 0;
        l && (this.progress = 1);
        Z3H(this, this.progress);
        this.onStop();
        this.Qr()
    };
    g.D.pause = function() {
        this.isPlaying() && (kB(this), this.C = -1, this.v9("pause"))
    };
    g.D.cS = function() {
        this.C == 0 || this.stop(!1);
        this.v9("destroy");
        ht.q7.cS.call(this)
    };
    g.D.destroy = function() {
        this.dispose()
    };
    g.D.v8 = function() {
        this.v9("animate")
    };
    g.D.v9 = function(l) {
        this.dispatchEvent(new $MK(l, this))
    };
    g.JH($MK, g.G4);
    g.JH(FL, ht);
    FL.prototype.G = function() {};
    FL.prototype.v8 = function() {
        this.G();
        FL.q7.v8.call(this)
    };
    FL.prototype.Qr = function() {
        this.G();
        FL.q7.Qr.call(this)
    };
    FL.prototype.Nt = function() {
        this.G();
        FL.q7.Nt.call(this)
    };
    g.JH(TEi, FL);
    TEi.prototype.G = function() {
        this.element.style.left = Math.round(this.coords[0]) + "px";
        this.element.style.top = Math.round(this.coords[1]) + "px"
    };
    g.p(jVx, g.F);
    g.D = jVx.prototype;
    g.D.listen = function(l, E, e, d) {
        e = (0, g.qW)(e, d || this.V);
        l = g.KE(l, E, e);
        this.C.push(l);
        return l
    };
    g.D.v7 = function(l, E, e, d) {
        e = (0, g.qW)(e, d || this.V);
        l = Fut(l, E, e);
        this.C.push(l);
        return l
    };
    g.D.Dn = function(l) {
        g.Ur(l);
        g.Vx(this.C, l)
    };
    g.D.removeAll = function() {
        g.Ur(this.C);
        this.C.length = 0
    };
    g.D.cS = function() {
        this.removeAll();
        g.F.prototype.cS.call(this)
    };
    g.p(SoR, g.Vc);
    g.D = SoR.prototype;
    g.D.load = function() {
        g.Vc.prototype.load.call(this);
        if (!i2(this)) {
            var l = g.i8R(this.player.getVideoData());
            l ? (l = XrN(l, zkB(this)), Z6(this, l, !1)) : rbW(this)
        }
    };
    g.D.unload = function() {
        Z6(this, null);
        this.W && (this.W.abort(), this.W = null);
        g.Vc.prototype.unload.call(this)
    };
    g.D.Sp = function(l, E) {
        return i2(this) ? l === "loadCustomEndscreenRenderer" ? (l = XrN(E, "new"), Z6(this, l), !0) : null : null
    };
    g.D.getOptions = function() {
        return i2(this) ? ["loadCustomEndscreenRenderer"] : []
    };
    g.D.l2 = function() {
        if (this.endscreen && this.endscreen.elements) {
            var l = this.player.getVideoContentRect();
            if (l && l.width !== 0 && l.height !== 0) {
                var E = this.player.getPlayerSize();
                if (E && E.width !== 0 && E.height !== 0) {
                    var e = l.width / l.height;
                    var d = 0;
                    for (var C = -1, x = 0; x < DF_.length; x++) {
                        var Y = Math.abs(E.width - DF_[x]);
                        if (C === -1 || d >= Y) C = x, d = Y
                    }
                    d = pX5[C];
                    this.G && g.W_(this.G.element, "outline-width", Math.max(E.width, E.height) + "px");
                    for (E = 0; E < this.endscreen.elements.length; ++E)
                        if (x = this.endscreen.elements[E].id, C = this.V[x],
                            Y = this.X[x], C && Y) {
                            var B = Y.width * e / Y.aspectRatio,
                                q = Math.round(Y.width * l.width);
                            x = Math.round(B * l.height);
                            var O = l.left + Math.round(Y.left * l.width),
                                M = l.top + Math.round(Y.top * l.height);
                            g.Ej(C.element, q, x);
                            g.rv(C.element, O, M);
                            g.YP(C.element, KF5);
                            q > 256 || x > 256 ? g.d4(C.element, "ytp-ce-large-round") : q > 96 || x > 96 ? g.d4(C.element, "ytp-ce-medium-round") : g.d4(C.element, "ytp-ce-small-round");
                            g.YP(C.element, UFD);
                            q = Y.left + Y.width / 2;
                            Y = Y.top + B / 2;
                            g.d4(C.element, q <= .5 && Y <= .5 ? "ytp-ce-top-left-quad" : q > .5 && Y <= .5 ? "ytp-ce-top-right-quad" :
                                q <= .5 && Y > .5 ? "ytp-ce-bottom-left-quad" : "ytp-ce-bottom-right-quad");
                            g.YP(C.element, pX5);
                            g.d4(C.element, d);
                            (C = g.B_(document, "div", "ytp-ce-expanding-overlay-body", C.element)[0]) && g.W_(C, "height", x + "px")
                        }
                }
            }
        }
    };
    g.D.onCueRangeEnter = function(l) {
        if (this.endscreen)
            if (l.getId() === "ytp-ce-in-endscreen") W8(this, this.endscreen.impressionUrls), (l = g.Ki()) && this.endscreen.visualElement && g.XV(l, this.endscreen.visualElement), this.C && (g.d4(this.C, "ytp-ce-element-show"), this.C.removeAttribute("aria-hidden"), this.player.iZ() ? g.d4(this.C, "ytp-ce-hide-button-lower") : g.xP(this.C, "ytp-ce-hide-button-lower"));
            else {
                l = l.getId().substring(15);
                var E = this.V[l],
                    e = this.X[l];
                g.d4(E.element, "ytp-ce-element-show");
                E.element.removeAttribute("aria-hidden");
                E = this.player.getRootNode();
                g.d4(E, "ytp-ce-shown");
                W8(this, e.impressionUrls);
                (E = g.Ki()) && g.XV(E, e.visualElement);
                this.player.N().K && this.player.x8("endscreenelementshown", l)
            }
    };
    g.D.onCueRangeExit = function(l) {
        if (l.getId() === "ytp-ce-in-endscreen") this.C && (g.xP(this.C, "ytp-ce-element-show"), this.C.setAttribute("aria-hidden", "true"));
        else {
            l = l.getId().substring(15);
            var E = this.V[l];
            g.xP(E.element, "ytp-ce-element-show");
            E.element.setAttribute("aria-hidden", "true");
            E = this.player.getRootNode();
            g.xP(E, "ytp-ce-shown");
            this.player.N().K && this.player.x8("endscreenelementhidden", l)
        }
    };
    g.D.yE8 = function(l) {
        var E = this;
        l.target === window && (new g.Gv(function() {
            for (var e = g.U(Object.values(E.V)), d = e.next(); !d.done; d = e.next()) g.YP(d.value.element, ["ytp-ce-force-expand", "ytp-ce-element-hover", "ytp-ce-element-shadow-show"])
        }, 0)).start()
    };
    g.D.SD = function(l) {
        for (var E = g.U(Object.values(this.V)), e = E.next(); !e.done; e = E.next()) e = e.value, l ? e.element.setAttribute("hidden", "") : e.element.removeAttribute("hidden")
    };
    g.D.opZ = function(l) {
        this.C && this.player.getRootNode().removeChild(this.C);
        l && (g.d4(l, "ytp-ce-hide-button-container"), this.C = l, g.lb(this.player, this.C, 4))
    };
    var DF_ = [346, 426, 470, 506, 570, 640, 853, 1280, 1920],
        pX5 = "ytp-ce-size-346 ytp-ce-size-426 ytp-ce-size-470 ytp-ce-size-506 ytp-ce-size-570 ytp-ce-size-640 ytp-ce-size-853 ytp-ce-size-1280 ytp-ce-size-1920".split(" "),
        UFD = ["ytp-ce-top-left-quad", "ytp-ce-top-right-quad", "ytp-ce-bottom-left-quad", "ytp-ce-bottom-right-quad"],
        KF5 = ["ytp-ce-small-round", "ytp-ce-medium-round", "ytp-ce-large-round"];
    var Oq_ = {
        XVQ: "current",
        qv4: "new"
    };
    var vGB = {
            CLOSE: "close",
            z66: "openUrl",
            SUBSCRIBE: "subscribe"
        },
        N1K = {
            M7J: "click",
            CLOSE: "close",
            B0V: "hidden",
            raZ: "rollOut",
            UW9: "rollOver",
            cmK: "shown"
        };
    bqB.prototype.s0 = function() {
        var l = DIx(this, function(E) {
            return E.type === "openUrl" && E.url != null
        });
        return l ? l.url : null
    };
    var NNu = {
            zkZ: "anchored",
            UR: "branding",
            CHANNEL: "channel",
            DiO: "cta",
            mIK: "highlightText",
            WGO: "label",
            PLAYLIST: "playlist",
            POPUP: "popup",
            p9O: "speech",
            SUBSCRIBE: "subscribe",
            teS: "title",
            VIDEO: "video",
            G$V: "website"
        },
        vcR = {
            UR: "branding",
            SbQ: "card",
            LX2: "drawer",
            dIO: "highlight",
            w5k: "marker",
            tH9: "promotion",
            TEXT: "text",
            ldK: "widget"
        };
    g.p(ws, g.F);
    g.D = ws.prototype;
    g.D.addCueRange = function(l, E, e, d, C) {
        l = new g.X1(l, E, {
            id: e,
            namespace: "annotations_module"
        });
        d && this.E6.set(l, d);
        C && this.bO.set(l, C);
        this.context.D.Lh([l], 1)
    };
    g.D.UM = function() {
        this.context.V.subscribe("resize", this.uS, this)
    };
    g.D.IE = function() {
        return this.element
    };
    g.D.Ga = function(l, E, e, d, C, x) {
        if (this.eZ) return !1;
        x && (x.stopPropagation(), x.preventDefault());
        this.navigate(l, e, d, C);
        return !1
    };
    g.D.show = function() {};
    g.D.hide = function() {};
    g.D.destroy = function() {
        g.mT(this.IE())
    };
    g.D.uS = function() {};
    g.D.navigate = function(l, E, e, d) {
        var C = this,
            x = GE(l);
        if (x) {
            var Y = HqD(x, l.target),
                B = function() {
                    l.C && C.context.D.pauseVideo();
                    var q = C.context.videoData.HB || !1,
                        O = g.l0(x || "");
                    q && O && (O.v || O.list) ? C.context.D.Q4(O.v, E, O.list, !1) : g.Ze(x || "", Y === "current" ? "_top" : void 0, E)
                };
            Y === "new" && (B(), B = null);
            Oh(this.context.logger, e, B, d);
            tHD(x) || (e = g.Ki(), d = E.itct, e && d && g.r$(e, g.bG(d)))
        }
    };
    g.D.cS = function() {
        this.E6.clear();
        this.bO.clear();
        g.F.prototype.cS.call(this)
    };
    g.D.createElement = function(l) {
        l = new g.W(l);
        g.L(this, l);
        return l.element
    };
    g.p(oGu, ws);
    g.D = oGu.prototype;
    g.D.GV = function() {
        this.VV && Cv(this, this.VV)
    };
    g.D.isAvailable = function() {
        var l;
        if (l = !!this.cards.length)(l = this.D.getRootNode()) ? (l = g.es(l), l = 173 < l.width && 173 < l.height) : l = !1;
        return l
    };
    g.D.uS = function() {
        var l = this.isAvailable();
        g.dk(this.IE(), l);
        g.u9(this.context.D.getRootNode(), g.oG.IV_DRAWER_ENABLED, l);
        ID(this.D)
    };
    g.D.destroy = function() {
        this.D.OW(!1);
        try {
            this.D.getRootNode().removeChild(this.W)
        } catch (l) {}
        g.w7(this.o4);
        g.oU(this.hO);
        this.tO && this.tO.dispose();
        this.X && this.X.dispose();
        ws.prototype.destroy.call(this)
    };
    g.D.a5 = function() {
        var l = this;
        this.context.C.listen(g.qr("iv-drawer-close-button", this.W), "click", this.tQ, this);
        this.context.C.listen(this.V, "touchend", function() {
            l.pJ.start()
        });
        this.context.C.listen(this.V, "scroll", this.Mr, this);
        this.context.V.subscribe("onHideControls", function() {
            l.DQ = !0
        });
        this.context.V.subscribe("onShowControls", function() {
            l.DQ = !1
        });
        this.context.V.subscribe("onVideoAreaChange", function() {
            l.DQ = g.ec(l.D.getRootNode(), "ytp-autohide")
        });
        this.o4.push(g.r7("iv-button-shown", this.cO6, this));
        this.o4.push(g.r7("iv-button-hidden", this.ztO, this));
        Phx(this)
    };
    g.D.findLastIndex = function(l) {
        if (this.cards.length === 0) return 0;
        var E = g.mR(this.cards, function(e) {
            return l.LW.startMs > e.LW.startMs || l.LW.startMs === e.LW.startMs && l.LW.timestamp >= e.LW.timestamp ? !0 : !1
        });
        return E === -1 ? 0 : E + 1
    };
    g.D.tQ = function() {
        if (this.G) {
            Oh(this.context.logger, uL(this).Mi.close);
            var l = g.Ki();
            l && this.K && g.r$(l, this.K);
            eY(this)
        }
    };
    g.D.Mr = function() {
        g.u9(this.W, "iv-drawer-scrolled", this.V.scrollTop > 0)
    };
    g.D.cO6 = function() {
        var l = g.Ki(),
            E = uL(this);
        E = E ? E.eB : this.eB;
        l && E && g.SK(l, [E])
    };
    g.D.ztO = function() {
        var l = g.Ki(),
            E = uL(this);
        E = E ? E.eB : this.eB;
        l && E && g.zF(l, [E])
    };
    g.D.YM = function() {
        var l = uL(this);
        Oh(this.context.logger, l.Mi.L6);
        var E = g.Ki();
        if (E && l)
            if (this.D.B("web_infocards_teaser_show_logging_fix")) {
                var e = [];
                l.El && e.push(l.El);
                l.eB && e.push(l.eB);
                e.length > 0 && g.SK(E, e)
            } else g.SK(E, [l.El, l.eB])
    };
    g.D.IQQ = function() {
        var l = g.Ki(),
            E = uL(this);
        l && E && g.zF(l, [E.El])
    };
    g.D.tT = function(l) {
        var E = uL(this),
            e = g.Ki();
        this.C ? l ? (l = this.context.logger, Oh(l, E.Mi.wO), l.D.sendVideoStatsEngageEvent(4, void 0), e && E.El && g.r$(e, E.El)) : (l = this.context.logger, Oh(l, E.Mi.wO), l.D.sendVideoStatsEngageEvent(4, void 0), e && E.eB && g.r$(e, E.eB)) : (l = this.context.logger, Oh(l, E.Mi.wO), l.D.sendVideoStatsEngageEvent(4, void 0), e && this.eB && g.r$(e, this.eB))
    };
    g.p(BT, ws);
    BT.prototype.UM = function() {
        ws.prototype.UM.call(this);
        iqo(this)
    };
    BT.prototype.show = function() {
        ws.prototype.show.call(this);
        var l = g.Ki(),
            E = this.annotation.data;
        l && E && (E = E.session_data) && g.SK(l, [g.bG(E.itct)])
    };
    BT.prototype.hide = function() {
        ws.prototype.hide.call(this);
        var l = g.Ki(),
            E = this.annotation.data;
        l && E && (E = E.session_data) && g.zF(l, [g.bG(E.itct)])
    };
    g.p(qm, BT);
    qm.prototype.show = function() {
        if (!this.isActive) {
            BT.prototype.show.call(this);
            if (!this.Y) {
                g.d4(this.IE(), "iv-branding");
                var l = this.annotation.data;
                this.V = this.createElement({
                    j: "img",
                    R4: ["branding-img", "iv-click-target"],
                    J: {
                        "aria-label": "Channel watermark",
                        src: l.image_url,
                        width: l.image_width,
                        height: l.image_height
                    }
                });
                g.dk(this.V, !1);
                var E = this.createElement({
                    j: "button",
                    R4: ["branding-img-container", "ytp-button"]
                });
                E.appendChild(this.V);
                this.IE().appendChild(E);
                var e = this.annotation.s0();
                e && nG(this, E,
                    e, this.annotation.id, l.session_data);
                this.context.D.B("disable_branding_context") || gG5(this, l);
                this.Y = !0
            }
            g.dk(this.IE(), !0);
            this.isActive = !0;
            if (this.V) {
                try {
                    ZqR(this, this.V)
                } catch (d) {}
                g.d4(this.context.D.getRootNode(), "ytp-branding-shown");
                this.context.D.getRootNode().style.setProperty("--branding-image-width", this.V.getAttribute("width") + "px")
            }
        }
    };
    qm.prototype.hide = function() {
        this.isActive && (BT.prototype.hide.call(this), g.dk(this.IE(), !1), this.isActive = !1, g.xP(this.context.D.getRootNode(), "ytp-branding-shown"))
    };
    qm.prototype.destroy = function() {
        this.C && (this.C.dispose(), this.C = null);
        g.xP(this.context.D.getRootNode(), "ytp-branding-shown");
        BT.prototype.destroy.call(this)
    };
    g.p(jkD, BT);
    g.D = jkD.prototype;
    g.D.show = function() {
        this.isActive || (BT.prototype.show.call(this), this.U || (XfR(this), this.U = !0), g.dk(this.IE(), !0), g.Lk(function() {
            g.xP(this.IE(), "iv-promo-inactive")
        }, 100, this), this.IE().removeAttribute("aria-hidden"), this.isActive = !0, wfi(this), Sqt(this), zOu(this, this.X))
    };
    g.D.hide = function() {
        this.isActive && (g.d4(this.IE(), "iv-promo-inactive"), this.isActive = !1, this.IE().setAttribute("aria-hidden", "true"))
    };
    g.D.Ga = function(l, E, e, d, C, x) {
        return this.isCollapsed ? !1 : BT.prototype.Ga.call(this, l, E, e, d, C, x)
    };
    g.D.lF = function(l) {
        this.K = !0;
        GVW(this, 500, l)
    };
    g.D.xU = function() {
        this.K = !1;
        rf_(this)
    };
    g.D.yv = function(l) {
        l.stopPropagation();
        this.hide()
    };
    g.D.Nv = function(l) {
        l.stopPropagation();
        wfi(this);
        this.isCollapsed = !0;
        g.d4(this.IE(), "iv-promo-collapsed-no-delay");
        this.Z.start()
    };
    g.D.destroy = function() {
        this.Z.dispose();
        BT.prototype.destroy.call(this)
    };
    g.p(l5B, g.Vc);
    g.D = l5B.prototype;
    g.D.Sp = function(l, E) {
        if (!btR(this.player.N().playerStyle)) return null;
        switch (l) {
            case "loadCustomAnnotationsXml":
                return (l = g.rR(E)) && xF_(this, l), !0;
            case "removeCustomAnnotationById":
                return E && this.C && (ajt(this.C, E), ID(this.player)), !0
        }
        return null
    };
    g.D.getOptions = function() {
        return btR(this.player.N().playerStyle) ? ["loadCustomAnnotationsXml", "removeCustomAnnotationById"] : []
    };
    g.D.f_ = function() {
        var l = this.player.N(),
            E = this.player.getVideoData(),
            e = l.annotationsLoadPolicy || E.annotationsLoadPolicy;
        return E.HB || this.player.isMutedByEmbedsMutedAutoplay() ? !1 : e === 1 && !E.Fk || l.DQ.get(E.videoId) || g.YL(E) || g.ue(E) ? !0 : !1
    };
    g.D.Fh = function() {
        if (this.G) {
            var l = this.player.SZ().getVideoContentRect(!0);
            g.Ej(this.G.element, l.width, l.height);
            g.rv(this.G.element, l.left, l.top)
        }
        if (this.C) {
            var E = this.player.v5();
            l = this.C;
            E = E.width;
            g.u9(l.W, "iv-drawer-small", E <= 426);
            g.u9(l.W, "iv-drawer-big", E >= 1280)
        }
    };
    g.D.Th = function(l) {
        ewo(this, l.state);
        g.G(l.state, 2) && (this.iZ() && this.jj() && this.player.getPresentingPlayerType() !== 2 && this.Wk(!1), this.OW(!1))
    };
    g.D.load = function() {
        function l(Y) {
            var B = E.loadNumber;
            E.Z = null;
            E.loaded && E.loadNumber === B && E.player.getVideoData().videoId === d && (Y = g.Ox(Y) && Y.responseXML ? Y.responseXML : null) && (xF_(E, Y), g.d4(E.player.getRootNode(), "iv-module-loaded"))
        }
        var E = this;
        g.Vc.prototype.load.call(this);
        ewo(this, this.player.getPlayerStateObject());
        this.loadNumber++;
        var e = this.player.getVideoData(),
            d = e.videoId;
        g.zZ() && (l = Ylu(this, l));
        var C = {
            format: "XML",
            onFinish: l,
            onError: function() {
                E.Z = null
            },
            urlParams: {}
        };
        e.isPharma && (C.urlParams.pharma = "1");
        C.method = "POST";
        C.withCredentials = !0;
        var x = this.player.N().DQ.get(d);
        x && uGK(C, x);
        x = x && (x.w6 || x.UH);
        if (!e.eb || x) e.hO ? dFx(this, e.hO, C) : (this.Y = function() {
            if (!E.K) E.onVideoDataChange(C);
            var Y = E.player.getVideoData();
            (Y == null ? 0 : g.xL(Y)) && !E.o4 && Mau(E, Y)
        }, this.player.addEventListener("videodatachange", this.Y));
        g.lb(this.player, this.G.element, 4);
        this.Fh();
        (x = g.YL(e)) && OtW(this, x);
        (x = g.ue(e)) && x.featuredChannel && Jh5(this, x.featuredChannel, x.annotationId || "branding", e.videoId || null, e.eventId || null);
        this.EQ = g.qr("ytp-cards-button", this.player.getRootNode());
        g.xL(e) && Mau(this, e)
    };
    g.D.onVideoDataChange = function(l) {
        var E = this.player.getVideoData();
        E.hO && dFx(this, E.hO, l)
    };
    g.D.unload = function() {
        this.player.tE("annotations_module");
        for (var l = g.U(Object.keys(this.X)), E = l.next(); !E.done; E = l.next()) this.X[E.value].destroy();
        this.U = null;
        this.C && (this.C.destroy(), this.C = null, ID(this.player));
        this.K = !1;
        this.Z && (this.Z.abort(), this.Z = null);
        this.o4 = !1;
        this.X = {};
        this.V.hide();
        g.Vc.prototype.unload.call(this);
        this.G.detach();
        this.Y && (this.player.removeEventListener("videodatachange", this.Y), this.Y = null)
    };
    g.D.Uj = function(l) {
        l === this.player.getVideoData().videoId && (this.loaded ? BNK(this) : this.load())
    };
    g.D.iZ = function() {
        var l;
        return ((l = this.C) == null ? void 0 : l.isAvailable()) || this.o4
    };
    g.D.jj = function() {
        return !!this.C && this.C.G
    };
    g.D.Wk = function(l, E, e) {
        E = E === void 0 ? !1 : E;
        this.iZ();
        this.C && (l ? e ? Eh(this.C, e, E) : Eh(this.C, "YOUTUBE_DRAWER_AUTO_OPEN", E) : eY(this.C))
    };
    g.D.OW = function(l, E) {
        this.player.publish(l ? "cardsteasershow" : "cardsteaserhide", E)
    };
    g.D.cS = function() {
        this.player.N().DQ.unsubscribe("vast_info_card_add", this.Uj, this);
        g.xP(this.player.getRootNode(), g.oG.IV_DRAWER_OPEN);
        for (var l = this.VV, E = g.LA, e = 0, d = l.length; e < d; e++) E.HV(l[e]);
        this.VV.length = 0;
        g.Vc.prototype.cS.call(this)
    };
    g.D.createElement = function(l) {
        l = new g.W(l);
        g.L(this, l);
        return l.element
    };
    g.HQ("annotations_module", l5B);
    g.HQ("creatorendscreen", SoR);
})(_yt_player);