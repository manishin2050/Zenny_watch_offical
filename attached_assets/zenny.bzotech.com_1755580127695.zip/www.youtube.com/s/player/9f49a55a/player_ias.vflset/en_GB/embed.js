(function(g) {
    var window = this;
    'use strict';
    var NIx = function(l) {
            l.mutedAutoplay = !1;
            l.endSeconds = NaN;
            l.limitedPlaybackDurationInSeconds = NaN;
            g.tQ(l)
        },
        J5K = function() {
            return {
                j: "svg",
                J: {
                    height: "100%",
                    version: "1.1",
                    viewBox: "0 0 110 26",
                    width: "100%"
                },
                S: [{
                    j: "path",
                    PB: !0,
                    T: "ytp-svg-fill",
                    J: {
                        d: "M 16.68,.99 C 13.55,1.03 7.02,1.16 4.99,1.68 c -1.49,.4 -2.59,1.6 -2.99,3 -0.69,2.7 -0.68,8.31 -0.68,8.31 0,0 -0.01,5.61 .68,8.31 .39,1.5 1.59,2.6 2.99,3 2.69,.7 13.40,.68 13.40,.68 0,0 10.70,.01 13.40,-0.68 1.5,-0.4 2.59,-1.6 2.99,-3 .69,-2.7 .68,-8.31 .68,-8.31 0,0 .11,-5.61 -0.68,-8.31 -0.4,-1.5 -1.59,-2.6 -2.99,-3 C 29.11,.98 18.40,.99 18.40,.99 c 0,0 -0.67,-0.01 -1.71,0 z m 72.21,.90 0,21.28 2.78,0 .31,-1.37 .09,0 c .3,.5 .71,.88 1.21,1.18 .5,.3 1.08,.40 1.68,.40 1.1,0 1.99,-0.49 2.49,-1.59 .5,-1.1 .81,-2.70 .81,-4.90 l 0,-2.40 c 0,-1.6 -0.11,-2.90 -0.31,-3.90 -0.2,-0.89 -0.5,-1.59 -1,-2.09 -0.5,-0.4 -1.10,-0.59 -1.90,-0.59 -0.59,0 -1.18,.19 -1.68,.49 -0.49,.3 -1.01,.80 -1.21,1.40 l 0,-7.90 -3.28,0 z m -49.99,.78 3.90,13.90 .18,6.71 3.31,0 0,-6.71 3.87,-13.90 -3.37,0 -1.40,6.31 c -0.4,1.89 -0.71,3.19 -0.81,3.99 l -0.09,0 c -0.2,-1.1 -0.51,-2.4 -0.81,-3.99 l -1.37,-6.31 -3.40,0 z m 29.59,0 0,2.71 3.40,0 0,17.90 3.28,0 0,-17.90 3.40,0 c 0,0 .00,-2.71 -0.09,-2.71 l -9.99,0 z m -53.49,5.12 8.90,5.18 -8.90,5.09 0,-10.28 z m 89.40,.09 c -1.7,0 -2.89,.59 -3.59,1.59 -0.69,.99 -0.99,2.60 -0.99,4.90 l 0,2.59 c 0,2.2 .30,3.90 .99,4.90 .7,1.1 1.8,1.59 3.5,1.59 1.4,0 2.38,-0.3 3.18,-1 .7,-0.7 1.09,-1.69 1.09,-3.09 l 0,-0.5 -2.90,-0.21 c 0,1 -0.08,1.6 -0.28,2 -0.1,.4 -0.5,.62 -1,.62 -0.3,0 -0.61,-0.11 -0.81,-0.31 -0.2,-0.3 -0.30,-0.59 -0.40,-1.09 -0.1,-0.5 -0.09,-1.21 -0.09,-2.21 l 0,-0.78 5.71,-0.09 0,-2.62 c 0,-1.6 -0.10,-2.78 -0.40,-3.68 -0.2,-0.89 -0.71,-1.59 -1.31,-1.99 -0.7,-0.4 -1.48,-0.59 -2.68,-0.59 z m -50.49,.09 c -1.09,0 -2.01,.18 -2.71,.68 -0.7,.4 -1.2,1.12 -1.49,2.12 -0.3,1 -0.5,2.27 -0.5,3.87 l 0,2.21 c 0,1.5 .10,2.78 .40,3.78 .2,.9 .70,1.62 1.40,2.12 .69,.5 1.71,.68 2.81,.78 1.19,0 2.08,-0.28 2.78,-0.68 .69,-0.4 1.09,-1.09 1.49,-2.09 .39,-1 .49,-2.30 .49,-3.90 l 0,-2.21 c 0,-1.6 -0.2,-2.87 -0.49,-3.87 -0.3,-0.89 -0.8,-1.62 -1.49,-2.12 -0.7,-0.5 -1.58,-0.68 -2.68,-0.68 z m 12.18,.09 0,11.90 c -0.1,.3 -0.29,.48 -0.59,.68 -0.2,.2 -0.51,.31 -0.81,.31 -0.3,0 -0.58,-0.10 -0.68,-0.40 -0.1,-0.3 -0.18,-0.70 -0.18,-1.40 l 0,-10.99 -3.40,0 0,11.21 c 0,1.4 .18,2.39 .68,3.09 .49,.7 1.21,1 2.21,1 1.4,0 2.48,-0.69 3.18,-2.09 l .09,0 .31,1.78 2.59,0 0,-14.99 c 0,0 -3.40,.00 -3.40,-0.09 z m 17.31,0 0,11.90 c -0.1,.3 -0.29,.48 -0.59,.68 -0.2,.2 -0.51,.31 -0.81,.31 -0.3,0 -0.58,-0.10 -0.68,-0.40 -0.1,-0.3 -0.21,-0.70 -0.21,-1.40 l 0,-10.99 -3.40,0 0,11.21 c 0,1.4 .21,2.39 .71,3.09 .5,.7 1.18,1 2.18,1 1.39,0 2.51,-0.69 3.21,-2.09 l .09,0 .28,1.78 2.62,0 0,-14.99 c 0,0 -3.40,.00 -3.40,-0.09 z m 20.90,2.09 c .4,0 .58,.11 .78,.31 .2,.3 .30,.59 .40,1.09 .1,.5 .09,1.21 .09,2.21 l 0,1.09 -2.5,0 0,-1.09 c 0,-1 -0.00,-1.71 .09,-2.21 0,-0.4 .11,-0.8 .31,-1 .2,-0.3 .51,-0.40 .81,-0.40 z m -50.49,.12 c .5,0 .8,.18 1,.68 .19,.5 .28,1.30 .28,2.40 l 0,4.68 c 0,1.1 -0.08,1.90 -0.28,2.40 -0.2,.5 -0.5,.68 -1,.68 -0.5,0 -0.79,-0.18 -0.99,-0.68 -0.2,-0.5 -0.31,-1.30 -0.31,-2.40 l 0,-4.68 c 0,-1.1 .11,-1.90 .31,-2.40 .2,-0.5 .49,-0.68 .99,-0.68 z m 39.68,.09 c .3,0 .61,.10 .81,.40 .2,.3 .27,.67 .37,1.37 .1,.6 .12,1.51 .12,2.71 l .09,1.90 c 0,1.1 .00,1.99 -0.09,2.59 -0.1,.6 -0.19,1.08 -0.49,1.28 -0.2,.3 -0.50,.40 -0.90,.40 -0.3,0 -0.51,-0.08 -0.81,-0.18 -0.2,-0.1 -0.39,-0.29 -0.59,-0.59 l 0,-8.5 c .1,-0.4 .29,-0.7 .59,-1 .3,-0.3 .60,-0.40 .90,-0.40 z"
                    }
                }]
            }
        },
        bdx = function() {
            return {
                j: "svg",
                J: {
                    fill: "none",
                    height: "100%",
                    viewBox: "0 0 143 51",
                    width: "100%"
                },
                S: [{
                    j: "path",
                    J: {
                        d: "M58.37 41.39H62.79V27.23C62.79 23.03 62.69 18.69 62.43 13.59H62.93L63.69 16.89L68.67 41.39H73.17L78.07 16.89L78.89 13.59H79.37C79.15 18.45 79.03 22.89 79.03 27.23V41.39H83.45V8.79H75.95L73.41 20.81C72.35 25.85 71.51 32.01 71.01 35.19H70.73C70.33 31.95 69.49 25.81 68.41 20.85L65.81 8.79H58.37V41.39Z",
                        fill: "white"
                    }
                }, {
                    j: "path",
                    J: {
                        d: "M91.45 41.73C93.91 41.73 95.83 40.59 97.17 38.13H97.35L97.69 41.39H101.43V17.73H96.47V36.61C95.91 37.67 94.81 38.29 93.73 38.29C92.33 38.29 91.89 37.17 91.89 35.13V17.73H86.93V35.43C86.93 39.49 88.19 41.73 91.45 41.73Z",
                        fill: "white"
                    }
                }, {
                    j: "path",
                    J: {
                        d: "M110.79 41.89C115.15 41.89 117.75 39.83 117.75 35.65C117.75 31.79 115.93 30.39 111.85 27.47C109.67 25.91 108.39 25.09 108.39 22.95C108.39 21.47 109.27 20.61 110.89 20.61C112.69 20.61 113.33 21.81 113.33 25.29L117.45 25.07C117.77 19.57 115.71 17.23 110.97 17.23C106.57 17.23 104.17 19.27 104.17 23.45C104.17 27.25 105.97 28.83 108.93 31.03C111.89 33.23 113.55 34.53 113.55 36.23C113.55 37.75 112.51 38.61 111.01 38.61C109.13 38.61 108.11 36.97 108.29 34.41L104.21 34.49C103.51 39.25 105.89 41.89 110.79 41.89Z",
                        fill: "white"
                    }
                }, {
                    j: "path",
                    J: {
                        d: "M122.5 14.59C124.22 14.59 125.04 13.99 125.04 11.59C125.04 9.33 124.16 8.65 122.5 8.65C120.84 8.65 119.94 9.27 119.94 11.59C119.94 13.99 120.82 14.59 122.5 14.59ZM120.2 41.39H125V17.73H120.2V41.39Z",
                        fill: "white"
                    }
                }, {
                    j: "path",
                    J: {
                        d: "M134.95 41.79C137.31 41.79 138.63 41.49 139.71 40.47C141.31 39.01 141.97 36.63 141.85 33.11L137.41 32.87C137.41 36.87 136.81 38.45 135.03 38.45C133.13 38.45 132.77 36.45 132.77 31.97V27.21C132.77 22.41 133.23 20.51 135.07 20.51C136.67 20.51 137.29 22.01 137.29 26.47L141.65 26.15C141.97 22.93 141.59 20.29 140.09 18.83C139.01 17.77 137.37 17.29 135.15 17.29C129.65 17.29 127.75 20.73 127.75 28.03V31.17C127.75 38.47 129.23 41.79 134.95 41.79Z",
                        fill: "white"
                    }
                }, {
                    j: "path",
                    J: {
                        "clip-rule": "evenodd",
                        d: "M24.99 49C29.74 49.00 34.38 47.59 38.32 44.95C42.27 42.32 45.35 38.57 47.17 34.18C48.98 29.80 49.46 24.97 48.53 20.32C47.61 15.66 45.32 11.38 41.97 8.03C38.61 4.67 34.33 2.38 29.68 1.46C25.02 .53 20.20 1.01 15.81 2.82C11.43 4.64 7.68 7.71 5.04 11.66C2.40 15.61 1 20.25 1 25C0.99 28.15 1.61 31.27 2.82 34.18C4.03 37.09 5.79 39.74 8.02 41.97C10.25 44.19 12.89 45.96 15.81 47.17C18.72 48.37 21.84 49 24.99 49ZM24.99 12.36C27.49 12.36 29.94 13.10 32.02 14.48C34.10 15.87 35.72 17.84 36.68 20.15C37.64 22.46 37.89 25.01 37.41 27.46C36.92 29.91 35.72 32.17 33.95 33.94C32.18 35.70 29.93 36.91 27.48 37.40C25.02 37.89 22.48 37.64 20.17 36.68C17.86 35.72 15.88 34.10 14.50 32.02C13.11 29.94 12.37 27.50 12.37 25C12.37 21.65 13.70 18.44 16.07 16.07C18.43 13.70 21.64 12.37 24.99 12.36ZM24.99 10.43C22.11 10.43 19.29 11.28 16.89 12.88C14.50 14.48 12.63 16.76 11.53 19.42C10.42 22.09 10.13 25.02 10.70 27.85C11.26 30.67 12.65 33.27 14.69 35.31C16.73 37.35 19.32 38.73 22.15 39.30C24.98 39.86 27.91 39.57 30.57 38.46C33.23 37.36 35.51 35.49 37.11 33.09C38.71 30.70 39.57 27.88 39.56 25C39.56 23.08 39.19 21.19 38.46 19.42C37.72 17.65 36.65 16.04 35.30 14.69C33.94 13.34 32.34 12.27 30.57 11.53C28.80 10.80 26.90 10.43 24.99 10.43ZM32.63 24.99L20.36 32.09V17.91L32.63 24.99Z",
                        fill: "white",
                        "fill-rule": "evenodd"
                    }
                }]
            }
        },
        DJu = function(l) {
            g.W.call(this, {
                j: "div",
                T: "ytp-related-on-error-overlay"
            });
            var E = this;
            this.api = l;
            this.X = this.V = 0;
            this.W = new g.oE(this);
            this.C = [];
            this.suggestionData = [];
            this.columns = this.containerWidth = 0;
            this.title = new g.W({
                j: "h2",
                T: "ytp-related-title",
                zK: "{{title}}"
            });
            this.previous = new g.W({
                j: "button",
                R4: ["ytp-button", "ytp-previous"],
                J: {
                    "aria-label": "Show previous suggested videos"
                },
                S: [g.vF()]
            });
            this.U = new g.wR(function(x) {
                E.suggestions.element.scrollLeft = -x
            });
            this.G = this.scrollPosition = 0;
            this.Y = !0;
            this.next = new g.W({
                j: "button",
                R4: ["ytp-button", "ytp-next"],
                J: {
                    "aria-label": "Show more suggested videos"
                },
                S: [g.N8()]
            });
            g.L(this, this.W);
            l = l.N();
            this.K = l.W;
            g.L(this, this.title);
            this.title.AO(this.element);
            this.suggestions = new g.W({
                j: "div",
                T: "ytp-suggestions"
            });
            g.L(this, this.suggestions);
            this.suggestions.AO(this.element);
            g.L(this, this.previous);
            this.previous.AO(this.element);
            this.previous.listen("click", this.N_, this);
            g.L(this, this.U);
            for (var e = {
                    r4: 0
                }; e.r4 < 16; e = {
                    r4: e.r4
                }, e.r4++) {
                var d = new g.W({
                    j: "a",
                    T: "ytp-suggestion-link",
                    J: {
                        href: "{{link}}",
                        target: l.U,
                        "aria-label": "{{aria_label}}"
                    },
                    S: [{
                        j: "div",
                        T: "ytp-suggestion-image",
                        S: [{
                            j: "div",
                            J: {
                                "data-is-live": "{{is_live}}"
                            },
                            T: "ytp-suggestion-duration",
                            zK: "{{duration}}"
                        }]
                    }, {
                        j: "div",
                        T: "ytp-suggestion-title",
                        J: {
                            title: "{{hover_title}}"
                        },
                        zK: "{{title}}"
                    }, {
                        j: "div",
                        T: "ytp-suggestion-author",
                        zK: "{{views_or_author}}"
                    }]
                });
                g.L(this, d);
                d.AO(this.suggestions.element);
                var C = d.GK("ytp-suggestion-link");
                g.W_(C, "transitionDelay", e.r4 /
                    20 + "s");
                this.W.L(C, "click", function(x) {
                    return function(Y) {
                        var B = x.r4,
                            q = E.suggestionData[B],
                            O = q.sessionData;
                        g.dp(E.api.N()) && E.api.B("web_player_log_click_before_generating_ve_conversion_params") ? (E.api.logClick(E.C[B].element), B = q.Rg(), q = {}, g.rA(E.api, q), B = g.Uy(B, q), g.sA(B, E.api, Y)) : g.QE(Y, E.api, E.K, O || void 0) && E.api.Q4(q.videoId, O, q.playlistId)
                    }
                }(e));
                this.C.push(d)
            }
            g.L(this, this.next);
            this.next.AO(this.element);
            this.next.listen("click", this.yF, this);
            this.W.L(this.api, "videodatachange", this.onVideoDataChange);
            this.resize(this.api.SZ().getPlayerSize());
            this.onVideoDataChange();
            this.show()
        },
        peB = function(l, E) {
            if (l.api.N().B("web_player_log_click_before_generating_ve_conversion_params"))
                for (var e = Math.floor(-l.scrollPosition / (l.G + l.V)), d = Math.min(e + l.columns, l.suggestionData.length) - 1; e <= d; e++) l.api.logVisibility(l.C[e].element, E)
        },
        K8u = function(l) {
            l.next.element.style.bottom =
                l.X + "px";
            l.previous.element.style.bottom = l.X + "px";
            var E = l.scrollPosition,
                e = l.containerWidth - l.suggestionData.length * (l.G + l.V);
            g.u9(l.element, "ytp-scroll-min", E >= 0);
            g.u9(l.element, "ytp-scroll-max", E <= e)
        },
        UJW = function(l) {
            for (var E = 0; E < l.suggestionData.length; E++) {
                var e = l.suggestionData[E],
                    d = l.C[E],
                    C = e.shortViewCount ? e.shortViewCount : e.author,
                    x = e.Rg(),
                    Y = l.api.N();
                if (g.dp(Y) && !Y.B("web_player_log_click_before_generating_ve_conversion_params")) {
                    var B = {};
                    g.fw(l.api, "addEmbedsConversionTrackingParams", [B]);
                    x = g.Uy(x, B)
                }
                d.element.style.display = "";
                B = d.GK("ytp-suggestion-title");
                g.vN.test(e.title) ? B.dir = "rtl" : g.ITo.test(e.title) && (B.dir = "ltr");
                B = d.GK("ytp-suggestion-author");
                g.vN.test(C) ? B.dir = "rtl" : g.ITo.test(C) && (B.dir = "ltr");
                d.update({
                    views_or_author: C,
                    duration: e.isLivePlayback ? "Live" : e.lengthSeconds ? g.mg(e.lengthSeconds) : "",
                    link: x,
                    hover_title: e.title,
                    title: e.title,
                    aria_label: e.ariaLabel || null,
                    is_live: e.isLivePlayback
                });
                C = e.Cw();
                d.GK("ytp-suggestion-image").style.backgroundImage = C ? "url(" + C + ")" : "";
                Y.B("web_player_log_click_before_generating_ve_conversion_params") && (l.api.createServerVe(d.element, d), (e = (e = e.sessionData) && e.itct) && l.api.setTrackingParams(d.element, e))
            }
            for (; E < l.C.length; E++) l.C[E].element.style.display = "none";
            K8u(l)
        },
        ld = function(l) {
            g.gl.call(this, l);
            var E = this;
            this.C = null;
            var e = l.N(),
                d = {
                    target: e.U
                },
                C = ["ytp-small-redirect"];
            if (e.G) C.push("no-link");
            else {
                var x = g.PI(e);
                d.href = x;
                d["aria-label"] = "Visit YouTube to search for more videos"
            }
            var Y = new g.W({
                j: "a",
                R4: C,
                J: d,
                S: [{
                    j: "svg",
                    J: {
                        fill: "#fff",
                        height: "100%",
                        viewBox: "0 0 24 24",
                        width: "100%"
                    },
                    S: [{
                        j: "path",
                        J: {
                            d: "M0 0h24v24H0V0z",
                            fill: "none"
                        }
                    }, {
                        j: "path",
                        J: {
                            d: "M21.58 7.19c-.23-.86-.91-1.54-1.77-1.77C18.25 5 12 5 12 5s-6.25 0-7.81.42c-.86.23-1.54.91-1.77 1.77C2 8.75 2 12 2 12s0 3.25.42 4.81c.23.86.91 1.54 1.77 1.77C5.75 19 12 19 12 19s6.25 0 7.81-.42c.86-.23 1.54-.91 1.77-1.77C22 15.25 22 12 22 12s0-3.25-.42-4.81zM10 15V9l5.2 3-5.2 3z"
                        }
                    }]
                }]
            });
            Y.AO(this.element);
            l.createClientVe(Y.element, this, 178053);
            this.L(Y.element, "click", function(B) {
                mJK(E, B, Y.element)
            });
            g.L(this, Y);
            e.G || e.disableOrganicUi || (this.C = new DJu(l), this.C.AO(this.element), g.L(this, this.C));
            this.L(l, "videodatachange", function() {
                E.show()
            });
            this.resize(this.api.SZ().getPlayerSize())
        },
        mJK = function(l, E, e) {
            E.preventDefault();
            l.api.logClick(e);
            E = e.getAttribute("href");
            e = {};
            g.fw(l.api, "addEmbedsConversionTrackingParams", [e]);
            E = g.Jw(e) ? E : g.Uy(E, e);
            g.DT(window, E)
        },
        y5o = function(l, E) {
            l.GK("ytp-error-content").style.paddingTop = "0px";
            var e = l.GK("ytp-error-content"),
                d = e.clientHeight;
            l.C && l.C.resize(E, E.height - d);
            e.style.paddingTop = (E.height - (l.C ? l.C.element.clientHeight : 0)) / 2 - d / 2 + "px"
        },
        Vku = function(l, E) {
            var e = l.api.N(),
                d;
            E.reason && (tkx(E.reason) ? d = g.O8(E.reason) : d = g.WQ(g.q8(E.reason)), l.n3(d, "content"));
            var C;
            E.subreason && (tkx(E.subreason) ? C = g.O8(E.subreason) : C = g.WQ(g.q8(E.subreason)), l.n3(C, "subreason"));
            if (E.proceedButton && E.proceedButton.buttonRenderer) {
                d = l.GK("ytp-error-content-wrap-subreason");
                E = E.proceedButton.buttonRenderer;
                var x = g.bV("A");
                if (E.text && E.text.simpleText && (C = E.text.simpleText, x.textContent = C, !Hd_(d, C) && (!e.G || e.embedsErrorLinks))) {
                    var Y;
                    e = (Y = g.T(E == null ? void 0 : E.navigationEndpoint, g.PF)) == null ?
                        void 0 : Y.url;
                    var B;
                    Y = (B = g.T(E == null ? void 0 : E.navigationEndpoint, g.PF)) == null ? void 0 : B.target;
                    e && (x.setAttribute("href", e), l.api.createClientVe(x, l, 178424), l.L(x, "click", function(q) {
                        mJK(l, q, x)
                    }));
                    Y && x.setAttribute("target", Y);
                    B = g.bV("DIV");
                    B.appendChild(x);
                    d.appendChild(B)
                }
            }
        },
        tkx = function(l) {
            if (l.runs)
                for (var E = 0; E < l.runs.length; E++)
                    if (l.runs[E].navigationEndpoint) return !0;
            return !1
        },
        Hd_ = function(l, E) {
            l = g.Y$("A", l);
            for (var e = 0; e < l.length; e++)
                if (l[e].textContent === E) return !0;
            return !1
        },
        od6 = function(l, E) {
            g.W.call(this, {
                j: "a",
                R4: ["ytp-impression-link"],
                J: {
                    target: "{{target}}",
                    href: "{{url}}",
                    "aria-label": "Watch on YouTube"
                },
                S: [{
                    j: "div",
                    T: "ytp-impression-link-content",
                    J: {
                        "aria-hidden": "true"
                    },
                    S: [{
                        j: "div",
                        T: "ytp-impression-link-text",
                        zK: "Watch on"
                    }, {
                        j: "div",
                        T: "ytp-impression-link-logo",
                        zK: "{{logoSvg}}"
                    }]
                }]
            });
            this.api = l;
            this.C = E;
            this.updateValue("target", l.N().U);
            this.L(l, "videodatachange", this.onVideoDataChange);
            this.L(this.api, "presentingplayerstatechange", this.G1);
            this.L(this.api, "videoplayerreset", this.bC);
            this.L(this.element,
                "click", this.onClick);
            this.onVideoDataChange();
            this.bC()
        },
        A5_ = function(l) {
            var E = {};
            g.fw(l.api, "addEmbedsConversionTrackingParams", [E]);
            l = l.api.getVideoUrl();
            return l = g.Uy(l, E)
        },
        Ei = function(l) {
            g.W.call(this, {
                j: "div",
                R4: ["ytp-mobile-a11y-hidden-seek-button"],
                S: [{
                    j: "button",
                    R4: ["ytp-mobile-a11y-hidden-seek-button-rewind", "ytp-button"],
                    J: {
                        "aria-label": "Rewind 10 seconds",
                        "aria-hidden": "false"
                    }
                }, {
                    j: "button",
                    R4: ["ytp-mobile-a11y-hidden-seek-button-forward", "ytp-button"],
                    J: {
                        "aria-label": "Fast forward 10 seconds",
                        "aria-hidden": "false"
                    }
                }]
            });
            this.api = l;
            this.C = this.GK("ytp-mobile-a11y-hidden-seek-button-rewind");
            this.forwardButton = this.GK("ytp-mobile-a11y-hidden-seek-button-forward");
            this.api.createClientVe(this.C, this,
                141902);
            this.api.createClientVe(this.forwardButton, this, 141903);
            this.L(this.api, "presentingplayerstatechange", this.G1);
            this.L(this.C, "click", this.V);
            this.L(this.forwardButton, "click", this.G);
            this.G1()
        },
        en = function(l) {
            g.W.call(this, {
                j: "div",
                T: "ytp-muted-autoplay-endscreen-overlay",
                S: [{
                    j: "div",
                    T: "ytp-muted-autoplay-end-panel",
                    S: [{
                        j: "button",
                        R4: ["ytp-muted-autoplay-end-text", "ytp-button"],
                        zK: "{{text}}"
                    }]
                }]
            });
            this.api = l;
            this.W = this.GK("ytp-muted-autoplay-end-panel");
            this.V = !1;
            this.api.createClientVe(this.element, this, 52428);
            this.L(this.api, "presentingplayerstatechange", this.G);
            this.L(l, "onMutedAutoplayStarts", this.onMutedAutoplayStarts);
            this.listen("click", this.onClick);
            this.hide()
        },
        dZ = function(l) {
            var E = l.N();
            g.W.call(this, {
                j: "a",
                R4: ["ytp-watermark", "yt-uix-sessionlink"],
                J: {
                    target: E.U,
                    href: "{{url}}",
                    "aria-label": g.uO("Watch on $WEBSITE", {
                        WEBSITE: g.UC(E)
                    }),
                    "data-sessionlink": "feature=player-watermark"
                },
                zK: "{{logoSvg}}"
            });
            this.api = l;
            this.C = null;
            this.V = !1;
            this.state = l.getPlayerStateObject();
            this.L(l, "videodatachange", this.onVideoDataChange);
            this.L(l, "presentingplayerstatechange", this.onStateChange);
            this.L(l, "appresize", this.l2);
            this.onVideoDataChange();
            this.L3(this.state);
            this.l2(l.SZ().getPlayerSize())
        },
        QMB = function(l) {
            var E = l.api.getVideoData(),
                e = l.api.N();
            e = e.us && !g.G(l.state, 2) && !l.api.getVideoData(1).HB && !(e.B("embeds_enable_emc3ds_woyt_counterfactual") && l.api.getPlayerStateObject().isCued());
            E.mutedAutoplay || l.SD(e);
            l.api.logVisibility(l.element, e)
        },
        IuN = function(l) {
            g.W.call(this, {
                j: "div",
                T: "ytp-muted-autoplay-overlay",
                S: [{
                    j: "div",
                    T: "ytp-muted-autoplay-bottom-buttons",
                    S: [{
                        j: "button",
                        R4: ["ytp-muted-autoplay-equalizer", "ytp-button"],
                        J: {
                            "aria-label": "Muted playback indicator"
                        },
                        S: [{
                            j: "div",
                            R4: ["ytp-muted-autoplay-equalizer-icon"],
                            S: [{
                                j: "svg",
                                J: {
                                    height: "100%",
                                    version: "1.1",
                                    viewBox: "-4 -4 24 24",
                                    width: "100%"
                                },
                                S: [{
                                    j: "g",
                                    J: {
                                        fill: "#fff"
                                    },
                                    S: [{
                                            j: "rect",
                                            T: "ytp-equalizer-bar-left",
                                            J: {
                                                height: "9",
                                                width: "4",
                                                x: "1",
                                                y: "7"
                                            }
                                        }, {
                                            j: "rect",
                                            T: "ytp-equalizer-bar-middle",
                                            J: {
                                                height: "14",
                                                width: "4",
                                                x: "6",
                                                y: "2"
                                            }
                                        },
                                        {
                                            j: "rect",
                                            T: "ytp-equalizer-bar-right",
                                            J: {
                                                height: "12",
                                                width: "4",
                                                x: "11",
                                                y: "4"
                                            }
                                        }
                                    ]
                                }]
                            }]
                        }]
                    }]
                }]
            });
            var E = this;
            this.api = l;
            this.bottomButtons = this.GK("ytp-muted-autoplay-bottom-buttons");
            this.G = new g.Gv(this.Gb, 4E3, this);
            this.V = !1;
            l.createClientVe(this.element, this, 39306);
            this.L(l, "presentingplayerstatechange", this.W8);
            this.L(l, "onMutedAutoplayStarts", function() {
                sMi(E);
                E.W8();
                auB(E);
                E.V = !1
            });
            this.L(l, "onAutoplayBlocked", this.onAutoplayBlocked);
            this.listen("click", this.onClick);
            this.L(l, "onMutedAutoplayEnds", this.onMutedAutoplayEnds);
            this.hide();
            l.isMutedByEmbedsMutedAutoplay() && (sMi(this), this.W8(), auB(this));
            g.L(this, this.G)
        },
        auB = function(l) {
            l.qw && l.C && (l.C.show(), l.G.start())
        },
        sMi = function(l) {
            l.watermark || (l.watermark = new dZ(l.api), g.L(l, l.watermark), l.watermark.AO(l.bottomButtons, 0), g.u9(l.watermark.element, "ytp-muted-autoplay-watermark", !0), l.C = new g.wY(l.watermark, 0, !0, 100), g.L(l,
                l.C))
        },
        CN = function(l) {
            g.W.call(this, {
                j: "div",
                T: "ytp-pause-overlay",
                J: {
                    tabIndex: "-1"
                }
            });
            var E = this;
            this.api = l;
            this.G = new g.oE(this);
            this.fade = new g.wY(this, 1E3, !1, 100, function() {
                E.C.V = !1
            }, function() {
                E.C.V = !0
            });
            this.V = !1;
            this.expandButton = new g.W({
                j: "button",
                R4: ["ytp-button", "ytp-expand"],
                zK: this.api.isEmbedsShortsMode() ? "More Shorts" : "More videos"
            });
            l.N().controlsType === "0" && g.d4(l.getRootNode(), "ytp-pause-overlay-controls-hidden");
            g.L(this, this.G);
            g.L(this, this.fade);
            var e = new g.W({
                j: "button",
                R4: ["ytp-button", "ytp-collapse"],
                J: {
                    "aria-label": this.api.isEmbedsShortsMode() ? "Hide more Shorts" : "Hide more videos"
                },
                S: [{
                    j: "div",
                    T: "ytp-collapse-icon",
                    S: [g.ou()]
                }]
            });
            g.L(this, e);
            e.AO(this.element);
            e.listen("click",
                this.W, this);
            g.L(this, this.expandButton);
            this.expandButton.AO(this.element);
            this.expandButton.listen("click", this.X, this);
            this.C = new g.np(l);
            g.L(this, this.C);
            this.C.V = !1;
            this.C.AO(this.element);
            this.api.isEmbedsShortsMode() ? this.api.createClientVe(this.element, this, 157212) : this.api.createClientVe(this.element, this, 172777);
            this.G.L(this.api, "presentingplayerstatechange", this.TK);
            this.G.L(this.api, "videodatachange", this.TK);
            this.hide()
        },
        xE = function(l) {
            g.W.call(this, {
                j: "div",
                R4: ["ytp-player-content", "ytp-iv-player-content"],
                S: [{
                    j: "div",
                    T: "ytp-countdown-timer",
                    S: [{
                        j: "svg",
                        J: {
                            height: "100%",
                            version: "1.1",
                            viewBox: "0 0 72 72",
                            width: "100%"
                        },
                        S: [{
                            j: "circle",
                            T: "ytp-svg-countdown-timer-ring",
                            J: {
                                cx: "-36",
                                cy: "36",
                                "fill-opacity": "0",
                                r: "33.5",
                                stroke: "#FFFFFF",
                                "stroke-dasharray": "211",
                                "stroke-dashoffset": "-211",
                                "stroke-width": "4",
                                transform: "rotate(-90)"
                            }
                        }, {
                            j: "circle",
                            T: "ytp-svg-countdown-timer-background",
                            J: {
                                cx: "-36",
                                cy: "36",
                                "fill-opacity": "0",
                                r: "33.5",
                                stroke: "#FFFFFF",
                                "stroke-opacity": "0.3",
                                "stroke-width": "4",
                                transform: "rotate(-90)"
                            }
                        }]
                    }, {
                        j: "span",
                        T: "ytp-countdown-timer-time",
                        zK: "{{duration}}"
                    }]
                }]
            });
            this.api = l;
            this.Y = this.GK("ytp-svg-countdown-timer-ring");
            this.C = null;
            this.W = this.G = 0;
            this.V = !1;
            this.X = 0;
            this.api.createClientVe(this.element, this, 159628)
        },
        PQ5 = function(l) {
            l.C || (l.G = 5E3, l.W = (0, g.tF)(), l.C = new g.j5(function() {
                fui(l)
            }, null), fui(l))
        },
        fui = function(l) {
            if (!l.V) {
                var E = Math.min((0, g.tF)() - l.W, l.G);
                var e = l.G - E;
                E = l.G === 0 ? 0 : Math.max(e / l.G, 0);
                e = Math.round(e / 1E3);
                l.Y.setAttribute("stroke-dashoffset", "" + -211 * (E + 1));
                l.updateValue("duration", e);
                E <= 0 && l.C ? l.stopTimer() : l.C && l.C.start()
            }
        },
        kku = function(l) {
            g.Vc.call(this, l);
            this.D = l;
            this.C = new g.oE(this);
            this.V = null;
            this.Y = !1;
            this.countdownTimer = null;
            this.U = !1;
            RX5(this);
            g.L(this, this.C);
            this.load()
        },
        F8B = function(l) {
            var E = g.htH(l.D);
            E !== l.U && (l.U = E, l.Z && (l.Z.dispose(), l.Z = null), l.G && (l.G.dispose(), l.G = null), l.W && (l.W.dispose(), l.W = null), l.V && (l.V.stop(), l.V.dispose(), l.V = null), E && (E = g.F5(l.D), l.D.isEmbedsShortsMode() && (l.W = new g.W({
                j: "div",
                T: "ytp-pause-overlay-backdrop",
                J: {
                    tabIndex: "-1"
                }
            }), g.L(l, l.W), g.lb(l.D, l.W.element, 4), l.V = new g.wY(l.W, 1E3, !1, 100), g.L(l, l.V), l.W.hide()), l.Z = new g.W({
                j: "div",
                T: "ytp-pause-overlay-container",
                J: {
                    tabIndex: "-1"
                }
            }), g.L(l, l.Z), l.G = new CN(l.D, E), g.L(l, l.G), l.G.AO(l.Z.element), g.lb(l.D, l.Z.element,
                4), hXu(l, l.D.getPlayerStateObject())))
        },
        hXu = function(l, E) {
            l.V && (!g.G(E, 4) && !g.G(E, 2) || g.G(E, 1024) ? l.V.hide() : l.V.show())
        },
        RX5 = function(l) {
            var E = l.D;
            l = !!E.isEmbedsShortsMode();
            g.u9(E.getRootNode(), "ytp-shorts-mode", l);
            if (E = E.getVideoData()) E.tU = l
        },
        YE = function(l, E) {
            var e = l.D.N();
            l = {
                adSource: "EMBEDS_AD_SOURCE_YOUTUBE",
                breakType: l.D.getCurrentTime() === 0 ? "EMBEDS_AD_BREAK_TYPE_PRE_ROLL" : l.D.getPlayerState() === 0 ? "EMBEDS_AD_BREAK_TYPE_POST_ROLL" : "EMBEDS_AD_BREAK_TYPE_MID_ROLL",
                embedUrl: g.iQT(l.D.N().loaderUrl),
                eventType: E,
                youtubeHost: g.vt(l.D.N().Ri) || ""
            };
            l.embeddedPlayerMode = e.pJ;
            g.CU("embedsAdEvent", l)
        };
    g.p(DJu, g.W);
    g.D = DJu.prototype;
    g.D.hide = function() {
        this.Y = !0;
        g.W.prototype.hide.call(this);
        peB(this, !1)
    };
    g.D.show = function() {
        this.Y = !1;
        g.W.prototype.show.call(this);
        peB(this, !0)
    };
    g.D.isHidden = function() {
        return this.Y
    };
    g.D.yF = function() {
        this.scrollTo(this.scrollPosition - this.containerWidth)
    };
    g.D.N_ = function() {
        this.scrollTo(this.scrollPosition + this.containerWidth)
    };
    g.D.resize = function(l, E) {
        var e = this.api.N(),
            d = 16 / 9,
            C = l.width >= 650,
            x = l.width < 480 || l.height < 290,
            Y = Math.min(this.suggestionData.length, this.C.length);
        if (Math.min(l.width, l.height) <= 150 || Y === 0 || !e.yh) this.hide();
        else {
            var B;
            if (C) {
                var q = B = 28;
                this.V = 16
            } else this.V = q = B = 8;
            if (x) {
                var O = 6;
                C = 14;
                var M = 12;
                x = 24;
                e = 12
            } else O = 8, C = 18, M = 16, x = 36, e = 16;
            l = l.width - (48 + B + q);
            B = Math.ceil(l / 150);
            B = Math.min(3, B);
            q = l / B - this.V;
            var v = Math.floor(q / d);
            E && v + 100 > E && q > 50 && (v = Math.max(E, 50 / d), B = Math.ceil(l / (d * (v - 100) + this.V)), q = l / B - this.V,
                v = Math.floor(q / d));
            q < 50 || g.zu(this.api) ? this.hide() : this.show();
            for (E = 0; E < Y; E++) {
                d = this.C[E];
                var N = d.GK("ytp-suggestion-image");
                N.style.width = q + "px";
                N.style.height = v + "px";
                d.GK("ytp-suggestion-title").style.width = q + "px";
                d.GK("ytp-suggestion-author").style.width = q + "px";
                d = d.GK("ytp-suggestion-duration");
                d.style.display = d && q < 100 ? "none" : ""
            }
            Y = C + O + M + 4;
            this.X = Y + e + (v - x) / 2;
            this.suggestions.element.style.height = v + Y + "px";
            this.G = q;
            this.containerWidth = l;
            this.columns = B;
            this.scrollPosition = 0;
            this.suggestions.element.scrollLeft = -0;
            K8u(this)
        }
    };
    g.D.onVideoDataChange = function() {
        var l = this.api.getVideoData(),
            E = this.api.N();
        this.K = l.HB ? !1 : E.W;
        l.suggestions ? this.suggestionData = g.aM(l.suggestions, function(e) {
            return e && !e.playlistId
        }) : this.suggestionData.length = 0;
        UJW(this);
        l.HB ? this.title.update({
            title: g.uO("More videos from $DNI_RELATED_CHANNEL", {
                DNI_RELATED_CHANNEL: l.author
            })
        }) : this.title.update({
            title: "More videos on YouTube"
        })
    };
    g.D.scrollTo = function(l) {
        l = g.$1(l, this.containerWidth - this.suggestionData.length * (this.G + this.V), 0);
        this.U.start(this.scrollPosition, l, 1E3);
        this.scrollPosition = l;
        K8u(this);
        peB(this, !0)
    };
    g.p(ld, g.gl);
    ld.prototype.show = function() {
        g.gl.prototype.show.call(this);
        y5o(this, this.api.SZ().getPlayerSize())
    };
    ld.prototype.resize = function(l) {
        g.gl.prototype.resize.call(this, l);
        this.C && (y5o(this, l), g.u9(this.element, "related-on-error-overlay-visible", !this.C.isHidden()))
    };
    ld.prototype.V = function(l) {
        g.gl.prototype.V.call(this, l);
        var E = this.api.getVideoData();
        if (E.xH || E.playerErrorMessageRenderer)(l = E.xH) ? Vku(this, l) : E.playerErrorMessageRenderer && Vku(this, E.playerErrorMessageRenderer);
        else {
            var e;
            l.G9 && (E.A8 ? tkx(E.A8) ? e = g.O8(E.A8) : e = g.WQ(g.q8(E.A8)) : e = g.WQ(l.G9), this.n3(e, "subreason"))
        }
    };
    g.p(od6, g.W);
    g.D = od6.prototype;
    g.D.onVideoDataChange = function() {
        var l = this.api.getVideoData(),
            E = J5K(),
            e = 96714;
        g.H0(l) ? (E = bdx(), e = 216165, g.d4(this.element, "ytp-music-impression-link")) : g.xP(this.element, "ytp-music-impression-link");
        this.api.N().B("embeds_enable_emc3ds_woyt_counterfactual") && g.d4(this.element, "ytp-woyt-emc3ds-cf");
        this.updateValue("logoSvg", E);
        this.api.hasVe(this.element) && this.api.destroyVe(this.element);
        this.api.createClientVe(this.element, this, e)
    };
    g.D.G1 = function() {
        this.api.getPlayerStateObject().isCued() || (this.hide(), this.api.logVisibility(this.element, !1))
    };
    g.D.bC = function() {
        var l = this.api.getVideoData(),
            E = this.api.N(),
            e = this.api.getVideoData().HB,
            d = E.us && !E.B("embeds_enable_emc3ds_woyt_counterfactual"),
            C = !E.yh,
            x = this.C.mq() && !E.B("embeds_enable_emc3ds_woyt_counterfactual");
        E = E.G;
        d || x || e || C || E || this.api.isEmbedsShortsMode() || !l.videoId ? (this.hide(), this.api.logVisibility(this.element, !1)) : (l = A5_(this), this.updateValue("url", l), this.show())
    };
    g.D.onClick = function(l) {
        this.api.B("web_player_log_click_before_generating_ve_conversion_params") && this.api.logClick(this.element);
        var E = A5_(this);
        g.sA(E, this.api, l);
        this.api.B("web_player_log_click_before_generating_ve_conversion_params") || this.api.logClick(this.element)
    };
    g.D.show = function() {
        this.api.getPlayerStateObject().isCued() && (g.W.prototype.show.call(this), this.api.hasVe(this.element) && this.api.logVisibility(this.element, !0))
    };
    g.p(Ei, g.W);
    Ei.prototype.G1 = function() {
        var l = this.api.getPlayerStateObject();
        !this.api.S9() || g.G(l, 2) && g.Gu(this.api) || g.G(l, 64) ? (this.api.logVisibility(this.C, !1), this.api.logVisibility(this.forwardButton, !1), this.hide()) : (this.show(), this.api.logVisibility(this.C, !0), this.api.logVisibility(this.forwardButton, !0))
    };
    Ei.prototype.V = function() {
        this.api.seekBy(-10 * this.api.getPlaybackRate(), void 0, void 0, 83);
        this.api.logClick(this.C)
    };
    Ei.prototype.G = function() {
        this.api.seekBy(10 * this.api.getPlaybackRate(), void 0, void 0, 82);
        this.api.logClick(this.forwardButton)
    };
    g.p(en, g.W);
    en.prototype.G = function() {
        var l = this.api.getPlayerStateObject(),
            E = this.api.getVideoData();
        g.u9(this.element, "ytp-shorts-mode", this.api.isEmbedsShortsMode());
        !E.mutedAutoplay || E.limitedPlaybackDurationInSeconds === 0 && E.endSeconds === 0 && E.mutedAutoplayDurationMode === 2 || (g.G(l, 2) && !this.qw ? (this.show(), this.C || (this.C = new g.$Q(this.api), g.L(this, this.C), this.C.AO(this.W, 0), this.C.show()), l = this.api.getVideoData(), this.updateValue("text", l.g_), g.u9(this.element, "ytp-muted-autoplay-show-end-panel", !0), this.api.logVisibility(this.element,
            this.qw), this.api.cg("onMutedAutoplayEnds")) : this.hide())
    };
    en.prototype.onClick = function() {
        if (!this.V) {
            this.C && (this.C.cS(), this.C = null);
            g.u9(this.api.getRootNode(), "ytp-muted-autoplay", !1);
            var l = this.api.getVideoData(),
                E = this.api.getCurrentTime();
            NIx(l);
            this.api.loadVideoById(l.videoId, E);
            this.api.XC();
            this.api.logClick(this.element);
            this.hide();
            this.V = !0
        }
    };
    en.prototype.onMutedAutoplayStarts = function() {
        this.V = !1;
        this.C && (this.C.cS(), this.C = null)
    };
    g.p(dZ, g.W);
    g.D = dZ.prototype;
    g.D.onStateChange = function(l) {
        this.L3(l.state)
    };
    g.D.L3 = function(l) {
        this.state !== l && (this.state = l);
        QMB(this)
    };
    g.D.onVideoDataChange = function() {
        var l = this.api.N();
        l.G && g.d4(this.element, "ytp-no-hover");
        var E = this.api.getVideoData();
        E.videoId && !l.G ? (l = this.api.getVideoUrl(!0, !1, !1, !0), this.updateValue("url", l), this.C || (this.C = this.listen("click", this.onClick))) : this.C && (this.updateValue("url", null), this.Dn(this.C), this.C = null);
        l = J5K();
        var e = 76758;
        g.H0(E) && (l = bdx(), e = 216164);
        this.updateValue("logoSvg", l);
        this.api.hasVe(this.element) && this.api.destroyVe(this.element);
        this.api.createClientVe(this.element, this,
            e);
        QMB(this)
    };
    g.D.onClick = function(l) {
        this.api.B("web_player_log_click_before_generating_ve_conversion_params") && this.api.logClick(this.element);
        var E = this.api.getVideoUrl(!g.ye(l), !1, !0, !0);
        if (this.api.B("web_player_log_click_before_generating_ve_conversion_params")) {
            var e = {};
            g.fw(this.api, "addEmbedsConversionTrackingParams", [e]);
            E = g.Uy(E, e)
        }
        g.sA(E, this.api, l);
        this.api.B("web_player_log_click_before_generating_ve_conversion_params") || this.api.logClick(this.element)
    };
    g.D.l2 = function(l) {
        if ((l = l.width < 480) && !this.V || !l && this.V) {
            var E = new g.W(J5K()),
                e = this.GK("ytp-watermark");
            g.u9(e, "ytp-watermark-small", l);
            g.KQ(e);
            E.AO(e);
            this.V = l
        }
    };
    g.p(IuN, g.W);
    g.D = IuN.prototype;
    g.D.W8 = function() {
        var l = this.api.getPlayerStateObject();
        !this.api.getVideoData().mutedAutoplay || g.G(l, 2) ? this.hide() : this.qw || (g.W.prototype.show.call(this), this.api.logVisibility(this.element, this.qw))
    };
    g.D.Gb = function() {
        this.C && this.C.hide()
    };
    g.D.onAutoplayBlocked = function() {
        this.hide();
        NIx(this.api.getVideoData())
    };
    g.D.onClick = function() {
        if (!this.V) {
            g.u9(this.api.getRootNode(), "ytp-muted-autoplay", !1);
            var l = this.api.getVideoData(),
                E = this.api.getCurrentTime();
            NIx(l);
            this.api.loadVideoById(l.videoId, E);
            this.api.XC();
            this.api.logClick(this.element);
            this.api.cg("onMutedAutoplayEnds");
            this.V = !0
        }
    };
    g.D.onMutedAutoplayEnds = function() {
        this.watermark && (this.watermark.cS(), this.watermark = null)
    };
    g.p(CN, g.W);
    CN.prototype.hide = function() {
        g.xP(this.api.getRootNode(), "ytp-expand-pause-overlay");
        g.W.prototype.hide.call(this)
    };
    CN.prototype.W = function() {
        this.V = !0;
        g.xP(this.api.getRootNode(), "ytp-expand-pause-overlay");
        this.api.isEmbedsShortsMode() && this.api.logVisibility(this.element, !1);
        this.expandButton.focus()
    };
    CN.prototype.X = function() {
        this.V = !1;
        g.d4(this.api.getRootNode(), "ytp-expand-pause-overlay");
        this.api.isEmbedsShortsMode() && this.api.logVisibility(this.element, !0);
        this.focus()
    };
    CN.prototype.TK = function() {
        var l = this.api.getPlayerStateObject();
        g.G(l, 1) || g.G(l, 16) || g.G(l, 32) || (!g.G(l, 4) || g.G(l, 2) || g.G(l, 1024) ? (this.V || this.api.logVisibility(this.element, !1), this.fade.hide()) : this.C.hasSuggestions() && (this.V || (g.d4(this.api.getRootNode(), "ytp-expand-pause-overlay"), g.la(this.C), this.C.show(), this.api.logVisibility(this.element, !0)), this.fade.show()))
    };
    g.p(xE, g.W);
    xE.prototype.show = function() {
        g.W.prototype.show.call(this);
        this.api.logVisibility(this.element, !0)
    };
    xE.prototype.stopTimer = function() {
        this.C && (this.C.dispose(), this.C = null, this.V = !1)
    };
    xE.prototype.cS = function() {
        this.stopTimer();
        g.W.prototype.cS.call(this)
    };
    g.p(kku, g.Vc);
    g.D = kku.prototype;
    g.D.NW = function() {
        return !1
    };
    g.D.create = function() {
        var l = this.D.N(),
            E = g.F5(this.D),
            e, d = (e = this.D.getVideoData()) == null ? void 0 : e.clientPlaybackNonce;
        d && g.QN({
            clientPlaybackNonce: d
        });
        l.bO && !l.disableOrganicUi && F8B(this);
        var C;
        (C = l.getWebPlayerContextConfig()) != null && C.embedsEnableEmc3ds || (this.K = new IuN(this.D), g.L(this, this.K), g.lb(this.D, this.K.element, 4), this.VV = new en(this.D), g.L(this, this.VV), g.lb(this.D, this.VV.element, 4));
        l.us && (this.watermark = new dZ(this.D), g.L(this, this.watermark), g.lb(this.D, this.watermark.element, 8));
        E && !l.disableOrganicUi && (this.X = new od6(this.D, E), g.L(this, this.X), g.lb(this.D, this.X.element, 8), this.D.isMutedByEmbedsMutedAutoplay() && (this.onMutedAutoplayStarts(), this.X.hide()));
        l.V && !l.disableOrganicUi && (this.o4 = new Ei(this.D), g.L(this, this.o4), g.lb(this.D, this.o4.element, 4));
        this.C.L(this.D, "appresize", this.l2);
        this.C.L(this.D, "presentingplayerstatechange", this.G1);
        this.C.L(this.D, "videodatachange", this.onVideoDataChange);
        this.C.L(this.D, "videoplayerreset", this.onReset);
        this.C.L(this.D, "onMutedAutoplayStarts",
            this.onMutedAutoplayStarts);
        this.C.L(this.D, "onAdStart", this.onAdStart);
        this.C.L(this.D, "onAdComplete", this.onAdComplete);
        this.C.L(this.D, "onAdSkip", this.onAdSkip);
        this.C.L(this.D, "onAdStateChange", this.onAdStateChange);
        if (this.Y = g.YC(g.vI(l))) this.countdownTimer = new xE(this.D), g.L(this, this.countdownTimer), g.lb(this.D, this.countdownTimer.element, 4), this.countdownTimer.hide(), this.C.L(this.D, g.zw("embeds"), this.onCueRangeEnter), this.C.L(this.D, g.r9("embeds"), this.onCueRangeExit);
        this.Mk(this.D.getPlayerStateObject());
        this.player.jB("embed");
        var x, Y;
        ((x = this.D.N().getWebPlayerContextConfig()) == null ? 0 : (Y = x.embedsHostFlags) == null ? 0 : Y.allowOverridingVisitorDataPlayerVars) && (l = g.g6("IDENTITY_MEMENTO")) && this.D.By("onMementoChange", l)
    };
    g.D.onCueRangeEnter = function(l) {
        l.getId() === "countdown timer" && this.countdownTimer && (this.countdownTimer.show(), PQ5(this.countdownTimer))
    };
    g.D.onCueRangeExit = function(l) {
        l.getId() === "countdown timer" && this.countdownTimer && (this.countdownTimer.stopTimer(), this.countdownTimer.hide())
    };
    g.D.l2 = function() {
        var l = this.D.SZ().getPlayerSize();
        this.Bp && this.Bp.resize(l)
    };
    g.D.onReset = function() {
        RX5(this)
    };
    g.D.G1 = function(l) {
        this.Mk(l.state)
    };
    g.D.Mk = function(l) {
        g.G(l, 128) ? (this.Bp || (this.Bp = new ld(this.D), g.L(this, this.Bp), g.lb(this.D, this.Bp.element, 4)), this.Bp.V(l.m6), this.Bp.show(), g.d4(this.D.getRootNode(), "ytp-embed-error")) : this.Bp && (this.Bp.dispose(), this.Bp = null, g.xP(this.D.getRootNode(), "ytp-embed-error"));
        if (this.countdownTimer && this.countdownTimer.C)
            if (g.G(l, 64)) this.countdownTimer.hide(), this.countdownTimer.stopTimer();
            else if (l.isPaused()) {
            var E = this.countdownTimer;
            E.V || (E.V = !0, E.X = (0, g.tF)())
        } else l.isPlaying() && this.countdownTimer.V &&
            (E = this.countdownTimer, E.V && (E.W += (0, g.tF)() - E.X, E.V = !1, fui(E)));
        hXu(this, l)
    };
    g.D.onMutedAutoplayStarts = function() {
        this.D.getVideoData().mutedAutoplay && this.K && g.u9(this.D.getRootNode(), "ytp-muted-autoplay", !0)
    };
    g.D.onVideoDataChange = function(l, E) {
        var e = this.P7 !== E.videoId;
        l = !e && l === "dataloaded";
        var d = {
            isShortsModeEnabled: !!this.D.isEmbedsShortsMode()
        };
        g.CU("embedsVideoDataDidChange", {
            clientPlaybackNonce: E.clientPlaybackNonce,
            isReload: l,
            runtimeEnabledFeatures: d
        });
        e && (this.P7 = E.videoId, this.countdownTimer && (this.countdownTimer.show(), this.countdownTimer.hide()), this.Y && (this.D.tE("embeds"), E.isAd() || E.limitedPlaybackDurationInSeconds < 5 || g.zu(this.D) || (E = Math.max((E.startSeconds + E.limitedPlaybackDurationInSeconds -
            5) * 1E3, 0), E = new g.X1(E, E + 5E3, {
            id: "countdown timer",
            namespace: "embeds"
        }), this.D.Lh([E]))), this.D.N().bO && !this.D.N().disableOrganicUi && (RX5(this), F8B(this)));
        this.D.N().G && this.G && this.G.detach()
    };
    g.D.onAdStart = function() {
        YE(this, "EMBEDS_AD_EVENT_TYPE_AD_STARTED")
    };
    g.D.onAdComplete = function() {
        YE(this, "EMBEDS_AD_EVENT_TYPE_AD_COMPLETED")
    };
    g.D.onAdSkip = function() {
        YE(this, "EMBEDS_AD_EVENT_TYPE_AD_SKIPPED")
    };
    g.D.onAdStateChange = function(l) {
        l === 2 && YE(this, "EMBEDS_AD_EVENT_TYPE_AD_PAUSED")
    };
    g.HQ("embed", kku);
})(_yt_player);