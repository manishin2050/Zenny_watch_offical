(function(g) {
    var window = this;
    'use strict';
    var L8i = function(l) {
            l.publish("autonavvisibility")
        },
        c56 = function(l, E) {
            l.x8("onAutonavCoundownStarted", E)
        },
        ido = function(l) {
            var E, e, d;
            return l == null ? void 0 : (E = l.playerOverlays) == null ? void 0 : (e = E.playerOverlayRenderer) == null ? void 0 : (d = e.autoplay) == null ? void 0 : d.playerOverlayAutoplayRenderer
        },
        ud = function(l) {
            var E = l.N(),
                e = E.W;
            g.W.call(this, {
                j: "a",
                T: "ytp-autonav-suggestion-card",
                J: {
                    href: "{{url}}",
                    target: e ? E.U : "",
                    "aria-label": "{{aria_label}}",
                    "data-is-live": "{{is_live}}",
                    "data-is-list": "{{is_list}}",
                    "data-is-mix": "{{is_mix}}",
                    "data-is-upcoming": "{{is_upcoming}}"
                },
                S: [{
                    j: "div",
                    R4: ["ytp-autonav-endscreen-upnext-thumbnail", "ytp-autonav-thumbnail-small"],
                    J: {
                        style: "{{background}}"
                    },
                    S: [{
                        j: "div",
                        J: {
                            "aria-label": "{{timestamp}}"
                        },
                        R4: ["ytp-autonav-timestamp"],
                        zK: "{{duration}}"
                    }, {
                        j: "div",
                        R4: ["ytp-autonav-live-stamp"],
                        zK: "Live"
                    }, {
                        j: "div",
                        R4: ["ytp-autonav-upcoming-stamp"],
                        zK: "Upcoming"
                    }, {
                        j: "div",
                        T: "ytp-autonav-list-overlay",
                        S: [{
                            j: "div",
                            T: "ytp-autonav-mix-text",
                            zK: "Mix"
                        }, {
                            j: "div",
                            T: "ytp-autonav-mix-icon"
                        }]
                    }]
                }, {
                    j: "div",
                    R4: ["ytp-autonav-endscreen-upnext-title", "ytp-autonav-title-card"],
                    zK: "{{title}}"
                }, {
                    j: "div",
                    R4: ["ytp-autonav-endscreen-upnext-author", "ytp-autonav-author-card"],
                    zK: "{{author}}"
                }, {
                    j: "div",
                    R4: ["ytp-autonav-endscreen-upnext-author", "ytp-autonav-view-and-date-card"],
                    zK: "{{views_and_publish_time}}"
                }]
            });
            this.D = l;
            this.suggestion =
                null;
            this.C = e;
            this.listen("click", this.onClick);
            this.listen("keypress", this.onKeyPress)
        },
        BP = function(l, E) {
            E = E === void 0 ? !1 : E;
            g.W.call(this, {
                j: "div",
                T: "ytp-autonav-endscreen-countdown-overlay"
            });
            var e = this;
            this.Y = E;
            this.cancelCommand = this.X = void 0;
            this.G = 0;
            this.container = new g.W({
                j: "div",
                T: "ytp-autonav-endscreen-countdown-container"
            });
            g.L(this, this.container);
            this.container.AO(this.element);
            E = l.N();
            var d = E.W;
            this.D = l;
            this.suggestion = null;
            this.onVideoDataChange("newdata", this.D.getVideoData());
            this.L(l, "videodatachange", this.onVideoDataChange);
            this.C = new g.W({
                j: "div",
                T: "ytp-autonav-endscreen-upnext-container",
                J: {
                    "aria-label": "{{aria_label}}",
                    "data-is-live": "{{is_live}}",
                    "data-is-list": "{{is_list}}",
                    "data-is-mix": "{{is_mix}}",
                    "data-is-upcoming": "{{is_upcoming}}"
                },
                S: [{
                    j: "div",
                    T: "ytp-autonav-endscreen-upnext-header"
                }, {
                    j: "div",
                    T: "ytp-autonav-endscreen-upnext-alternative-header",
                    zK: "{{autoplayAlternativeHeader}}"
                }, {
                    j: "a",
                    T: "ytp-autonav-endscreen-link-container",
                    J: {
                        href: "{{url}}",
                        target: d ? E.U : ""
                    },
                    S: [{
                        j: "div",
                        T: "ytp-autonav-endscreen-upnext-thumbnail",
                        J: {
                            style: "{{background}}"
                        },
                        S: [{
                            j: "div",
                            J: {
                                "aria-label": "{{timestamp}}"
                            },
                            R4: ["ytp-autonav-timestamp"],
                            zK: "{{duration}}"
                        }, {
                            j: "div",
                            R4: ["ytp-autonav-live-stamp"],
                            zK: "Live"
                        }, {
                            j: "div",
                            R4: ["ytp-autonav-upcoming-stamp"],
                            zK: "Upcoming"
                        }]
                    }, {
                        j: "div",
                        T: "ytp-autonav-endscreen-video-info",
                        S: [{
                            j: "div",
                            T: "ytp-autonav-endscreen-premium-badge"
                        }, {
                            j: "div",
                            T: "ytp-autonav-endscreen-upnext-title",
                            zK: "{{title}}"
                        }, {
                            j: "div",
                            T: "ytp-autonav-endscreen-upnext-author",
                            zK: "{{author}}"
                        }, {
                            j: "div",
                            T: "ytp-autonav-view-and-date",
                            zK: "{{views_and_publish_time}}"
                        }, {
                            j: "div",
                            T: "ytp-autonav-author-and-view",
                            zK: "{{author_and_views}}"
                        }]
                    }]
                }]
            });
            g.L(this, this.C);
            this.C.AO(this.container.element);
            d || this.L(this.C.GK("ytp-autonav-endscreen-link-container"), "click", this.lC);
            this.D.createClientVe(this.container.element, this, 115127);
            this.D.createClientVe(this.C.GK("ytp-autonav-endscreen-link-container"), this, 115128);
            this.overlay = new g.W({
                j: "div",
                T: "ytp-autonav-overlay"
            });
            g.L(this, this.overlay);
            this.overlay.AO(this.container.element);
            this.V = new g.W({
                j: "div",
                T: "ytp-autonav-endscreen-button-container"
            });
            g.L(this, this.V);
            this.V.AO(this.container.element);
            this.cancelButton = new g.W({
                j: "button",
                R4: ["ytp-autonav-endscreen-upnext-button", "ytp-autonav-endscreen-upnext-cancel-button", E.B("web_modern_buttons") ? "ytp-autonav-endscreen-upnext-button-rounded" : ""],
                J: {
                    "aria-label": "Cancel auto-play"
                },
                zK: "Cancel"
            });
            g.L(this, this.cancelButton);
            this.cancelButton.AO(this.V.element);
            this.cancelButton.listen("click", this.Ei, this);
            this.D.createClientVe(this.cancelButton.element, this, 115129);
            this.playButton = new g.W({
                j: "a",
                R4: ["ytp-autonav-endscreen-upnext-button", "ytp-autonav-endscreen-upnext-play-button",
                    E.B("web_modern_buttons") ? "ytp-autonav-endscreen-upnext-button-rounded" : ""
                ],
                J: {
                    href: "{{url}}",
                    role: "button",
                    "aria-label": "Play next video"
                },
                zK: "Play now"
            });
            g.L(this, this.playButton);
            this.playButton.AO(this.V.element);
            this.playButton.listen("click", this.lC, this);
            this.D.createServerVe(this.playButton.element, this.playButton, !0);
            (E = this.D.getVideoData()) && Zd5(this, E);
            this.W = new g.Gv(function() {
                $JH(e)
            }, 500);
            g.L(this, this.W);
            this.xV();
            this.L(l, "autonavvisibility", this.xV);
            this.D.B("web_autonav_color_transition") && (this.L(l, "autonavchange", this.fD), this.L(l, "onAutonavCoundownStarted", this.rO9))
        },
        qY = function(l) {
            var E = l.D.v5(!0, l.D.isFullscreen());
            g.u9(l.container.element, "ytp-autonav-endscreen-small-mode", l.mq(E));
            g.u9(l.container.element, "ytp-autonav-endscreen-is-premium", !!l.suggestion && !!l.suggestion.jHO);
            g.u9(l.D.getRootNode(), "ytp-autonav-endscreen-cancelled-state", !l.D.vy());
            g.u9(l.D.getRootNode(), "countdown-running", l.Av());
            g.u9(l.container.element, "ytp-player-content", l.D.vy());
            g.W_(l.overlay.element, {
                width: E.width + "px"
            });
            if (!l.Av()) {
                l.D.vy() ? TID(l, Math.round(gdo(l) / 1E3)) : TID(l);
                E = !!l.suggestion && !!l.suggestion.uM;
                var e = l.D.vy() ||
                    !E;
                g.u9(l.container.element, "ytp-autonav-endscreen-upnext-alternative-header-only", !e && E);
                g.u9(l.container.element, "ytp-autonav-endscreen-upnext-no-alternative-header", e && !E);
                l.V.SD(l.D.vy());
                g.u9(l.element, "ytp-enable-w2w-color-transitions", W85(l))
            }
        },
        $JH = function(l) {
            var E = gdo(l),
                e = Math,
                d = e.min;
            var C = l.G ? Date.now() - l.G : 0;
            e = d.call(e, C, E);
            TID(l, Math.ceil((E - e) / 1E3));
            E - e <= 500 && l.Av() ? l.select(!0) : l.Av() && l.W.start()
        },
        gdo = function(l) {
            if (l.D.isFullscreen()) {
                var E;
                l = (E = l.D.getVideoData()) == null ? void 0 : E.Pq;
                return l === -1 || l === void 0 ? 8E3 : l
            }
            return l.D.cU() >= 0 ? l.D.cU() : g.CV(l.D.N().experiments, "autoplay_time") || 1E4
        },
        Zd5 = function(l, E) {
            E = E.getWatchNextResponse();
            var e, d;
            E = (e = ido(E)) == null ? void 0 : (d = e.nextButton) == null ? void 0 : d.buttonRenderer;
            l.X = E == null ? void 0 : E.navigationEndpoint;
            e = E == null ? void 0 : E.trackingParams;
            l.playButton && e && l.D.setTrackingParams(l.playButton.element, e)
        },
        W85 = function(l) {
            var E;
            return !((E = l.D.getVideoData()) == null || !E.watchToWatchTransitionRenderer)
        },
        TID = function(l, E) {
            E = E === void 0 ? -1 : E;
            l = l.C.GK("ytp-autonav-endscreen-upnext-header");
            g.KQ(l);
            if (E >= 0) {
                E = String(E);
                var e = "Up next in $SECONDS".match(RegExp("\\$SECONDS", "gi"))[0],
                    d = "Up next in $SECONDS".indexOf(e);
                if (d >= 0) {
                    l.appendChild(g.Dq("Up next in $SECONDS".slice(0, d)));
                    var C = g.bV("span");
                    g.Ed(C, "ytp-autonav-endscreen-upnext-header-countdown-number");
                    g.tC(C, E);
                    l.appendChild(C);
                    l.appendChild(g.Dq("Up next in $SECONDS".slice(d + e.length)));
                    return
                }
            }
            g.tC(l, "Up next")
        },
        Oi = function(l, E) {
            g.W.call(this, {
                j: "div",
                R4: ["html5-endscreen", "ytp-player-content", E || "base-endscreen"]
            });
            this.created = !1;
            this.player = l
        },
        MY = function(l) {
            g.W.call(this, {
                j: "div",
                R4: ["ytp-upnext", "ytp-player-content"],
                J: {
                    "aria-label": "{{aria_label}}"
                },
                S: [{
                    j: "div",
                    T: "ytp-cued-thumbnail-overlay-image",
                    J: {
                        style: "{{background}}"
                    }
                }, {
                    j: "span",
                    T: "ytp-upnext-top",
                    S: [{
                        j: "span",
                        T: "ytp-upnext-header",
                        zK: "Up Next"
                    }, {
                        j: "span",
                        T: "ytp-upnext-title",
                        zK: "{{title}}"
                    }, {
                        j: "span",
                        T: "ytp-upnext-author",
                        zK: "{{author}}"
                    }]
                }, {
                    j: "a",
                    T: "ytp-upnext-autoplay-icon",
                    J: {
                        role: "button",
                        href: "{{url}}",
                        "aria-label": "Play next video"
                    },
                    S: [{
                        j: "svg",
                        J: {
                            height: "100%",
                            version: "1.1",
                            viewBox: "0 0 72 72",
                            width: "100%"
                        },
                        S: [{
                            j: "circle",
                            T: "ytp-svg-autoplay-circle",
                            J: {
                                cx: "36",
                                cy: "36",
                                fill: "#fff",
                                "fill-opacity": "0.3",
                                r: "31.5"
                            }
                        }, {
                            j: "circle",
                            T: "ytp-svg-autoplay-ring",
                            J: {
                                cx: "-36",
                                cy: "36",
                                "fill-opacity": "0",
                                r: "33.5",
                                stroke: "#FFFFFF",
                                "stroke-dasharray": "211",
                                "stroke-dashoffset": "-211",
                                "stroke-width": "4",
                                transform: "rotate(-90)"
                            }
                        }, {
                            j: "path",
                            T: "ytp-svg-fill",
                            J: {
                                d: "M 24,48 41,36 24,24 V 48 z M 44,24 v 24 h 4 V 24 h -4 z"
                            }
                        }]
                    }]
                }, {
                    j: "span",
                    T: "ytp-upnext-bottom",
                    S: [{
                        j: "span",
                        T: "ytp-upnext-cancel"
                    }, {
                        j: "span",
                        T: "ytp-upnext-paused",
                        zK: "Auto-play is paused"
                    }]
                }]
            });
            this.api = l;
            this.cancelButton = null;
            this.X = this.GK("ytp-svg-autoplay-ring");
            this.G = this.notification = this.C = this.suggestion = null;
            this.W = new g.Gv(this.Ha, 5E3, this);
            this.V = 0;
            var E = this.GK("ytp-upnext-cancel");
            this.cancelButton = new g.W({
                j: "button",
                R4: ["ytp-upnext-cancel-button", "ytp-button"],
                J: {
                    tabindex: "0",
                    "aria-label": "Cancel auto-play"
                },
                zK: "Cancel"
            });
            g.L(this, this.cancelButton);
            this.cancelButton.listen("click", this.bz, this);
            this.cancelButton.AO(E);
            this.cancelButton && this.api.createClientVe(this.cancelButton.element,
                this, 115129);
            g.L(this, this.W);
            this.api.createClientVe(this.element, this, 18788);
            E = this.GK("ytp-upnext-autoplay-icon");
            this.L(E, "click", this.xM);
            this.api.createClientVe(E, this, 115130);
            this.uC();
            this.L(l, "autonavvisibility", this.uC);
            this.L(l, "mdxnowautoplaying", this.Jg6);
            this.L(l, "mdxautoplaycanceled", this.yg6);
            g.u9(this.element, "ytp-upnext-mobile", this.api.N().V)
        },
        jMD = function(l, E) {
            if (E) return E;
            if (l.api.isFullscreen()) {
                var e;
                l = (e = l.api.getVideoData()) == null ? void 0 : e.Pq;
                return l === -1 || l === void 0 ? 8E3 : l
            }
            return l.api.cU() >= 0 ? l.api.cU() : g.CV(l.api.N().experiments, "autoplay_time") || 1E4
        },
        GkW = function(l, E) {
            E = jMD(l, E);
            var e = Math,
                d = e.min;
            var C = (0, g.tF)() - l.V;
            e = d.call(e, C, E);
            E = E === 0 ? 1 : Math.min(e / E, 1);
            l.X.setAttribute("stroke-dashoffset", "" + -211 * (E + 1));
            E >= 1 && l.Av() && l.api.getPresentingPlayerType() !== 3 ? l.select(!0) : l.Av() && l.C.start()
        },
        vP = function(l) {
            Oi.call(this, l, "autonav-endscreen");
            this.overlay = this.videoData = null;
            this.table = new g.W({
                j: "div",
                T: "ytp-suggestion-panel",
                S: [{
                    j: "div",
                    R4: ["ytp-autonav-endscreen-upnext-header", "ytp-autonav-endscreen-more-videos"],
                    zK: "More videos"
                }]
            });
            this.K = new g.W({
                j: "div",
                T: "ytp-suggestions-container"
            });
            this.videos = [];
            this.G = null;
            this.X = this.Y = !1;
            this.V = new BP(this.player);
            g.L(this, this.V);
            this.V.AO(this.element);
            l.getVideoData().yh ? this.C = this.V : (this.C = new MY(l), g.lb(this.player, this.C.element, 4), g.L(this, this.C));
            this.overlay = new g.W({
                j: "div",
                T: "ytp-autonav-overlay-cancelled-state"
            });
            g.L(this, this.overlay);
            this.overlay.AO(this.element);
            this.W = new g.oE(this);
            g.L(this, this.W);
            g.L(this, this.table);
            this.table.AO(this.element);
            this.table.show();
            g.L(this, this.K);
            this.K.AO(this.table.element);
            this.hide()
        },
        NY = function(l) {
            var E = l.vy();
            E !== l.X && (l.X = E, L8i(l.player), l.X ? (l.V !== l.C && l.V.hide(), l.table.hide()) : (l.V !== l.C && l.V.show(), l.table.show()))
        },
        Xex = function(l) {
            Oi.call(this, l, "videowall-endscreen");
            var E = this;
            this.D = l;
            this.stills = [];
            this.G = this.videoData = null;
            this.W = this.Y = !1;
            this.K = null;
            g.d4(this.element, "modern-videowall-endscreen");
            this.V = new g.oE(this);
            g.L(this, this.V);
            this.X = new g.Gv(function() {
                g.d4(E.element, "ytp-show-tiles")
            }, 0);
            g.L(this, this.X);
            this.table = new g.dY({
                j: "div",
                T: "ytp-modern-endscreen-content"
            });
            g.L(this, this.table);
            this.table.AO(this.element);
            l.getVideoData().yh ? this.C = new BP(l, !0) : this.C = new MY(l);
            g.L(this, this.C);
            g.lb(this.player, this.C.element, 4);
            l.createClientVe(this.element, this, 158789);
            this.hide()
        },
        Js = function(l) {
            return g.EA(l.player) && l.Lt() && !l.G
        },
        bd = function(l) {
            var E = l.vy();
            E !== l.Y && (l.Y = E, L8i(l.player))
        },
        S7x = function(l) {
            Oi.call(this, l, "subscribecard-endscreen");
            this.C = new g.W({
                j: "div",
                T: "ytp-subscribe-card",
                S: [{
                    j: "img",
                    T: "ytp-author-image",
                    J: {
                        src: "{{profilePicture}}"
                    }
                }, {
                    j: "div",
                    T: "ytp-subscribe-card-right",
                    S: [{
                        j: "div",
                        T: "ytp-author-name",
                        zK: "{{author}}"
                    }, {
                        j: "div",
                        T: "html5-subscribe-button-container"
                    }]
                }]
            });
            g.L(this, this.C);
            this.C.AO(this.element);
            var E = l.getVideoData();
            this.subscribeButton = new g.Cl("Subscribe", null, "Unsubscribe", null, !0, !1, E.bE, E.subscribed, "trailer-endscreen", null, l, !1);
            g.L(this, this.subscribeButton);
            this.subscribeButton.AO(this.C.GK("html5-subscribe-button-container"));
            this.L(l, "videodatachange", this.TK);
            this.TK();
            this.hide()
        },
        Dk = function(l) {
            var E = l.N(),
                e = g.yK || g.EC ? {
                    style: "will-change: opacity"
                } : void 0,
                d = E.W,
                C = ["ytp-videowall-still"];
            E.V && C.push("ytp-videowall-show-text");
            g.W.call(this, {
                j: "a",
                R4: C,
                J: {
                    href: "{{url}}",
                    target: d ? E.U : "",
                    "aria-label": "{{aria_label}}",
                    "data-is-live": "{{is_live}}",
                    "data-is-list": "{{is_list}}",
                    "data-is-mix": "{{is_mix}}"
                },
                S: [{
                    j: "div",
                    T: "ytp-videowall-still-image",
                    J: {
                        style: "{{background}}"
                    }
                }, {
                    j: "span",
                    T: "ytp-videowall-still-info",
                    J: {
                        "aria-hidden": "true"
                    },
                    S: [{
                        j: "span",
                        T: "ytp-videowall-still-info-bg",
                        S: [{
                            j: "span",
                            T: "ytp-videowall-still-info-content",
                            J: e,
                            S: [{
                                    j: "span",
                                    T: "ytp-videowall-still-info-title",
                                    zK: "{{title}}"
                                },
                                {
                                    j: "span",
                                    T: "ytp-videowall-still-info-author",
                                    zK: "{{author_and_views}}"
                                }, {
                                    j: "span",
                                    T: "ytp-videowall-still-info-live",
                                    zK: "Live"
                                }, {
                                    j: "span",
                                    T: "ytp-videowall-still-info-duration",
                                    zK: "{{duration}}"
                                }
                            ]
                        }]
                    }]
                }, {
                    j: "span",
                    R4: ["ytp-videowall-still-listlabel-regular", "ytp-videowall-still-listlabel"],
                    J: {
                        "aria-hidden": "true"
                    },
                    S: [{
                        j: "span",
                        T: "ytp-videowall-still-listlabel-icon"
                    }, "Playlist", {
                        j: "span",
                        T: "ytp-videowall-still-listlabel-length",
                        S: [" (", {
                            j: "span",
                            zK: "{{playlist_length}}"
                        }, ")"]
                    }]
                }, {
                    j: "span",
                    R4: ["ytp-videowall-still-listlabel-mix",
                        "ytp-videowall-still-listlabel"
                    ],
                    J: {
                        "aria-hidden": "true"
                    },
                    S: [{
                        j: "span",
                        T: "ytp-videowall-still-listlabel-mix-icon"
                    }, "Mix", {
                        j: "span",
                        T: "ytp-videowall-still-listlabel-length",
                        zK: " (50+)"
                    }]
                }]
            });
            this.suggestion = null;
            this.V = d;
            this.api = l;
            this.C = new g.oE(this);
            g.L(this, this.C);
            this.listen("click", this.onClick);
            this.listen("keypress", this.onKeyPress);
            this.C.L(l, "videodatachange", this.onVideoDataChange);
            l.createServerVe(this.element, this);
            this.onVideoDataChange()
        },
        pN = function(l) {
            Oi.call(this, l, "videowall-endscreen");
            var E = this;
            this.D = l;
            this.G = 0;
            this.stills = [];
            this.W = this.videoData = null;
            this.X = this.K = !1;
            this.U = null;
            this.V = new g.oE(this);
            g.L(this, this.V);
            this.Y = new g.Gv(function() {
                g.d4(E.element, "ytp-show-tiles")
            }, 0);
            g.L(this, this.Y);
            var e = new g.W({
                j: "button",
                R4: ["ytp-button", "ytp-endscreen-previous"],
                J: {
                    "aria-label": "Previous"
                },
                S: [g.vF()]
            });
            g.L(this, e);
            e.AO(this.element);
            e.listen("click", this.Ui, this);
            this.table = new g.dY({
                j: "div",
                T: "ytp-endscreen-content"
            });
            g.L(this, this.table);
            this.table.AO(this.element);
            e = new g.W({
                j: "button",
                R4: ["ytp-button", "ytp-endscreen-next"],
                J: {
                    "aria-label": "Next"
                },
                S: [g.N8()]
            });
            g.L(this, e);
            e.AO(this.element);
            e.listen("click", this.eE, this);
            l.getVideoData().yh ? this.C = new BP(l, !0) : this.C =
                new MY(l);
            g.L(this, this.C);
            g.lb(this.player, this.C.element, 4);
            l.createClientVe(this.element, this, 158789);
            this.hide()
        },
        KN = function(l) {
            return g.EA(l.player) && l.Lt() && !l.W
        },
        Ui = function(l) {
            var E = l.vy();
            E !== l.K && (l.K = E, L8i(l.player))
        },
        zXD = function(l, E) {
            g.W.call(this, {
                j: "button",
                R4: ["ytp-watch-on-youtube-button", "ytp-button"],
                zK: "{{content}}"
            });
            this.D = l;
            this.buttonType = this.buttonType = E;
            this.C6();
            this.buttonType === 2 && g.d4(this.element, "ytp-continue-watching-button");
            this.listen("click", this.onClick);
            this.listen("videodatachange", this.C6);
            this.SD(!0)
        },
        mq = function(l) {
            Oi.call(this, l, "watch-again-on-youtube-endscreen");
            this.watchButton = new zXD(l, 1);
            g.L(this, this.watchButton);
            this.watchButton.AO(this.element);
            g.htH(l) && (this.C = new g.np(l), g.L(this, this.C), this.V = new g.W({
                j: "div",
                R4: ["ytp-watch-again-on-youtube-endscreen-more-videos-container"],
                J: {
                    tabIndex: "-1"
                },
                S: [this.C]
            }), g.L(this, this.V), this.C.AO(this.V.element), this.V.AO(this.element));
            l.createClientVe(this.element, this, 156914);
            this.hide()
        },
        lPN = function(l) {
            g.Vc.call(this, l);
            var E = this;
            this.endScreen = null;
            this.C = this.V = this.G = !1;
            this.listeners = new g.oE(this);
            g.L(this, this.listeners);
            var e = l.N();
            l.isEmbedsShortsMode() ? this.endScreen = new mq(l) : r5_(l) ? (this.G = !0, weB(this), this.C ? this.endScreen = new vP(l) : e.B("delhi_modern_endscreen") ? this.endScreen = new Xex(l) : this.endScreen = new pN(l)) : e.Hy ? this.endScreen = new S7x(l) : this.endScreen = new Oi(l);
            g.L(this, this.endScreen);
            g.lb(l, this.endScreen.element, 4);
            ndt(this);
            this.listeners.L(l, "videodatachange", this.onVideoDataChange, this);
            this.listeners.L(l, g.zw("endscreen"), function(d) {
                E.onCueRangeEnter(d)
            });
            this.listeners.L(l, g.r9("endscreen"), function(d) {
                E.onCueRangeExit(d)
            })
        },
        weB = function(l) {
            var E = l.player.getVideoData();
            if (!E || l.C === E.ul && l.V === E.yh) return !1;
            l.C = E.ul;
            l.V = E.yh;
            return !0
        },
        r5_ = function(l) {
            l = l.N();
            return l.yh && !l.Hy && !l.disableOrganicUi
        },
        ndt = function(l) {
            l.player.tE("endscreen");
            var E = l.player.getVideoData();
            E = new g.X1(Math.max((E.lengthSeconds - 10) * 1E3, 0), 0x8000000000000, {
                id: "preload",
                namespace: "endscreen"
            });
            var e = new g.X1(0x8000000000000, 0x8000000000000, {
                id: "load",
                priority: 8,
                namespace: "endscreen"
            });
            l.player.Lh([E, e])
        };
    g.jw.prototype.cU = g.Cs(6, function() {
        return this.app.cU()
    });
    g.p1.prototype.cU = g.Cs(5, function() {
        return this.getVideoData().gx
    });
    g.$L.prototype.pK = g.Cs(4, function(l) {
        this.WV().pK(l)
    });
    g.rl.prototype.pK = g.Cs(3, function(l) {
        this.eq !== l && (this.eq = l, this.b_())
    });
    g.p(ud, g.W);
    ud.prototype.select = function() {
        this.D.Q4(this.suggestion.videoId, this.suggestion.sessionData, this.suggestion.playlistId, void 0, void 0, this.suggestion.jf || void 0) && this.D.logClick(this.element)
    };
    ud.prototype.onClick = function(l) {
        g.QE(l, this.D, this.C, this.suggestion.sessionData || void 0) && this.select()
    };
    ud.prototype.onKeyPress = function(l) {
        switch (l.keyCode) {
            case 13:
            case 32:
                l.defaultPrevented || (this.select(), l.preventDefault())
        }
    };
    g.p(BP, g.W);
    g.D = BP.prototype;
    g.D.GO = function(l) {
        this.suggestion !== l && (this.suggestion = l, g.OT(this.C, l), this.playButton.updateValue("url", this.suggestion.Rg()), qY(this))
    };
    g.D.Av = function() {
        return this.G > 0
    };
    g.D.YA = function() {
        this.Av() || (this.G = Date.now(), $JH(this), c56(this.D, gdo(this)), g.u9(this.D.getRootNode(), "countdown-running", this.Av()))
    };
    g.D.Ab = function() {
        this.FV();
        $JH(this);
        var l = this.C.GK("ytp-autonav-endscreen-upnext-header");
        l && g.tC(l, "Up next")
    };
    g.D.FV = function() {
        this.Av() && (this.W.stop(), this.G = 0)
    };
    g.D.select = function(l) {
        this.D.nextVideo(!1, l === void 0 ? !1 : l);
        this.FV()
    };
    g.D.lC = function(l) {
        g.QE(l, this.D) && (l.currentTarget === this.playButton.element ? this.D.logClick(this.playButton.element) : l.currentTarget === this.C.GK("ytp-autonav-endscreen-link-container") && (l = this.C.GK("ytp-autonav-endscreen-link-container"), this.D.logVisibility(l, !0), this.D.logClick(l)), this.X ? (this.D.x8("innertubeCommand", this.X), this.FV()) : this.select())
    };
    g.D.Ei = function() {
        this.D.logClick(this.cancelButton.element);
        g.X5(this.D, !0);
        this.cancelCommand && this.D.x8("innertubeCommand", this.cancelCommand)
    };
    g.D.onVideoDataChange = function(l, E) {
        Zd5(this, E);
        l = E.getWatchNextResponse();
        var e, d;
        l = (e = ido(l)) == null ? void 0 : (d = e.cancelButton) == null ? void 0 : d.buttonRenderer;
        this.cancelCommand = l == null ? void 0 : l.command
    };
    g.D.rO9 = function(l) {
        if (W85(this)) {
            var E = this.D.getVideoData().watchToWatchTransitionRenderer,
                e = E == null ? void 0 : E.fromColorPaletteDark;
            E = E == null ? void 0 : E.toColorPaletteDark;
            if (e && E) {
                var d = this.element;
                d.style.setProperty("--w2w-start-background-color", g.kO(e.surgeColor));
                d.style.setProperty("--w2w-start-primary-text-color", g.kO(e.primaryTitleColor));
                d.style.setProperty("--w2w-start-secondary-text-color", g.kO(e.secondaryTitleColor));
                d.style.setProperty("--w2w-end-background-color", g.kO(E.surgeColor));
                d.style.setProperty("--w2w-end-primary-text-color", g.kO(E.primaryTitleColor));
                d.style.setProperty("--w2w-end-secondary-text-color", g.kO(E.secondaryTitleColor));
                d.style.setProperty("--w2w-animation-duration", l + "ms")
            }
            g.u9(this.element, "ytp-w2w-animate", !0)
        }
    };
    g.D.fD = function(l) {
        this.D.B("web_autonav_color_transition") && l !== 2 && g.u9(this.element, "ytp-w2w-animate", !1)
    };
    g.D.xV = function() {
        var l = this.D.vy();
        this.Y && this.qw !== l && this.SD(l);
        qY(this);
        this.D.logVisibility(this.container.element, l);
        this.D.logVisibility(this.cancelButton.element, l);
        this.D.logVisibility(this.C.GK("ytp-autonav-endscreen-link-container"), l);
        this.D.logVisibility(this.playButton.element, l)
    };
    g.D.mq = function(l) {
        return l.width < 400 || l.height < 459
    };
    g.p(Oi, g.W);
    g.D = Oi.prototype;
    g.D.create = function() {
        this.created = !0
    };
    g.D.destroy = function() {
        this.created = !1
    };
    g.D.Lt = function() {
        return !1
    };
    g.D.vy = function() {
        return !1
    };
    g.D.GT = function() {
        return !1
    };
    g.p(MY, g.W);
    g.D = MY.prototype;
    g.D.Ha = function() {
        this.notification && (this.W.stop(), this.Dn(this.G), this.G = null, this.notification.close(), this.notification = null)
    };
    g.D.GO = function(l) {
        this.suggestion = l;
        g.OT(this, l, "hqdefault.jpg")
    };
    g.D.uC = function() {
        this.SD(this.api.vy());
        this.api.logVisibility(this.element, this.api.vy());
        this.api.logVisibility(this.GK("ytp-upnext-autoplay-icon"), this.api.vy());
        this.cancelButton && this.api.logVisibility(this.cancelButton.element, this.api.vy())
    };
    g.D.uoS = function() {
        window.focus();
        this.Ha()
    };
    g.D.YA = function(l) {
        var E = this;
        this.Av() || (g.nx("a11y-announce", "Up Next " + this.suggestion.title), this.V = (0, g.tF)(), this.C = new g.Gv(function() {
            GkW(E, l)
        }, 25), GkW(this, l), c56(this.api, jMD(this, l)));
        g.xP(this.element, "ytp-upnext-autoplay-paused")
    };
    g.D.hide = function() {
        g.W.prototype.hide.call(this)
    };
    g.D.Av = function() {
        return !!this.C
    };
    g.D.Ab = function() {
        this.FV();
        this.V = (0, g.tF)();
        GkW(this);
        g.d4(this.element, "ytp-upnext-autoplay-paused")
    };
    g.D.FV = function() {
        this.Av() && (this.C.dispose(), this.C = null)
    };
    g.D.select = function(l) {
        l = l === void 0 ? !1 : l;
        if (this.api.N().B("autonav_notifications") && l && window.Notification && typeof document.hasFocus === "function") {
            var E = Notification.permission;
            E === "default" ? Notification.requestPermission() : E !== "granted" || document.hasFocus() || (this.Ha(), this.notification = new Notification("Up Next", {
                body: this.suggestion.title,
                icon: this.suggestion.Cw()
            }), this.G = this.L(this.notification, "click", this.uoS), this.W.start())
        }
        this.FV();
        this.api.nextVideo(!1, l)
    };
    g.D.xM = function(l) {
        !g.yJ(this.cancelButton.element, l.target) && g.QE(l, this.api) && (this.api.vy() && this.api.logClick(this.GK("ytp-upnext-autoplay-icon")), this.select())
    };
    g.D.bz = function() {
        this.api.vy() && this.cancelButton && this.api.logClick(this.cancelButton.element);
        g.X5(this.api, !0)
    };
    g.D.Jg6 = function(l) {
        this.api.getPresentingPlayerType();
        this.show();
        this.YA(l)
    };
    g.D.yg6 = function() {
        this.api.getPresentingPlayerType();
        this.FV();
        this.hide()
    };
    g.D.cS = function() {
        this.FV();
        this.Ha();
        g.W.prototype.cS.call(this)
    };
    g.p(vP, Oi);
    g.D = vP.prototype;
    g.D.create = function() {
        Oi.prototype.create.call(this);
        this.W.L(this.player, "appresize", this.I0);
        this.W.L(this.player, "onVideoAreaChange", this.I0);
        this.W.L(this.player, "videodatachange", this.onVideoDataChange);
        this.W.L(this.player, "autonavchange", this.Sm);
        this.W.L(this.player, "onAutonavCancelled", this.lz);
        this.onVideoDataChange()
    };
    g.D.show = function() {
        Oi.prototype.show.call(this);
        (this.Y || this.G && this.G !== this.videoData.clientPlaybackNonce) && g.X5(this.player, !1);
        g.EA(this.player) && this.Lt() && !this.G ? (NY(this), this.videoData.autonavState === 2 ? this.player.getVisibilityState() === 3 ? this.C.select(!0) : this.C.YA() : this.videoData.autonavState === 3 && this.C.Ab()) : (g.X5(this.player, !0), NY(this));
        this.I0()
    };
    g.D.hide = function() {
        Oi.prototype.hide.call(this);
        this.C.Ab();
        NY(this)
    };
    g.D.I0 = function() {
        var l = this.player.v5(!0, this.player.isFullscreen());
        NY(this);
        qY(this.V);
        g.u9(this.element, "ytp-autonav-cancelled-small-mode", this.mq(l));
        g.u9(this.element, "ytp-autonav-cancelled-tiny-mode", this.nX(l));
        g.u9(this.element, "ytp-autonav-cancelled-mini-mode", l.width <= 400 || l.height <= 360);
        this.overlay && g.W_(this.overlay.element, {
            width: l.width + "px"
        });
        if (!this.X)
            for (l = 0; l < this.videos.length; l++) g.u9(this.videos[l].element, "ytp-suggestion-card-with-margin", l % 2 === 1)
    };
    g.D.onVideoDataChange = function() {
        var l = this.player.getVideoData();
        if (this.videoData !== l && l) {
            this.videoData = l;
            if ((l = this.videoData.suggestions) && l.length || this.player.B("web_player_autonav_empty_suggestions_fix")) {
                var E = g.AQ(this.videoData);
                E && (this.C.GO(E), this.C !== this.V && this.V.GO(E))
            }
            if (l && l.length)
                for (E = 0; E < EAN.length; ++E) {
                    var e = EAN[E];
                    if (l && l[e]) {
                        this.videos[E] = new ud(this.player);
                        var d = this.videos[E];
                        e = l[e];
                        d.suggestion !== e && (d.suggestion = e, g.OT(d, e));
                        g.L(this, this.videos[E]);
                        this.videos[E].AO(this.K.element)
                    }
                }
            this.I0()
        }
    };
    g.D.Sm = function(l) {
        l === 1 ? (this.Y = !1, this.G = this.videoData.clientPlaybackNonce, this.C.FV(), this.qw && this.I0()) : (this.Y = !0, this.vy() && (l === 2 ? this.C.YA() : l === 3 && this.C.Ab()))
    };
    g.D.lz = function(l) {
        l ? this.Sm(1) : (this.G = null, this.Y = !1)
    };
    g.D.Lt = function() {
        return this.videoData.autonavState !== 1
    };
    g.D.mq = function(l) {
        return (l.width < 910 || l.height < 459) && !this.nX(l) && !(l.width <= 400 || l.height <= 360)
    };
    g.D.nX = function(l) {
        return l.width < 800 && !(l.width <= 400 || l.height <= 360)
    };
    g.D.vy = function() {
        return this.qw && g.EA(this.player) && this.Lt() && !this.G
    };
    var EAN = [1, 3, 2, 4];
    g.p(Xex, Oi);
    g.D = Xex.prototype;
    g.D.create = function() {
        Oi.prototype.create.call(this);
        var l = this.player.getVideoData();
        l && (this.videoData = l);
        this.kA();
        this.V.L(this.player, "appresize", this.kA);
        this.V.L(this.player, "onVideoAreaChange", this.kA);
        this.V.L(this.player, "videodatachange", this.onVideoDataChange);
        this.V.L(this.player, "autonavchange", this.jc);
        this.V.L(this.player, "onAutonavCancelled", this.SE);
        l = this.videoData.autonavState;
        l !== this.K && this.jc(l);
        this.V.L(this.element, "transitionend", this.nD)
    };
    g.D.destroy = function() {
        g.oU(this.V);
        g.xd(this.stills);
        this.stills = [];
        Oi.prototype.destroy.call(this);
        g.xP(this.element, "ytp-show-tiles");
        this.X.stop();
        this.K = this.videoData.autonavState
    };
    g.D.Lt = function() {
        return this.videoData.autonavState !== 1
    };
    g.D.show = function() {
        var l = this.qw;
        Oi.prototype.show.call(this);
        g.xP(this.element, "ytp-show-tiles");
        this.player.N().V ? g.S5(this.X) : this.X.start();
        (this.W || this.G && this.G !== this.videoData.clientPlaybackNonce) && g.X5(this.player, !1);
        Js(this) ? (bd(this), this.videoData.autonavState === 2 ? this.player.getVisibilityState() === 3 ? this.C.select(!0) : this.C.YA() : this.videoData.autonavState === 3 && this.C.Ab()) : (g.X5(this.player, !0), bd(this));
        l !== this.qw && this.player.logVisibility(this.element, !0)
    };
    g.D.hide = function() {
        var l = this.qw;
        Oi.prototype.hide.call(this);
        this.C.Ab();
        bd(this);
        l !== this.qw && this.player.logVisibility(this.element, !1)
    };
    g.D.nD = function(l) {
        l.target === this.element && this.kA()
    };
    g.D.kA = function() {
        var l, E, e, d;
        var C = ((l = this.videoData) == null ? 0 : (E = l.suggestions) == null ? 0 : E.length) ? (e = this.videoData) == null ? void 0 : e.suggestions : [(d = this.videoData) == null ? void 0 : g.AQ(d)];
        if (C.length) {
            E = this.D.v5(!0, this.D.isFullscreen());
            l = Math.floor((E.width - 64 + 16) / (g.$1(E.width * .27, 250, 450) + 16));
            E = Math.min(3, Math.floor((E.height - 64) / ((E.width - 64 - (l - 1) * 16) / l * .5625 + 70)));
            g.YP(this.element, ["ytp-modern-endscreen-limit-rows-1", "ytp-modern-endscreen-limit-rows-2", "ytp-modern-endscreen-limit-rows-3"]);
            g.d4(this.element, "ytp-modern-endscreen-limit-rows-" + E);
            g.u9(this.element, "ytp-modern-endscreen-single-item", l === 1);
            g.u9(this.element, "ytp-modern-endscreen-row-0", E === 0);
            l = this.table.element;
            l.ariaLive = "polite";
            this.C.GO(g.AQ(this.videoData));
            this.C instanceof BP && qY(this.C);
            g.u9(this.element, "ytp-endscreen-takeover", Js(this));
            bd(this);
            E = 0;
            l.ariaBusy = "true";
            e = C.length;
            for (d = 0; d < e; d++) {
                var x = d % e,
                    Y = this.stills[d];
                Y || (Y = new g.M_(this.player), this.stills[d] = Y, l.appendChild(Y.element));
                g.R9s(Y, C[x]);
                E++
            }
            this.stills.length =
                E
        }
    };
    g.D.onVideoDataChange = function() {
        var l = this.player.getVideoData(1);
        this.videoData !== l && (l != null && g.AQ(l) ? (this.videoData = l, this.kA()) : this.player.CJ("missg", {
            vid: (l == null ? void 0 : l.videoId) || "",
            cpn: (l == null ? void 0 : l.clientPlaybackNonce) || ""
        }))
    };
    g.D.GT = function() {
        return this.C.Av()
    };
    g.D.jc = function(l) {
        l === 1 ? (this.W = !1, this.G = this.videoData.clientPlaybackNonce, this.C.FV(), this.qw && this.kA()) : (this.W = !0, this.qw && Js(this) && (l === 2 ? this.C.YA() : l === 3 && this.C.Ab()))
    };
    g.D.SE = function(l) {
        if (l) {
            for (l = 0; l < this.stills.length; l++) this.D.logVisibility(this.stills[l].element, !0);
            this.jc(1)
        } else this.G = null, this.W = !1;
        this.kA()
    };
    g.D.vy = function() {
        return this.qw && Js(this)
    };
    g.p(S7x, Oi);
    S7x.prototype.TK = function() {
        var l = this.player.getVideoData();
        this.C.update({
            profilePicture: l.profilePicture,
            author: l.author
        });
        this.subscribeButton.channelId = l.bE;
        var E = this.subscribeButton;
        l.subscribed ? E.C() : E.V()
    };
    g.p(Dk, g.W);
    Dk.prototype.select = function() {
        this.api.Q4(this.suggestion.videoId, this.suggestion.sessionData, this.suggestion.playlistId, void 0, void 0, this.suggestion.jf || void 0) && this.api.logClick(this.element)
    };
    Dk.prototype.onClick = function(l) {
        if (g.dp(this.api.N()) && this.api.B("web_player_log_click_before_generating_ve_conversion_params")) {
            this.api.logClick(this.element);
            var E = this.suggestion.Rg(),
                e = {};
            g.rA(this.api, e);
            E = g.Uy(E, e);
            g.sA(E, this.api, l)
        } else g.QE(l, this.api, this.V, this.suggestion.sessionData || void 0) && this.select()
    };
    Dk.prototype.onKeyPress = function(l) {
        switch (l.keyCode) {
            case 13:
            case 32:
                l.defaultPrevented || (this.select(), l.preventDefault())
        }
    };
    Dk.prototype.onVideoDataChange = function() {
        var l = this.api.getVideoData(),
            E = this.api.N();
        this.V = l.HB ? !1 : E.W
    };
    g.p(pN, Oi);
    g.D = pN.prototype;
    g.D.create = function() {
        Oi.prototype.create.call(this);
        var l = this.player.getVideoData();
        l && (this.videoData = l);
        this.UA();
        this.V.L(this.player, "appresize", this.UA);
        this.V.L(this.player, "onVideoAreaChange", this.UA);
        this.V.L(this.player, "videodatachange", this.onVideoDataChange);
        this.V.L(this.player, "autonavchange", this.Al);
        this.V.L(this.player, "onAutonavCancelled", this.QF);
        l = this.videoData.autonavState;
        l !== this.U && this.Al(l);
        this.V.L(this.element, "transitionend", this.Fc)
    };
    g.D.destroy = function() {
        g.oU(this.V);
        g.xd(this.stills);
        this.stills = [];
        Oi.prototype.destroy.call(this);
        g.xP(this.element, "ytp-show-tiles");
        this.Y.stop();
        this.U = this.videoData.autonavState
    };
    g.D.Lt = function() {
        return this.videoData.autonavState !== 1
    };
    g.D.show = function() {
        var l = this.qw;
        Oi.prototype.show.call(this);
        g.xP(this.element, "ytp-show-tiles");
        this.player.N().V ? g.S5(this.Y) : this.Y.start();
        (this.X || this.W && this.W !== this.videoData.clientPlaybackNonce) && g.X5(this.player, !1);
        KN(this) ? (Ui(this), this.videoData.autonavState === 2 ? this.player.getVisibilityState() === 3 ? this.C.select(!0) : this.C.YA() : this.videoData.autonavState === 3 && this.C.Ab()) : (g.X5(this.player, !0), Ui(this));
        l !== this.qw && this.player.logVisibility(this.element, !0)
    };
    g.D.hide = function() {
        var l = this.qw;
        Oi.prototype.hide.call(this);
        this.C.Ab();
        Ui(this);
        l !== this.qw && this.player.logVisibility(this.element, !1)
    };
    g.D.Fc = function(l) {
        l.target === this.element && this.UA()
    };
    g.D.UA = function() {
        var l, E, e, d;
        var C = ((l = this.videoData) == null ? 0 : (E = l.suggestions) == null ? 0 : E.length) ? (e = this.videoData) == null ? void 0 : e.suggestions : [(d = this.videoData) == null ? void 0 : g.AQ(d)];
        if (C.length) {
            g.d4(this.element, "ytp-endscreen-paginate");
            var x = this.D.v5(!0, this.D.isFullscreen());
            if (l = g.F5(this.D)) l = l.IW() ? 48 : 32, x.width -= l * 2;
            var Y = x.width / x.height;
            d = 96 / 54;
            E = l = 2;
            var B = Math.max(x.width / 96, 2),
                q = Math.max(x.height / 54, 2);
            e = C.length;
            var O = e * 4;
            for (O -= 4; O > 0 && (l < B || E < q);) {
                var M = l / 2,
                    v = E / 2,
                    N = l <= B - 2 && O >=
                    v * 4,
                    J = E <= q - 2 && O >= M * 4;
                if ((M + 1) / v * d / Y > Y / (M / (v + 1) * d) && J) O -= M * 4, E += 2;
                else if (N) O -= v * 4, l += 2;
                else if (J) O -= M * 4, E += 2;
                else break
            }
            d = !1;
            O >= 12 && e * 4 - O <= 6 && (E >= 4 || l >= 4) && (d = !0);
            O = l * 96;
            B = E * 54;
            Y = O / B < Y ? x.height / B : x.width / O;
            Y = Math.min(Y, 2);
            O = Math.floor(Math.min(x.width, O * Y));
            B = Math.floor(Math.min(x.height, B * Y));
            x = this.table.element;
            x.ariaLive = "polite";
            g.Ej(x, O, B);
            g.W_(x, {
                marginLeft: O / -2 + "px",
                marginTop: B / -2 + "px"
            });
            this.C.GO(g.AQ(this.videoData));
            this.C instanceof BP && qY(this.C);
            g.u9(this.element, "ytp-endscreen-takeover",
                KN(this));
            Ui(this);
            O += 4;
            B += 4;
            Y = 0;
            x.ariaBusy = "true";
            for (q = 0; q < l; q++)
                for (M = 0; M < E; M++)
                    if (v = Y, J = 0, d && q >= l - 2 && M >= E - 2 ? J = 1 : M % 2 === 0 && q % 2 === 0 && (M < 2 && q < 2 ? M === 0 && q === 0 && (J = 2) : J = 2), v = g.Ta(v + this.G, e), J !== 0) {
                        N = this.stills[Y];
                        N || (N = new Dk(this.player), this.stills[Y] = N, x.appendChild(N.element));
                        var b = Math.floor(B * M / E),
                            m = Math.floor(O * q / l),
                            H = Math.floor(B * (M + J) / E) - b - 4,
                            Q = Math.floor(O * (q + J) / l) - m - 4;
                        g.rv(N.element, m, b);
                        g.Ej(N.element, Q, H);
                        g.W_(N.element, "transitionDelay", (M + q) / 20 + "s");
                        g.u9(N.element, "ytp-videowall-still-mini",
                            J === 1);
                        g.u9(N.element, "ytp-videowall-still-large", J > 2);
                        J = Math.max(Q, H);
                        g.u9(N.element, "ytp-videowall-still-round-large", J >= 256);
                        g.u9(N.element, "ytp-videowall-still-round-medium", J > 96 && J < 256);
                        g.u9(N.element, "ytp-videowall-still-round-small", J <= 96);
                        v = C[v];
                        N.suggestion !== v && (N.suggestion = v, J = N.api.N(), b = g.ec(N.element, "ytp-videowall-still-large") ? "hqdefault.jpg" : "mqdefault.jpg", g.OT(N, v, b), g.dp(J) && !N.api.B("web_player_log_click_before_generating_ve_conversion_params") && (J = v.Rg(), b = {}, g.fw(N.api, "addEmbedsConversionTrackingParams", [b]), J = g.Uy(J, b), N.updateValue("url", J)), (v = (v = v.sessionData) && v.itct) && N.api.setTrackingParams(N.element, v));
                        Y++
                    }
            x.ariaBusy = "false";
            g.u9(this.element, "ytp-endscreen-paginate", Y < e);
            for (C = this.stills.length - 1; C >= Y; C--) l = this.stills[C], g.mT(l.element), g.Cd(l);
            this.stills.length = Y
        }
    };
    g.D.onVideoDataChange = function() {
        var l = this.player.getVideoData(1);
        this.videoData !== l && (l != null && g.AQ(l) ? (this.G = 0, this.videoData = l, this.UA()) : this.player.CJ("missg", {
            vid: (l == null ? void 0 : l.videoId) || "",
            cpn: (l == null ? void 0 : l.clientPlaybackNonce) || ""
        }))
    };
    g.D.eE = function() {
        this.G += this.stills.length;
        this.UA()
    };
    g.D.Ui = function() {
        this.G -= this.stills.length;
        this.UA()
    };
    g.D.GT = function() {
        return this.C.Av()
    };
    g.D.Al = function(l) {
        l === 1 ? (this.X = !1, this.W = this.videoData.clientPlaybackNonce, this.C.FV(), this.qw && this.UA()) : (this.X = !0, this.qw && KN(this) && (l === 2 ? this.C.YA() : l === 3 && this.C.Ab()))
    };
    g.D.QF = function(l) {
        if (l) {
            for (l = 0; l < this.stills.length; l++) this.D.logVisibility(this.stills[l].element, !0);
            this.Al(1)
        } else this.W = null, this.X = !1;
        this.UA()
    };
    g.D.vy = function() {
        return this.qw && KN(this)
    };
    g.p(zXD, g.W);
    g.D = zXD.prototype;
    g.D.C6 = function() {
        switch (this.buttonType) {
            case 1:
                var l = "Watch again on YouTube";
                var E = 156915;
                break;
            case 2:
                l = "Continue watching on YouTube";
                E = 156942;
                break;
            default:
                l = "Continue watching on YouTube", E = 156942
        }
        this.update({
            content: l
        });
        this.D.hasVe(this.element) && this.D.destroyVe(this.element);
        this.D.createClientVe(this.element, this, E)
    };
    g.D.onClick = function(l) {
        this.D.B("web_player_log_click_before_generating_ve_conversion_params") && this.D.logClick(this.element);
        g.sA(this.getVideoUrl(), this.D, l);
        this.D.B("web_player_log_click_before_generating_ve_conversion_params") || this.D.logClick(this.element)
    };
    g.D.getVideoUrl = function() {
        var l = !0;
        switch (this.buttonType) {
            case 1:
                l = !0;
                break;
            case 2:
                l = !1
        }
        l = this.D.getVideoUrl(l, !1, !1, !0);
        var E = this.D.N();
        if (g.dp(E)) {
            var e = {};
            g.dp(E) && g.fw(this.D, "addEmbedsConversionTrackingParams", [e]);
            l = g.Uy(l, e)
        }
        return l
    };
    g.D.logVisibility = function() {
        this.D.logVisibility(this.element, this.qw && this.Z)
    };
    g.D.show = function() {
        g.W.prototype.show.call(this);
        this.logVisibility()
    };
    g.D.hide = function() {
        g.W.prototype.hide.call(this);
        this.logVisibility()
    };
    g.D.y$ = function(l) {
        g.W.prototype.y$.call(this, l);
        this.logVisibility()
    };
    g.p(mq, Oi);
    mq.prototype.hasSuggestions = function() {
        var l;
        return (l = this.C) == null ? void 0 : l.hasSuggestions()
    };
    mq.prototype.show = function() {
        if (this.player.getPlayerState() !== 3) {
            Oi.prototype.show.call(this);
            var l = this.V;
            if (l) {
                var E = this.C.hasSuggestions();
                g.u9(this.element, "ytp-shorts-branded-ui", E);
                E ? l.show() : l.hide()
            }
            var e;
            (e = g.F5(this.player)) == null || e.pK(!0);
            this.player.logVisibility(this.element, !0);
            this.watchButton.y$(!0)
        }
    };
    mq.prototype.hide = function() {
        Oi.prototype.hide.call(this);
        var l;
        (l = g.F5(this.player)) == null || l.pK(!1);
        this.player.logVisibility(this.element, !1);
        this.watchButton.y$(!1)
    };
    g.p(lPN, g.Vc);
    g.D = lPN.prototype;
    g.D.f_ = function() {
        var l = this.player.getVideoData(),
            E = l.mutedAutoplay && (l.limitedPlaybackDurationInSeconds > 0 || l.endSeconds > 0 || l.mutedAutoplayDurationMode !== 2);
        if (this.player.isEmbedsShortsMode() && !E) return !0;
        var e;
        var d = !!((l == null ? 0 : g.AQ(l)) || (l == null ? 0 : (e = l.suggestions) == null ? 0 : e.length));
        d = !r5_(this.player) || d;
        l = l.y5;
        e = this.player.Cd();
        return d && !l && !e && !E
    };
    g.D.vy = function() {
        return this.endScreen.vy()
    };
    g.D.BH = function() {
        return this.vy() ? this.endScreen.GT() : !1
    };
    g.D.cS = function() {
        this.player.tE("endscreen");
        g.Vc.prototype.cS.call(this)
    };
    g.D.load = function() {
        var l = this.player.getVideoData();
        var E = l.transitionEndpointAtEndOfStream;
        if (E && E.videoId) {
            var e = this.player.WP().Qb.get("heartbeat"),
                d = g.AQ(l);
            !d || E.videoId !== d.videoId || l.HC ? (this.player.Q4(E.videoId, void 0, void 0, !0, !0, E), e && e.CM("HEARTBEAT_ACTION_TRIGGER_AT_STREAM_END", "HEARTBEAT_ACTION_TRANSITION_REASON_HAS_NEW_STREAM_TRANSITION_ENDPOINT"), l = !0) : l = !1
        } else l = !1;
        l || (g.Vc.prototype.load.call(this), this.endScreen.show())
    };
    g.D.unload = function() {
        g.Vc.prototype.unload.call(this);
        this.endScreen.hide();
        this.endScreen.destroy()
    };
    g.D.onCueRangeEnter = function(l) {
        this.f_() && (this.endScreen.created || this.endScreen.create(), l.getId() === "load" && this.load())
    };
    g.D.onCueRangeExit = function(l) {
        l.getId() === "load" && this.loaded && this.unload()
    };
    g.D.onVideoDataChange = function() {
        ndt(this);
        this.G && weB(this) && (this.endScreen && (this.endScreen.hide(), this.endScreen.created && this.endScreen.destroy(), this.endScreen.dispose()), this.C ? this.endScreen = new vP(this.player) : this.endScreen = new pN(this.player), g.L(this, this.endScreen), g.lb(this.player, this.endScreen.element, 4))
    };
    g.HQ("endscreen", lPN);
})(_yt_player);